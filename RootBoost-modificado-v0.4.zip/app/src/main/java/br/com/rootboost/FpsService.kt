package br.com.rootboost

import android.animation.ValueAnimator
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.RectF
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import java.util.Locale

/** Contador de FPS: número grande animado, gráfico dos últimos segundos, 1% low e tempo de quadro. */
class FpsView(ctx: Context) : View(ctx) {
    private var exibido = 0f
    private var anim: ValueAnimator? = null
    private var alvo = 60f
    private var baixo1 = 0f
    private var frameMs = 0f
    private var hist: List<Float> = emptyList()

    private val fundo = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xE60F1115.toInt() }
    private val borda = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        color = Cores.LINHA
    }
    private val num = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        typeface = FonteMedia
        color = Cores.TEXTO
    }
    private val leg = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Cores.SUAVE }
    private val linha = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
    }
    private val barra = Paint(Paint.ANTI_ALIAS_FLAG)
    private val caminho = Path()
    private val ret = RectF()

    fun atualizar(m: Fps.Medida?, h: List<Float>) {
        hist = h
        baixo1 = m?.baixo1 ?: 0f
        frameMs = m?.frameMs ?: 0f
        alvo = maxOf(30f, h.maxOrNull() ?: 0f)
        anim?.cancel()
        val a = ValueAnimator.ofFloat(exibido, m?.fps ?: 0f)
        a.duration = 450
        a.addUpdateListener { exibido = it.animatedValue as Float; invalidate() }
        anim = a
        a.start()
    }

    override fun onMeasure(w: Int, h: Int) {
        // Compacto para não cobrir HUD, minimapa ou botões do jogo.
        setMeasuredDimension(context.dp(148), context.dp(54))
    }

    override fun onDraw(c: Canvas) {
        val d = context.dp(1).toFloat()
        val w = width.toFloat()
        val h = height.toFloat()
        ret.set(d, d, w - d, h - d)
        val raio = h * 0.28f
        c.drawRoundRect(ret, raio, raio, fundo)
        borda.strokeWidth = d
        c.drawRoundRect(ret, raio, raio, borda)

        val razao = if (alvo > 0f) exibido / alvo else 0f
        val cor = when {
            exibido < 1f -> Cores.SUAVE
            razao >= 0.9f -> Cores.OK
            razao >= 0.6f -> Cores.AMBAR
            else -> Cores.ERRO
        }
        barra.color = cor
        ret.set(9f * d, h * 0.22f, 12f * d, h * 0.78f)
        c.drawRoundRect(ret, 2f * d, 2f * d, barra)

        num.textSize = h * 0.43f
        c.drawText(Math.round(exibido).toString(), 18f * d, h * 0.57f, num)
        leg.textSize = h * 0.15f
        c.drawText("FPS", 19f * d, h * 0.84f, leg)

        val x0 = w * 0.47f
        val x1 = w - 10f * d
        val y0 = h * 0.20f
        val y1 = h * 0.58f
        val n = minOf(hist.size, 40)
        if (n >= 2) {
            val ini = hist.size - n
            val passo = (x1 - x0) / (n - 1).toFloat()
            caminho.reset()
            for (i in 0 until n) {
                val v = hist[ini + i]
                val x = x0 + i * passo
                val y = y1 - (y1 - y0) * (v / alvo).coerceIn(0f, 1f)
                if (i == 0) caminho.moveTo(x, y) else caminho.lineTo(x, y)
            }
            linha.color = cor
            linha.strokeWidth = 2f * d
            c.drawPath(caminho, linha)
        }
        leg.textSize = h * 0.13f
        c.drawText(String.format(Locale.US, "1%% low %d · %.1f ms", Math.round(baixo1), frameMs), x0, h * 0.84f, leg)
    }
}

class FpsService : Service() {

    private var wm: WindowManager? = null
    private var vista: FpsView? = null
    private val main = Handler(Looper.getMainLooper())
    @Volatile private var ativo = false

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (!Settings.canDrawOverlays(this)) { stopSelf(); return START_NOT_STICKY }
        if (vista != null) return START_NOT_STICKY

        val gerente = getSystemService(WINDOW_SERVICE) as WindowManager
        wm = gerente
        val v = FpsView(this)
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        )
        params.gravity = Gravity.TOP or Gravity.END
        params.x = dp(14)
        params.y = dp(14)

        var ix = 0
        var iy = 0
        var tx = 0f
        var ty = 0f
        v.setOnTouchListener { view, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { ix = params.x; iy = params.y; tx = e.rawX; ty = e.rawY }
                MotionEvent.ACTION_MOVE -> {
                    // gravity END: arrastar para a esquerda aumenta x
                    params.x = ix - (e.rawX - tx).toInt()
                    params.y = iy + (e.rawY - ty).toInt()
                    gerente.updateViewLayout(view, params)
                }
            }
            true
        }
        gerente.addView(v, params)
        vista = v

        ativo = true
        Thread {
            while (ativo) {
                val m = Fps.atual
                val h = Fps.historico()
                main.post { vista?.atualizar(m, h) }
                try {
                    Thread.sleep(1000)
                } catch (e: InterruptedException) {
                    break
                }
            }
        }.start()
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        ativo = false
        val v = vista
        if (v != null) {
            try { wm?.removeView(v) } catch (e: Exception) { }
        }
        vista = null
        wm = null
        super.onDestroy()
    }
}
