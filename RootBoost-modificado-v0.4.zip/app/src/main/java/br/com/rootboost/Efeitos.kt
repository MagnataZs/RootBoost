package br.com.rootboost

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup

/** Feedback de toque: o elemento "afunda" levemente ao ser pressionado. */
fun View.pressionar() {
    setOnTouchListener { v, e ->
        when (e.action) {
            MotionEvent.ACTION_DOWN -> v.animate().scaleX(0.97f).scaleY(0.97f).setDuration(90).start()
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> v.animate().scaleX(1f).scaleY(1f).setDuration(160).start()
        }
        false
    }
}

/** Entrada escalonada: os blocos da página sobem e aparecem um após o outro. */
fun entrada(grupo: ViewGroup) {
    val n = minOf(grupo.childCount, 14)
    for (i in 0 until n) {
        val v = grupo.getChildAt(i)
        v.alpha = 0f
        v.translationY = v.context.dp(14).toFloat()
        v.animate().alpha(1f).translationY(0f).setStartDelay(i * 35L).setDuration(320).start()
    }
}

/** Bolinha que pulsa (indica serviço ativo). */
class Pulso(ctx: Context) : View(ctx) {
    var cor: Int = Cores.OK
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private var fase = 0f
    private val anim: ValueAnimator = ValueAnimator.ofFloat(0f, 1f).apply {
        duration = 1400
        repeatCount = ValueAnimator.INFINITE
        addUpdateListener { fase = it.animatedValue as Float; invalidate() }
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        anim.start()
    }

    override fun onDetachedFromWindow() {
        anim.cancel()
        super.onDetachedFromWindow()
    }

    override fun onMeasure(w: Int, h: Int) {
        val t = context.dp(14)
        setMeasuredDimension(t, t)
    }

    override fun onDraw(c: Canvas) {
        val m = width / 2f
        p.color = cor
        p.alpha = ((1f - fase) * 110f).toInt()
        c.drawCircle(m, m, m * (0.45f + 0.55f * fase), p)
        p.alpha = 255
        c.drawCircle(m, m, m * 0.38f, p)
    }
}
