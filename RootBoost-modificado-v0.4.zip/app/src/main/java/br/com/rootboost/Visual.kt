package br.com.rootboost

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.LinearGradient
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Shader
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.animation.LinearInterpolator
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import kotlin.math.abs

fun misturar(a: Int, b: Int, t: Float): Int {
    fun m(x: Int, y: Int) = x + ((y - x) * t).toInt()
    return Color.argb(
        m(Color.alpha(a), Color.alpha(b)), m(Color.red(a), Color.red(b)),
        m(Color.green(a), Color.green(b)), m(Color.blue(a), Color.blue(b))
    )
}

/** Ícones de traço desenhados em código (grade 24x24), sem imagens. */
class Icone(ctx: Context, private val tipo: String) : View(ctx) {
    var cor: Int = Cores.SUAVE
        set(v) { field = v; invalidate() }

    private val tr = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
        strokeWidth = 1.9f
    }
    private val pr = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }

    override fun onMeasure(w: Int, h: Int) {
        val t = context.dp(24)
        setMeasuredDimension(t, t)
    }

    override fun onDraw(c: Canvas) {
        tr.color = cor
        pr.color = cor
        c.save()
        val s = width / 24f
        c.scale(s, s)
        when (tipo) {
            "inicio" -> {
                c.drawArc(RectF(3f, 3f, 21f, 21f), 150f, 240f, false, tr)
                c.drawLine(12f, 12f, 16.5f, 7.5f, tr)
                c.drawCircle(12f, 12f, 1.5f, pr)
            }
            "jogos" -> {
                c.drawRoundRect(RectF(2.5f, 7f, 21.5f, 17.5f), 4.5f, 4.5f, tr)
                c.drawLine(7f, 10.2f, 7f, 14.3f, tr)
                c.drawLine(4.95f, 12.25f, 9.05f, 12.25f, tr)
                c.drawCircle(16f, 11.3f, 1f, pr)
                c.drawCircle(18.4f, 13.4f, 1f, pr)
            }
            "modulos" -> {
                c.drawRoundRect(RectF(4f, 4f, 10.5f, 10.5f), 1.8f, 1.8f, tr)
                c.drawRoundRect(RectF(13.5f, 4f, 20f, 10.5f), 1.8f, 1.8f, tr)
                c.drawRoundRect(RectF(4f, 13.5f, 10.5f, 20f), 1.8f, 1.8f, tr)
                c.drawRoundRect(RectF(13.5f, 13.5f, 20f, 20f), 1.8f, 1.8f, tr)
            }
            "ajustes" -> {
                c.drawLine(4f, 6f, 7f, 6f, tr); c.drawLine(11f, 6f, 20f, 6f, tr); c.drawCircle(9f, 6f, 2f, tr)
                c.drawLine(4f, 12f, 13f, 12f, tr); c.drawLine(17f, 12f, 20f, 12f, tr); c.drawCircle(15f, 12f, 2f, tr)
                c.drawLine(4f, 18f, 6f, 18f, tr); c.drawLine(10f, 18f, 20f, 18f, tr); c.drawCircle(8f, 18f, 2f, tr)
            }
            "info" -> {
                c.drawCircle(12f, 12f, 9f, tr)
                c.drawLine(12f, 11f, 12f, 16.5f, tr)
                c.drawCircle(12f, 7.8f, 1f, pr)
            }
            "fechar" -> {
                c.drawLine(6f, 6f, 18f, 18f, tr)
                c.drawLine(18f, 6f, 6f, 18f, tr)
            }
            "cpu" -> {
                c.drawRoundRect(RectF(6f, 6f, 18f, 18f), 2.2f, 2.2f, tr)
                c.drawRect(RectF(9.5f, 9.5f, 14.5f, 14.5f), tr)
                for (v in listOf(9f, 12f, 15f)) {
                    c.drawLine(v, 3f, v, 6f, tr); c.drawLine(v, 18f, v, 21f, tr)
                    c.drawLine(3f, v, 6f, v, tr); c.drawLine(18f, v, 21f, v, tr)
                }
            }
            "memoria" -> {
                val a = Path(); a.moveTo(12f, 4f); a.lineTo(20f, 8f); a.lineTo(12f, 12f); a.lineTo(4f, 8f); a.close()
                c.drawPath(a, tr)
                val b = Path(); b.moveTo(4f, 12f); b.lineTo(12f, 16f); b.lineTo(20f, 12f); c.drawPath(b, tr)
                val d = Path(); d.moveTo(4f, 16f); d.lineTo(12f, 20f); d.lineTo(20f, 16f); c.drawPath(d, tr)
            }
            "atualizar" -> {
                c.drawArc(RectF(4f, 4f, 20f, 20f), 40f, 270f, false, tr)
                val a = Path(); a.moveTo(13.5f, 5.9f); a.lineTo(17.1f, 5.9f); a.lineTo(17.1f, 2.3f)
                c.drawPath(a, tr)
            }
            "toque" -> {
                c.drawCircle(12f, 12f, 1.8f, pr)
                c.drawCircle(12f, 12f, 5.5f, tr)
                c.drawArc(RectF(2.5f, 2.5f, 21.5f, 21.5f), 200f, 140f, false, tr)
            }
            "wifi" -> {
                for (r in listOf(4.5f, 8.5f, 12.5f)) {
                    c.drawArc(RectF(12f - r, 19f - r, 12f + r, 19f + r), 228f, 84f, false, tr)
                }
                c.drawCircle(12f, 19f, 1.2f, pr)
            }
            "limpar" -> {
                val a = Path()
                a.moveTo(12f, 3f); a.lineTo(14f, 10f); a.lineTo(21f, 12f); a.lineTo(14f, 14f)
                a.lineTo(12f, 21f); a.lineTo(10f, 14f); a.lineTo(3f, 12f); a.lineTo(10f, 10f); a.close()
                c.drawPath(a, tr)
            }
            "terminal" -> {
                c.drawRoundRect(RectF(3f, 4f, 21f, 20f), 3f, 3f, tr)
                val a = Path(); a.moveTo(7f, 9f); a.lineTo(11f, 12f); a.lineTo(7f, 15f); c.drawPath(a, tr)
                c.drawLine(13f, 15.5f, 17f, 15.5f, tr)
            }
            "tela" -> {
                val a = Path(); a.moveTo(4f, 9f); a.lineTo(4f, 4f); a.lineTo(9f, 4f); c.drawPath(a, tr)
                val b = Path(); b.moveTo(15f, 4f); b.lineTo(20f, 4f); b.lineTo(20f, 9f); c.drawPath(b, tr)
                val d = Path(); d.moveTo(20f, 15f); d.lineTo(20f, 20f); d.lineTo(15f, 20f); c.drawPath(d, tr)
                val e = Path(); e.moveTo(9f, 20f); e.lineTo(4f, 20f); e.lineTo(4f, 15f); c.drawPath(e, tr)
            }
            "cor" -> {
                c.drawCircle(12f, 12f, 9f, tr)
                c.drawArc(RectF(3f, 3f, 21f, 21f), 270f, 180f, true, pr)
            }
            "fps" -> {
                val a = Path()
                a.moveTo(3f, 13f); a.lineTo(7f, 13f); a.lineTo(9.5f, 6f); a.lineTo(13f, 19f)
                a.lineTo(15.5f, 11f); a.lineTo(17f, 13f); a.lineTo(21f, 13f)
                c.drawPath(a, tr)
            }
            "sino" -> {
                val a = Path()
                a.moveTo(7f, 17f); a.lineTo(7f, 10f); a.arcTo(RectF(7f, 5f, 17f, 15f), 180f, 180f, false)
                a.lineTo(17f, 17f); a.close()
                c.drawPath(a, tr)
                c.drawLine(5f, 17f, 19f, 17f, tr)
                c.drawArc(RectF(10f, 18f, 14f, 22f), 0f, 180f, false, tr)
            }
            "raio" -> {
                val p = Path()
                p.moveTo(13.5f, 2.5f); p.lineTo(5.5f, 13.5f); p.lineTo(11f, 13.5f)
                p.lineTo(10f, 21.5f); p.lineTo(18.5f, 10f); p.lineTo(13f, 10f); p.close()
                c.drawPath(p, pr)
            }
        }
        c.restore()
    }
}

/** Medidor em arco com valor no centro. */
class Medidor(ctx: Context) : View(ctx) {
    var rotulo = ""
    var unidade = ""
    private var texto = "—"
    private var cor = Cores.ACENTO
    private var atual = 0f
    private var anim: ValueAnimator? = null

    private val trilha = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        color = Cores.LINHA
    }
    private val arco = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
    }
    private val num = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textAlign = Paint.Align.CENTER
        color = Cores.TEXTO
        typeface = FonteMedia
    }
    private val leg = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textAlign = Paint.Align.CENTER
        color = Cores.SUAVE
    }
    private val area = RectF()

    fun definir(frac: Float, valor: String, c: Int = Cores.ACENTO) {
        texto = valor
        cor = c
        val alvo = frac.coerceIn(0f, 1f)
        anim?.cancel()
        val a = ValueAnimator.ofFloat(atual, alvo)
        a.duration = 450
        a.addUpdateListener { atual = it.animatedValue as Float; invalidate() }
        anim = a
        a.start()
    }

    override fun onMeasure(w: Int, h: Int) {
        val tam = if (MeasureSpec.getMode(w) == MeasureSpec.UNSPECIFIED) context.dp(88) else MeasureSpec.getSize(w)
        setMeasuredDimension(tam, tam)
    }

    override fun onDraw(c: Canvas) {
        val s = minOf(width, height).toFloat()
        val esp = s * 0.07f
        trilha.strokeWidth = esp
        arco.strokeWidth = esp
        arco.color = cor
        area.set(esp, esp, s - esp, s - esp)
        c.drawArc(area, 135f, 270f, false, trilha)
        if (atual > 0.001f) c.drawArc(area, 135f, 270f * atual, false, arco)
        num.textSize = s * 0.26f
        c.drawText(texto, s / 2f, s * 0.57f, num)
        leg.textSize = s * 0.12f
        c.drawText(rotulo, s / 2f, s * 0.34f, leg)
        c.drawText(unidade, s / 2f, s * 0.76f, leg)
    }
}

/** Interruptor próprio (faixa + bolinha animada). */
class Chave(ctx: Context) : View(ctx) {
    var aoMudar: ((Boolean) -> Unit)? = null
    private var marcado = false
    private var t = 0f
    private var anim: ValueAnimator? = null
    private val faixa = Paint(Paint.ANTI_ALIAS_FLAG)
    private val bola = Paint(Paint.ANTI_ALIAS_FLAG)

    init {
        isClickable = true
        setOnClickListener {
            definir(!marcado, true)
            aoMudar?.invoke(marcado)
        }
    }

    fun estaMarcado(): Boolean = marcado

    fun somenteExibir() {
        setOnClickListener(null)
        isClickable = false
    }

    fun definir(v: Boolean, animar: Boolean = false) {
        marcado = v
        anim?.cancel()
        if (animar) {
            val a = ValueAnimator.ofFloat(t, if (v) 1f else 0f)
            a.duration = 160
            a.addUpdateListener { t = it.animatedValue as Float; invalidate() }
            anim = a
            a.start()
        } else {
            t = if (v) 1f else 0f
            invalidate()
        }
    }

    override fun onMeasure(w: Int, h: Int) {
        setMeasuredDimension(context.dp(46), context.dp(28))
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        faixa.color = misturar(0xFF3A3E48.toInt(), Cores.ACENTO, t)
        c.drawRoundRect(0f, 0f, w, h, h / 2f, h / 2f, faixa)
        val r = h / 2f - context.dp(3)
        val cx = h / 2f + (w - h) * t
        bola.color = misturar(0xFFB4B9C4.toInt(), Color.WHITE, t)
        c.drawCircle(cx, h / 2f, r, bola)
    }
}

/** Controle segmentado (ex.: Economia | Equilibrado | Performance | Gaming). */
class Segmentado(ctx: Context, opcoes: List<String>, sp: Float = 13f) : LinearLayout(ctx) {
    var aoEscolher: ((Int) -> Unit)? = null
    private val itens = ArrayList<TextView>()

    init {
        orientation = HORIZONTAL
        val d = context.dp(3)
        setPadding(d, d, d, d)
        background = context.forma(Cores.SUPERFICIE2, 14)
        for (i in opcoes.indices) {
            val t = TextView(context)
            t.text = opcoes[i]
            t.textSize = sp
            t.gravity = android.view.Gravity.CENTER
            t.typeface = FonteMedia
            t.setPadding(0, context.dp(10), 0, context.dp(10))
            t.setTextColor(Cores.SUAVE)
            t.setOnClickListener {
                definir(i)
                aoEscolher?.invoke(i)
            }
            addView(t, LayoutParams(0, AUTO, 1f))
            itens.add(t)
        }
    }

    /** Marca a opção i (use -1 para nenhuma). */
    fun definir(i: Int) {
        for (k in itens.indices) {
            val t = itens[k]
            if (k == i) {
                t.background = context.forma(Cores.ACENTO, 11)
                t.setTextColor(Color.WHITE)
            } else {
                t.background = null
                t.setTextColor(Cores.SUAVE)
            }
        }
    }
}


fun Context.caixaIcone(tipo: String): FrameLayout {
    val f = FrameLayout(this)
    f.background = forma(Cores.SUPERFICIE2, 12, Cores.LINHA, 1)
    val ic = Icone(this, tipo)
    ic.cor = Cores.ACENTO
    f.addView(ic, FrameLayout.LayoutParams(AUTO, AUTO, Gravity.CENTER))
    return f
}

fun Context.botaoInfo(aoClicar: () -> Unit): FrameLayout {
    val f = FrameLayout(this)
    val ic = Icone(this, "info")
    ic.cor = Cores.SUAVE
    f.addView(ic, FrameLayout.LayoutParams(AUTO, AUTO, Gravity.CENTER))
    f.setOnClickListener { aoClicar() }
    return f
}

/** Gráfico de linha que rola sozinho a cada nova amostra (monitor em tempo real). */
class Grafico(ctx: Context) : View(ctx) {
    var rotulo = ""
    var maximo = 100f
    private var valorTexto = "—"
    private var corLinha = Cores.ACENTO
    private val pontos = ArrayList<Float>()
    private val capacidade = 36
    private var fase = 1f
    private var anim: ValueAnimator? = null
    private val linha = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
    }
    private val preench = Paint(Paint.ANTI_ALIAS_FLAG)
    private val grade = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Cores.LINHA; strokeWidth = 1f }
    private val tRot = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Cores.SUAVE }
    private val tVal = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Cores.TEXTO
        typeface = FonteMedia
        textAlign = Paint.Align.RIGHT
    }
    private val caminho = Path()
    private val area = Path()

    fun definirCor(c: Int) {
        corLinha = c
        refazerShader()
        invalidate()
    }

    private fun refazerShader() {
        if (height <= 0) return
        val topo = (corLinha and 0x00FFFFFF) or 0x66000000
        preench.shader = LinearGradient(0f, height * 0.3f, 0f, height.toFloat(), topo, Color.TRANSPARENT, Shader.TileMode.CLAMP)
    }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        super.onSizeChanged(w, h, ow, oh)
        refazerShader()
    }

    fun adicionar(v: Float, texto: String) {
        valorTexto = texto
        pontos.add(v.coerceAtLeast(0f))
        while (pontos.size > capacidade + 1) pontos.removeAt(0)
        anim?.cancel()
        val a = ValueAnimator.ofFloat(0f, 1f)
        a.duration = 900
        a.interpolator = LinearInterpolator()
        a.addUpdateListener { fase = it.animatedValue as Float; invalidate() }
        anim = a
        a.start()
    }

    override fun onMeasure(w: Int, h: Int) {
        setMeasuredDimension(MeasureSpec.getSize(w), context.dp(92))
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val d = context.dp(1).toFloat()
        val topo = h * 0.36f
        val base = h - 4f * d
        for (i in 0..2) {
            val y = topo + (base - topo) * i / 2f
            c.drawLine(0f, y, w, y, grade)
        }
        tRot.textSize = h * 0.13f
        c.drawText(rotulo, 10f * d, h * 0.22f, tRot)
        tVal.textSize = h * 0.22f
        c.drawText(valorTexto, w - 10f * d, h * 0.25f, tVal)
        if (pontos.size < 2) return
        val passo = w / (capacidade - 1).toFloat()
        caminho.reset()
        area.reset()
        var px = 0f
        var py = 0f
        for (i in pontos.indices) {
            val x = (i - fase) * passo
            val frac = (pontos[i] / maximo).coerceIn(0f, 1f)
            val y = base - (base - topo) * frac
            if (i == 0) {
                caminho.moveTo(x, y)
                area.moveTo(x, base)
                area.lineTo(x, y)
            } else {
                val mx = (px + x) / 2f
                caminho.cubicTo(mx, py, mx, y, x, y)
                area.cubicTo(mx, py, mx, y, x, y)
            }
            px = x
            py = y
        }
        area.lineTo(px, base)
        area.close()
        c.drawPath(area, preench)
        linha.color = corLinha
        linha.strokeWidth = 2f * d
        c.drawPath(caminho, linha)
    }
}

/** Controle deslizante com paradas fixas (ex.: Off, 60, 90, 120). */
class Passos(ctx: Context, private val rotulos: List<String>) : View(ctx) {
    var indice = 0
        private set
    var aoSoltar: ((Int) -> Unit)? = null
    private var posAnim = 0f
    private var anim: ValueAnimator? = null
    private val pFaixa = Paint(Paint.ANTI_ALIAS_FLAG).apply { strokeCap = Paint.Cap.ROUND }
    private val pBola = Paint(Paint.ANTI_ALIAS_FLAG)
    private val pTexto = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textAlign = Paint.Align.CENTER
        typeface = FonteMedia
    }

    fun definir(i: Int, animar: Boolean = false) {
        indice = i.coerceIn(0, rotulos.size - 1)
        mover(indice.toFloat(), animar)
    }

    private fun mover(alvo: Float, animar: Boolean) {
        anim?.cancel()
        if (animar) {
            val a = ValueAnimator.ofFloat(posAnim, alvo)
            a.duration = 160
            a.addUpdateListener { posAnim = it.animatedValue as Float; invalidate() }
            anim = a
            a.start()
        } else {
            posAnim = alvo
            invalidate()
        }
    }

    override fun onMeasure(w: Int, h: Int) {
        setMeasuredDimension(MeasureSpec.getSize(w), context.dp(64))
    }

    private fun xDe(i: Float): Float {
        val p = context.dp(22).toFloat()
        return p + i * (width - 2f * p) / (rotulos.size - 1).toFloat()
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.action) {
            MotionEvent.ACTION_DOWN -> {
                parent?.requestDisallowInterceptTouchEvent(true)
                escolher(e.x)
            }
            MotionEvent.ACTION_MOVE -> escolher(e.x)
            MotionEvent.ACTION_UP -> aoSoltar?.invoke(indice)
        }
        return true
    }

    private fun escolher(x: Float) {
        var melhor = 0
        var dist = Float.MAX_VALUE
        for (i in rotulos.indices) {
            val d = abs(xDe(i.toFloat()) - x)
            if (d < dist) {
                dist = d
                melhor = i
            }
        }
        if (melhor != indice) {
            indice = melhor
            mover(melhor.toFloat(), true)
        }
    }

    override fun onDraw(c: Canvas) {
        val d = context.dp(1).toFloat()
        pTexto.textSize = 13f * d
        for (i in rotulos.indices) {
            pTexto.color = if (i == indice) Cores.ACENTO else Cores.SUAVE
            c.drawText(rotulos[i], xDe(i.toFloat()), 22f * d, pTexto)
        }
        val y = 44f * d
        pFaixa.strokeWidth = 2f * d
        pFaixa.color = Cores.LINHA
        c.drawLine(xDe(0f), y, xDe((rotulos.size - 1).toFloat()), y, pFaixa)
        pFaixa.color = Cores.ACENTO
        c.drawLine(xDe(0f), y, xDe(posAnim), y, pFaixa)
        pBola.color = Cores.ACENTO
        c.drawCircle(xDe(posAnim), y, 9f * d, pBola)
        pBola.color = Cores.SUPERFICIE
        c.drawCircle(xDe(posAnim), y, 3.5f * d, pBola)
    }
}
