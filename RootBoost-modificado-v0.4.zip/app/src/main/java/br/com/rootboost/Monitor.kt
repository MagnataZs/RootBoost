package br.com.rootboost

import android.content.Context

/** Enquanto um jogo está aberto: mede o FPS a cada segundo e aplica o anti-queda quando preciso. */
object Monitor {
    @Volatile private var ativo = false
    private var fio: Thread? = null

    fun iniciar(ctx: Context, pkg: String) {
        if (ativo) return
        ativo = true
        Fps.limpar()
        val app = ctx.applicationContext
        fio = Thread { laco(app, pkg) }.also { it.start() }
    }

    fun parar() {
        ativo = false
        fio?.interrupt()
        fio = null
        Fps.limpar()
    }

    private fun laco(ctx: Context, pkg: String) {
        var proximoImpulso = 0L
        try {
            while (ativo) {
                val anti = Prefs.modAtivo(ctx, "antiqueda")
                if (Prefs.fpsOn(ctx) || Prefs.painelNoJogo(ctx) || anti) {
                    val m = Fps.medir(pkg)
                    Fps.atual = m
                    if (m != null) Fps.registrar(m.fps)
                    if (anti && m != null) {
                        val h = Fps.historico()
                        if (h.size >= 14) {
                            val ref = h.subList(h.size - 14, h.size - 3).average()
                            val agora = h[h.size - 1]
                            val t = System.currentTimeMillis()
                            if (ref >= 25.0 && agora < ref * 0.72 && t > proximoImpulso) {
                                proximoImpulso = t + 15000L
                                Thread { Tuner.impulso(ctx) }.start()
                            }
                        }
                    }
                }
                Thread.sleep(1000)
            }
        } catch (e: InterruptedException) {
            // parou
        }
    }
}
