package br.com.rootboost

import android.content.Context
import java.util.Locale

/** Ajuste de cor da tela (saturação, contraste, brilho e ganho RGB) via SurfaceFlinger. */
object Cor {
    class Ajuste(val sat: Float, val con: Float, val bri: Float, val r: Float, val g: Float, val b: Float)
    class Preset(val id: String, val nome: String, val ajuste: Ajuste, val amostra: Int)

    val ORIGINAL = Ajuste(1f, 1f, 0f, 1f, 1f, 1f)

    val presets = listOf(
        Preset("original", "Original", ORIGINAL, 0xFF8D93A0.toInt()),
        Preset("vivo", "Vivo", Ajuste(1.35f, 1.06f, 0f, 1f, 1f, 1f), 0xFFFF5B1F.toInt()),
        Preset("cinema", "Cinema", Ajuste(1.12f, 1.14f, -0.02f, 1.03f, 1f, 0.95f), 0xFFC9A66B.toInt()),
        Preset("competitivo", "Competitivo", Ajuste(1.25f, 1.22f, 0.02f, 1f, 1f, 1f), 0xFF4CD9A0.toInt()),
        Preset("suave", "Suave", Ajuste(0.9f, 0.96f, 0.01f, 1f, 1f, 1f), 0xFF8FB7FF.toInt()),
        Preset("noite", "Noite", Ajuste(1f, 1f, -0.03f, 1f, 0.92f, 0.76f), 0xFFFFB347.toInt())
    )

    private fun lerF(ctx: Context, k: String, padrao: Float): Float =
        Prefs.str(ctx, k, padrao.toString()).toFloatOrNull() ?: padrao

    fun salvo(ctx: Context): Ajuste = Ajuste(
        lerF(ctx, "cor_sat", 1f), lerF(ctx, "cor_con", 1f), lerF(ctx, "cor_bri", 0f),
        lerF(ctx, "cor_r", 1f), lerF(ctx, "cor_g", 1f), lerF(ctx, "cor_b", 1f)
    )

    fun salvar(ctx: Context, a: Ajuste) {
        Prefs.putStr(ctx, "cor_sat", a.sat.toString())
        Prefs.putStr(ctx, "cor_con", a.con.toString())
        Prefs.putStr(ctx, "cor_bri", a.bri.toString())
        Prefs.putStr(ctx, "cor_r", a.r.toString())
        Prefs.putStr(ctx, "cor_g", a.g.toString())
        Prefs.putStr(ctx, "cor_b", a.b.toString())
    }

    private fun f(v: Float): String = String.format(Locale.US, "%.3f", v)

    fun aplicar(a: Ajuste): String {
        val dr = a.con * a.r
        val dg = a.con * a.g
        val db = a.con * a.b
        val t = 0.5f * (1f - a.con) + a.bri
        // matriz 4x4 em colunas: ganho nas diagonais, deslocamento na última coluna
        val matriz = "service call SurfaceFlinger 1015 i32 1 " +
            "f ${f(dr)} f 0 f 0 f 0 " +
            "f 0 f ${f(dg)} f 0 f 0 " +
            "f 0 f 0 f ${f(db)} f 0 " +
            "f ${f(t)} f ${f(t)} f ${f(t)} f 1"
        val sat = "service call SurfaceFlinger 1022 f ${f(a.sat)}"
        RootShell.run(matriz + "\n" + sat) ?: return "Sem acesso root."
        return "Cores aplicadas."
    }
}
