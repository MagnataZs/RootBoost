# RootBoost 0.4

Painel de desempenho com root e Game Turbo. Código-fonte ainda **não compilado nem testado em aparelho**:
se o build der erro, mande o log para corrigir.

## Abas
- **Início**: modo automático, monitor ao vivo (CPU, GPU, RAM, temperatura), perfis, contador de FPS, painel no jogo e atalhos.
- **Jogos**: lista de jogos, cada um com o seu perfil.
- **Desempenho**: resolução (DPI), taxa de atualização, módulos (animações, memória, prioridade da CPU, disco, anti-queda de FPS) e CPU manual.
- **Gráficos**: shaders prontos e ajuste manual (saturação, contraste, brilho, RGB), renderizador e driver gráfico.
- **Avançado**: terminal root, Smart Cache Cleaner, Smart App Killer, Lightning Touch, Wi-Fi, Não perturbe, diagnóstico.

## Dentro do jogo
- **Contador de FPS** real (SurfaceFlinger), com gráfico, 1% low e tempo de quadro.
- **Painel** com medidores animados, perfis, módulos e dados da sessão.

## Segurança
- Valores originais guardados e restaurados ao sair do jogo. Não desativa limites térmicos.
- Reiniciar o aparelho também devolve tudo ao padrão.
