# RootBoost 0.6

Painel de desempenho com root e Game Turbo. Código-fonte ainda **não compilado nem testado em aparelho**:
se o build der erro, mande o log para corrigir.

## O que mudou na 0.6
- **Painel do Game Turbo redesenhado** (dentro do jogo): cabeçalho com marca, wifi, bateria e hora; menu lateral com legendas;
  quatro cartões (CPU, GPU, RAM, FPS) com anel em degradê, variação (↑/↓ %) e mini-gráfico das últimas leituras;
  botões "Abrir app" e "Voltar ao jogo". Em tela deitada os cartões ficam em linha; em pé, em grade 2 x 2.
- Perfis, GPU Adreno e núcleos da CPU continuam no painel, logo abaixo dos cartões (role para ver).
- Engrenagem do menu abre a lista de jogos. Paleta azul/roxa só no painel do jogo; o resto do app segue igual.

## O que mudou na 0.5
- **Free Fire sem overlay**: nenhum jogo marcado como "sem overlay" recebe contador de FPS, painel ou medidor por cima
  (Free Fire e Free Fire MAX já vêm assim). Muda por jogo: Jogos > toque no jogo > botão "Overlay".
  O RootBoost não escreve em nenhum arquivo, pasta, APK ou processo de jogo; só ajusta o sistema.
- **Contador de FPS menor**: pílula de 68×24 dp; um toque abre a versão com gráfico e 1% low.
- **Visual novo**: paleta mais suave, cartões em degradê, animações mais lentas e macias, caixinhas para cada função.
- **Núcleos da CPU em tempo real**: uma barra por núcleo, com seta de subida/descida (também no painel do jogo).
- **GPU Adreno**: governor, frequência mínima e máxima (lidas do kernel), Adreno Boost (se o kernel expõe),
  atalho "Automática / Alta / Máxima" no painel do jogo e Adreno Boost como módulo.
- **Proteger chamadas**: Discord, WhatsApp, Telegram, Meet etc. ficam por último na fila do sistema para serem fechados,
  e a limpeza de RAM e o Smart App Killer pulam esses apps.
- **Apps rápidos**: abre um app escolhido em janela flutuante por cima do jogo (precisa de ROM com janelas livres;
  senão abre em tela cheia). Abrir um app rápido não encerra a sessão do Game Turbo.
- **Novos módulos**: Adreno Boost, Leitura antecipada do disco (carregamento), Sem avisos na tela, Brilho fixo.
- **Anti-queda de FPS** agora também sobe a GPU por alguns segundos.
- **Limpar RAM** não descarta mais o cache de arquivos ao abrir o jogo (isso atrasava o carregamento).

## Abas
- **Início**: modo automático, monitor ao vivo, núcleos da CPU, funções em caixinhas, perfis, FPS, painel no jogo, apps rápidos e atalhos.
- **Jogos**: lista de jogos, cada um com o seu perfil e a opção de overlay.
- **Desempenho**: resolução (DPI), taxa de atualização, módulos, GPU Adreno e CPU manual.
- **Gráficos**: shaders prontos e ajuste manual, renderizador e driver gráfico.
- **Avançado**: terminal root, Smart Cache Cleaner, Smart App Killer, Lightning Touch, Wi-Fi, Não perturbe, diagnóstico.

## Segurança
- Valores originais guardados e restaurados ao sair do jogo. Não desativa limites térmicos.
- Reiniciar o aparelho também devolve tudo ao padrão.
