# RootBoost 0.2

Painel de desempenho com root e **Game Turbo**. Código-fonte: ainda **não foi compilado nem testado em aparelho**.
Se o build der erro, mande o log para corrigir.

## O que faz
- **Perfis** (Economia, Equilibrado, Performance, Gaming): governor e frequência da CPU pelo `/sys/.../cpufreq`
  (lê o que o aparelho oferece) e, no Gaming, governor/frequência mínima da GPU (kgsl/devfreq) quando existir.
- **Game Turbo**: serviço que vê qual app está em primeiro plano e aplica o Gaming quando abre um jogo da sua lista;
  volta ao perfil escolhido quando você sai. Opção de limpar a RAM ao abrir o jogo.
- **Painel flutuante** com CPU, temperatura e RAM reais (arraste para mover).
- **Ferramentas**: limpar RAM, fstrim, saturação da tela, restaurar valores originais.

## Segurança
- Os valores originais são guardados (uma vez por boot) antes de qualquer alteração e voltam em "Restaurar".
- Não desativa limites térmicos nem serviços de proteção.
- Reiniciar o aparelho também devolve tudo ao padrão.

## Compilar sem PC (GitHub Actions)
1. Crie um repositório no GitHub e suba todos os arquivos deste projeto.
   Confirme que existe `.github/workflows/build.yml` (se o upload ignorar a pasta, crie o arquivo à mão em
   *Add file > Create new file* com esse caminho e cole o conteúdo).
2. Aba **Actions** > **Build APK** > **Run workflow** (ou basta dar push).
3. Quando terminar, abra a execução e baixe o artefato **RootBoost-debug-apk**. Dentro do zip está o `app-debug.apk`.

## Compilar no Android Studio
JDK 17, Android SDK Platform 35. Abra a pasta, sincronize o Gradle e use *Build > Build APK*.
