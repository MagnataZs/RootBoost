# RootBoost 0.8.0

Painel de desempenho com root e Game Turbo. Código-fonte ainda **não compilado nem testado em aparelho**:
se o build der erro, mande o log para corrigir.

## O que mudou na 0.8.0
- **Layout do app de volta ao padrão** (Início, Jogos, Desempenho, Gráficos, Avançado), só com as cores novas. As funções ficam todas na grade do Início (ícone, ⓘ e "ligar agora"), sem repetir em outras abas.
- **Funções que conferem se pegaram**: cada ajuste do kernel é lido de volta; o app só diz "ligado" se o sistema aceitou. "Já está no melhor valor" (disco, leitura antecipada) não é mais falha. Na primeira abertura de cada boot o app testa o aparelho e marca como "Indisponível aqui" o que ele não tem, com o motivo.
- **Chips Mali / MediaTek**: Boost da GPU Mali / MediaTek (devfreq e controles do GED), leitura de uso e clock da GPU Mali / MediaTek, e o Adreno Boost só aparece em chips Adreno.
- **Modo emulador** (Winlator, GameHub, ARMSX2, NetherSX2, PPSSPP, Dolphin e outros; detectado pelo nome ou escolhido na tela do jogo): sobe CPU/GPU, libera RAM, encerra apps de fundo, acelera o disco e liga o desempenho sustentado.
- **Funções novas**: Desempenho sustentado, Dados em segundo plano, Sem buscas de Wi‑Fi e Bluetooth, Sem economia de bateria.
- **Jogos pesados**: Honor of Kings, Genshin, Honkai, Zenless, Wuthering Waves, Warzone Mobile, Diablo Immortal, Asphalt 9, EA FC e outros; "Aplicar sugestão" também liga as funções certas para cada tipo de jogo.
- Aba Sessão do painel do jogo com o ícone do jogo e os ícones dos seus jogos.

## O que mudou na 0.7.1
- **Modo seguro** (desligado por padrão; liga por jogo na tela do jogo): o RootBoost não desenha nada por cima do jogo, deixa renderizador e driver gráfico no padrão enquanto ele está aberto, não faz medições e não aplica resolução/FPS/driver por jogo. Só entram o perfil de CPU/GPU, as funções do sistema e o filtro de cor. O RootBoost nunca toca na memória, nos arquivos ou no processo do jogo.
- Navegação do app de volta para baixo, como era antes.

## O que mudou na 0.7
- **App com o mesmo visual do Game Turbo**: menu lateral (Turbo, Jogos, Funções, Tela, Sistema), cartões neon e fonte condensada nos títulos.
- **Sem funções duplicadas**: todas as funções ficam só na aba Funções (cada uma com ícone, ⓘ explicando o que faz, chave "ao abrir o jogo" e "Ligar agora").
- **Filtros de imagem** (aba Tela e painel do jogo): galeria com prévia, força Sutil/Normal/Forte, pad de saturação x contraste, tom frio/quente e brilho com − e +. Sem barras deslizantes.
- **Ajustes por jogo** (aba Jogos): perfil, resolução, FPS alvo, modo jogo do sistema, driver (Game Driver/ANGLE), filtro de cor e funções próprias. Sugestões prontas para vários jogos conhecidos.
- **Painel do jogo**: abas Funções (com ⓘ) e Filtros; a alça arrasta para qualquer lugar e gruda na borda mais perto; novo tamanho de janela dos apps rápidos (pequena, média, grande) e a janela é redimensionada ao abrir.
- Contador de FPS com visual novo; crédito do criador (Diparis / MagnataZs).

## O que mudou na 0.6
- **Painel do Game Turbo redesenhado** (dentro do jogo): cabeçalho com marca, wifi, bateria e hora; menu lateral com legendas;
  quatro cartões (CPU, GPU, RAM, FPS) com anel em degradê, variação (↑/↓ %) e mini-gráfico das últimas leituras;
  botões "Abrir app" e "Voltar ao jogo". Em tela deitada os cartões ficam em linha; em pé, em grade 2 x 2.
- Perfis, GPU Adreno e núcleos da CPU continuam no painel, logo abaixo dos cartões (role para ver).
- Engrenagem do menu abre a lista de jogos. Paleta azul/roxa só no painel do jogo; o resto do app segue igual.

## O que mudou na 0.5
- **Free Fire sem overlay**: nenhum jogo marcado como "sem overlay" recebe contador de FPS, painel ou medidor por cima
  (Free Fire e Free Fire MAX já vêm assim). Muda por jogo: Jogos > toque no jogo > botão "Overlay".
  O RootBoost não escreve em nenhum arquivo, pasta, APK ou processo de jogo; só ajusta o sistema.
- **Contador de FPS menor**: pílula de 68×24 dp; um toque abre a versão com gráfico e 1% low.
- **Visual novo**: paleta mais suave, cartões em degradê, animações mais lentas e macias, caixinhas para cada função.
- **Núcleos da CPU em tempo real**: uma barra por núcleo, com seta de subida/descida (também no painel do jogo).
- **GPU Adreno**: governor, frequência mínima e máxima (lidas do kernel), Adreno Boost (se o kernel expõe),
  atalho "Automática / Alta / Máxima" no painel do jogo e Adreno Boost como módulo.
- **Proteger chamadas**: Discord, WhatsApp, Telegram, Meet etc. ficam por último na fila do sistema para serem fechados,
  e a limpeza de RAM e o Smart App Killer pulam esses apps.
- **Apps rápidos**: abre um app escolhido em janela flutuante por cima do jogo (precisa de ROM com janelas livres;
  senão abre em tela cheia). Abrir um app rápido não encerra a sessão do Game Turbo.
- **Novos módulos**: Adreno Boost, Leitura antecipada do disco (carregamento), Sem avisos na tela, Brilho fixo.
- **Anti-queda de FPS** agora também sobe a GPU por alguns segundos.
- **Limpar RAM** não descarta mais o cache de arquivos ao abrir o jogo (isso atrasava o carregamento).

## Abas
- **Início**: modo automático, monitor ao vivo, núcleos da CPU, funções em caixinhas, perfis, FPS, painel no jogo, apps rápidos e atalhos.
- **Jogos**: lista de jogos, cada um com o seu perfil e a opção de overlay.
- **Desempenho**: resolução (DPI), taxa de atualização, módulos, GPU Adreno e CPU manual.
- **Gráficos**: shaders prontos e ajuste manual, renderizador e driver gráfico.
- **Avançado**: terminal root, Smart Cache Cleaner, Smart App Killer, Lightning Touch, Wi-Fi, Não perturbe, diagnóstico.

## Segurança
- Valores originais guardados e restaurados ao sair do jogo. Não desativa limites térmicos.
- Reiniciar o aparelho também devolve tudo ao padrão.
