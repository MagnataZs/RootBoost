package br.com.rootboost

import android.animation.ValueAnimator
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.RectF
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import java.util.Locale

/** Contador de FPS: número grande animado, gráfico dos últimos segundos, 1% low e tempo de quadro. */
class FpsView(ctx: Context) : View(ctx) {
    private var exibido = 0f
    private var anim: ValueAnimator? = null
    private var alvo = 60f
    private var baixo1 = 0f
    private var frameMs = 0f
    private var hist: List<Float> = emptyList()

    private val fundo = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xE60A0E1B.toInt() }
    private val borda = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        color = Neon.BORDA
    }
    private val num = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        typeface = FonteTitulo
        color = Neon.TEXTO
    }
    private val leg = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Neon.SUAVE }
    private val linha = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
    }
    private val barra = Paint(Paint.ANTI_ALIAS_FLAG)
    private val caminho = Path()
    private val ret = RectF()

    fun atualizar(m: Fps.Medida?, h: List<Float>) {
        hist = h
        baixo1 = m?.baixo1 ?: 0f
        frameMs = m?.frameMs ?: 0f
        alvo = maxOf(30f, h.maxOrNull() ?: 0f)
        anim?.cancel()
        val a = ValueAnimator.ofFloat(exibido, m?.fps ?: 0f)
        a.duration = 600
        a.interpolator = android.view.animation.DecelerateInterpolator()
        a.addUpdateListener { exibido = it.animatedValue as Float; invalidate() }
        anim = a
        a.start()
    }

    /** Compacto por padrão (uma pílula pequena); um toque abre a versão com gráfico e 1% low. */
    var detalhado = false
        set(v) { field = v; requestLayout(); invalidate() }

    override fun onMeasure(w: Int, h: Int) {
        if (detalhado) setMeasuredDimension(context.dp(132), context.dp(46))
        else setMeasuredDimension(context.dp(68), context.dp(24))
    }

    override fun onDraw(c: Canvas) {
        val d = context.dp(1).toFloat()
        val w = width.toFloat()
        val h = height.toFloat()
        ret.set(d, d, w - d, h - d)
        val raio = h * (if (detalhado) 0.3f else 0.5f)
        fundo.color = 0xCC0A0E1B.toInt()
        c.drawRoundRect(ret, raio, raio, fundo)

        val razao = if (alvo > 0f) exibido / alvo else 0f
        val cor = when {
            exibido < 1f -> Cores.SUAVE
            razao >= 0.9f -> Cores.OK
            razao >= 0.6f -> Cores.AMBAR
            else -> Cores.ERRO
        }
        barra.color = cor
        // a borda ganha a cor do estado (verde bom, âmbar médio, vermelho ruim)
        borda.color = comAlfa(cor, 0x99)
        borda.strokeWidth = d
        c.drawRoundRect(ret, raio, raio, borda)

        if (!detalhado) {
            barra.alpha = 70
            c.drawCircle(h * 0.5f, h * 0.5f, h * 0.30f, barra)
            barra.alpha = 255
            c.drawCircle(h * 0.5f, h * 0.5f, h * 0.14f, barra)
            num.textSize = h * 0.6f
            val txt = Math.round(exibido).toString()
            val x = h * 0.82f
            c.drawText(txt, x, h * 0.74f, num)
            leg.textSize = h * 0.36f
            c.drawText("FPS", x + num.measureText(txt) + 3f * d, h * 0.72f, leg)
            return
        }

        ret.set(8f * d, h * 0.2f, 10.5f * d, h * 0.8f)
        c.drawRoundRect(ret, 2f * d, 2f * d, barra)
        num.textSize = h * 0.5f
        c.drawText(Math.round(exibido).toString(), 16f * d, h * 0.56f, num)
        leg.textSize = h * 0.2f
        c.drawText("FPS", 17f * d, h * 0.86f, leg)

        val x0 = w * 0.47f
        val x1 = w - 9f * d
        val y0 = h * 0.18f
        val y1 = h * 0.58f
        val n = minOf(hist.size, 30)
        if (n >= 2) {
            val ini = hist.size - n
            val passo = (x1 - x0) / (n - 1).toFloat()
            caminho.reset()
            for (i in 0 until n) {
                val v = hist[ini + i]
                val x = x0 + i * passo
                val y = y1 - (y1 - y0) * (v / alvo).coerceIn(0f, 1f)
                if (i == 0) caminho.moveTo(x, y) else caminho.lineTo(x, y)
            }
            linha.color = cor
            linha.strokeWidth = 1.6f * d
            c.drawPath(caminho, linha)
        }
        leg.textSize = h * 0.19f
        c.drawText(String.format(Locale.US, "1%% %d · %dms", Math.round(baixo1), Math.round(frameMs)), x0, h * 0.86f, leg)
    }
}

class FpsService : Service() {

    private var wm: WindowManager? = null
    private var vista: FpsView? = null
    private val main = Handler(Looper.getMainLooper())
    @Volatile private var ativo = false

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (!Settings.canDrawOverlays(this)) { stopSelf(); return START_NOT_STICKY }
        if (vista != null) return START_NOT_STICKY

        val gerente = getSystemService(WINDOW_SERVICE) as WindowManager
        wm = gerente
        val v = FpsView(this)
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        )
        params.gravity = Gravity.TOP or Gravity.END
        params.x = dp(10)
        params.y = dp(8)

        v.detalhado = Prefs.bool(this, "fps_detalhado", false)
        var ix = 0
        var iy = 0
        var tx = 0f
        var ty = 0f
        var moveu = false
        v.setOnTouchListener { view, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { ix = params.x; iy = params.y; tx = e.rawX; ty = e.rawY; moveu = false }
                MotionEvent.ACTION_MOVE -> {
                    if (Math.abs(e.rawX - tx) > dp(6) || Math.abs(e.rawY - ty) > dp(6)) moveu = true
                    if (moveu) {
                        // gravity END: arrastar para a esquerda aumenta x
                        params.x = ix - (e.rawX - tx).toInt()
                        params.y = iy + (e.rawY - ty).toInt()
                        gerente.updateViewLayout(view, params)
                    }
                }
                MotionEvent.ACTION_UP -> if (!moveu) {
                    val fps = view as FpsView
                    fps.detalhado = !fps.detalhado
                    Prefs.putBool(this, "fps_detalhado", fps.detalhado)
                    gerente.updateViewLayout(view, params)
                }
            }
            true
        }
        gerente.addView(v, params)
        vista = v

        ativo = true
        Thread {
            while (ativo) {
                val m = Fps.atual
                val h = Fps.historico()
                main.post { vista?.atualizar(m, h) }
                try {
                    Thread.sleep(1000)
                } catch (e: InterruptedException) {
                    break
                }
            }
        }.start()
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        ativo = false
        val v = vista
        if (v != null) {
            try { wm?.removeView(v) } catch (e: Exception) { }
        }
        vista = null
        wm = null
        super.onDestroy()
    }
}
