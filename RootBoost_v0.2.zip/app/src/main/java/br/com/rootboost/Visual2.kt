package br.com.rootboost

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Shader
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import kotlin.math.abs

/**
 * Cartão de um filtro de imagem: uma mini cena desenhada em código (céu, sol, morro, casa e personagem)
 * com as cores já passadas pelo filtro, então você vê o efeito antes de aplicar. Sem imagens, sem RAM extra.
 */
class CartaoFiltro(ctx: Context, val preset: Cor.Preset, private val larguraDp: Int = 92) : View(ctx) {
    var aoToque: (() -> Unit)? = null

    var forca = 1f
        set(v) { field = v; refazer(); invalidate() }

    var selecionado = false
        set(v) { field = v; invalidate() }

    private val base = intArrayOf(
        0xFF4FA3FF.toInt(), 0xFFC4E6FF.toInt(),
        0xFFFFC145.toInt(),
        0xFF3E9E6B.toInt(), 0xFF2B7A4B.toInt(),
        0xFFE5484D.toInt(), 0xFF8A3B2A.toInt(),
        0xFFF1C27D.toInt(), 0xFF3B5BDB.toInt()
    )
    private val cor = base.copyOf()
    private var ceu: Shader? = null
    private val pFundo = Paint(Paint.ANTI_ALIAS_FLAG)
    private val pBorda = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val pCena = Paint(Paint.ANTI_ALIAS_FLAG)
    private val pCheck = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        color = Color.WHITE
    }
    private val pTexto = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Neon.TEXTO
        typeface = FonteMedia
        textAlign = Paint.Align.CENTER
    }
    private val ret = RectF()
    private val prev = RectF()
    private val clip = Path()
    private val tri = Path()

    init {
        refazer()
        isClickable = true
        setOnClickListener { aoToque?.invoke() }
    }

    private fun refazer() {
        val a = Cor.mesclar(preset.ajuste, forca)
        for (i in base.indices) cor[i] = Cor.transformar(base[i], a)
        ceu = null
    }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        super.onSizeChanged(w, h, ow, oh)
        ceu = null
    }

    override fun onMeasure(w: Int, h: Int) {
        val larg = context.dp(larguraDp)
        setMeasuredDimension(larg, (larg * 1.2f).toInt())
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val d = context.dp(1).toFloat()

        ret.set(d, d, w - d, h - d)
        val r = 14f * d
        pFundo.color = if (selecionado) Neon.SELECIONADO else Neon.CARTAO_A
        c.drawRoundRect(ret, r, r, pFundo)
        pBorda.strokeWidth = if (selecionado) 2f * d else d
        pBorda.color = if (selecionado) Neon.CIANO else Neon.BORDA
        c.drawRoundRect(ret, r, r, pBorda)

        val m = 6f * d
        prev.set(m + d, m + d, w - m - d, h * 0.70f)
        val pr = 10f * d
        c.save()
        clip.reset()
        clip.addRoundRect(prev, pr, pr, Path.Direction.CW)
        c.clipPath(clip)
        if (ceu == null) ceu = LinearGradient(0f, prev.top, 0f, prev.bottom, cor[0], cor[1], Shader.TileMode.CLAMP)
        pCena.shader = ceu
        c.drawRect(prev, pCena)
        pCena.shader = null
        val pw = prev.width()
        val ph = prev.height()
        pCena.color = cor[2]
        c.drawCircle(prev.right - pw * 0.22f, prev.top + ph * 0.24f, pw * 0.11f, pCena)
        pCena.color = cor[3]
        c.drawCircle(prev.left + pw * 0.25f, prev.bottom - ph * 0.05f, pw * 0.42f, pCena)
        pCena.color = cor[4]
        c.drawRect(prev.left, prev.bottom - ph * 0.28f, prev.right, prev.bottom, pCena)
        val cx0 = prev.left + pw * 0.58f
        val cy1 = prev.bottom - ph * 0.26f
        pCena.color = cor[5]
        c.drawRect(cx0, cy1 - ph * 0.22f, cx0 + pw * 0.26f, cy1, pCena)
        pCena.color = cor[6]
        tri.reset()
        tri.moveTo(cx0 - pw * 0.03f, cy1 - ph * 0.22f)
        tri.lineTo(cx0 + pw * 0.13f, cy1 - ph * 0.40f)
        tri.lineTo(cx0 + pw * 0.29f, cy1 - ph * 0.22f)
        tri.close()
        c.drawPath(tri, pCena)
        val px = prev.left + pw * 0.28f
        val py = prev.bottom - ph * 0.30f
        pCena.color = cor[8]
        c.drawRoundRect(px - pw * 0.07f, py, px + pw * 0.07f, py + ph * 0.24f, 3f * d, 3f * d, pCena)
        pCena.color = cor[7]
        c.drawCircle(px, py - ph * 0.07f, pw * 0.065f, pCena)
        c.restore()

        if (selecionado) {
            val bx = prev.left + 11f * d
            val by = prev.top + 11f * d
            pCena.color = Neon.CIANO
            c.drawCircle(bx, by, 7f * d, pCena)
            pCheck.strokeWidth = 1.8f * d
            c.drawLine(bx - 3f * d, by, bx - 1f * d, by + 2.5f * d, pCheck)
            c.drawLine(bx - 1f * d, by + 2.5f * d, bx + 3.5f * d, by - 2.5f * d, pCheck)
        }

        var tam = 11.5f * d
        pTexto.textSize = tam
        while (pTexto.measureText(preset.nome) > w - 8f * d && tam > 8f * d) {
            tam -= 0.5f * d
            pTexto.textSize = tam
        }
        c.drawText(preset.nome, w / 2f, h - 10f * d, pTexto)
    }
}

/**
 * Pad de dois eixos para o ajuste fino das cores: para a direita aumenta a saturação,
 * para cima aumenta o contraste. Um ponto marca onde fica o "original" e o dedo gruda nele.
 */
class Pad2D(ctx: Context) : View(ctx) {
    var aoMudar: ((Float, Float) -> Unit)? = null
    var aoSoltar: ((Float, Float) -> Unit)? = null
    var alturaDp = 140

    private val satMin = 0.5f
    private val satMax = 1.8f
    private val conMin = 0.7f
    private val conMax = 1.4f
    private val fx0 = (1f - satMin) / (satMax - satMin)
    private val fy0 = (1f - conMin) / (conMax - conMin)
    private var fx = fx0
    private var fy = fy0

    private val pFundo = Paint(Paint.ANTI_ALIAS_FLAG)
    private val pSombra = Paint(Paint.ANTI_ALIAS_FLAG)
    private val pLinha = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        color = 0x22FFFFFF
    }
    private val pGuia = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        color = 0x66FFFFFF
    }
    private val pBola = Paint(Paint.ANTI_ALIAS_FLAG)
    private val pTexto = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xB0F1F5FF.toInt()
        typeface = FonteMedia
    }
    private val ret = RectF()
    private val clip = Path()

    fun sat(): Float = satMin + fx * (satMax - satMin)
    fun con(): Float = conMin + fy * (conMax - conMin)

    fun definir(sat: Float, con: Float) {
        fx = ((sat - satMin) / (satMax - satMin)).coerceIn(0f, 1f)
        fy = ((con - conMin) / (conMax - conMin)).coerceIn(0f, 1f)
        invalidate()
    }

    override fun onMeasure(w: Int, h: Int) {
        setMeasuredDimension(MeasureSpec.getSize(w), context.dp(alturaDp))
    }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        super.onSizeChanged(w, h, ow, oh)
        pFundo.shader = LinearGradient(
            0f, 0f, w.toFloat(), 0f,
            intArrayOf(0xFF343A52.toInt(), 0xFF4B5BD6.toInt(), 0xFFB75CFF.toInt()), null, Shader.TileMode.CLAMP
        )
        pSombra.shader = LinearGradient(
            0f, 0f, 0f, h.toFloat(), 0x00060810, 0xCC060810.toInt(), Shader.TileMode.CLAMP
        )
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val d = context.dp(1).toFloat()
        val r = 16f * d
        ret.set(0f, 0f, w, h)
        clip.reset()
        clip.addRoundRect(ret, r, r, Path.Direction.CW)
        c.save()
        c.clipPath(clip)
        c.drawRect(ret, pFundo)
        c.drawRect(ret, pSombra)
        pLinha.strokeWidth = d
        for (i in 1..3) {
            c.drawLine(w * i / 4f, 0f, w * i / 4f, h, pLinha)
            c.drawLine(0f, h * i / 4f, w, h * i / 4f, pLinha)
        }
        c.restore()

        // ponto do original
        val ox = fx0 * w
        val oy = (1f - fy0) * h
        pGuia.strokeWidth = d
        c.drawCircle(ox, oy, 5f * d, pGuia)

        // posição atual
        val x = fx * w
        val y = (1f - fy) * h
        c.drawLine(0f, y, x, y, pGuia)
        c.drawLine(x, y, x, h, pGuia)
        pBola.color = 0x5522D3EE
        c.drawCircle(x, y, 17f * d, pBola)
        pBola.color = Color.WHITE
        c.drawCircle(x, y, 8f * d, pBola)
        pBola.color = Neon.CIANO
        c.drawCircle(x, y, 4.5f * d, pBola)

        pTexto.textSize = 10.5f * d
        c.drawText("Contraste", 10f * d, 16f * d, pTexto)
        val t = "Saturação"
        c.drawText(t, w - pTexto.measureText(t) - 10f * d, h - 9f * d, pTexto)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.action) {
            MotionEvent.ACTION_DOWN -> {
                parent?.requestDisallowInterceptTouchEvent(true)
                mover(e)
            }
            MotionEvent.ACTION_MOVE -> mover(e)
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                mover(e)
                aoSoltar?.invoke(sat(), con())
            }
        }
        return true
    }

    private fun mover(e: MotionEvent) {
        if (width <= 0 || height <= 0) return
        var nx = (e.x / width).coerceIn(0f, 1f)
        var ny = (1f - e.y / height).coerceIn(0f, 1f)
        if (abs(nx - fx0) < 0.025f && abs(ny - fy0) < 0.025f) {
            nx = fx0
            ny = fy0
        }
        fx = nx
        fy = ny
        invalidate()
        aoMudar?.invoke(sat(), con())
    }
}

/** Controle com botões − e +, no lugar de barras deslizantes. */
class Stepper(
    ctx: Context,
    private val min: Float,
    private val max: Float,
    private val passo: Float,
    private val formato: (Float) -> String
) : LinearLayout(ctx) {
    var aoMudar: ((Float) -> Unit)? = null
    var valor = 0f
        private set
    private val tv: TextView

    init {
        orientation = HORIZONTAL
        gravity = Gravity.CENTER_VERTICAL
        val menos = botao("−")
        val mais = botao("+")
        tv = ctx.texto(formato(0f), 14f, Neon.TEXTO, true)
        tv.gravity = Gravity.CENTER
        addView(menos, LayoutParams(ctx.dp(44), ctx.dp(38)))
        addView(tv, LayoutParams(0, LayoutParams.WRAP_CONTENT, 1f))
        addView(mais, LayoutParams(ctx.dp(44), ctx.dp(38)))
        menos.setOnClickListener { mudar(-passo) }
        mais.setOnClickListener { mudar(passo) }
    }

    private fun botao(t: String): TextView {
        val b = context.texto(t, 20f, Neon.TEXTO, true)
        b.gravity = Gravity.CENTER
        b.background = context.clicavel(Neon.CARTAO_A, 12, Neon.BORDA, 1)
        return b
    }

    fun definir(v: Float) {
        valor = v.coerceIn(min, max)
        tv.text = formato(valor)
    }

    private fun mudar(delta: Float) {
        val novo = Math.round((valor + delta) / passo) * passo
        definir(novo)
        aoMudar?.invoke(valor)
    }
}

/** Função do Game Turbo: caixinha que liga e desliga, mais um botão ⓘ que explica o que ela faz. */
class CartaoFuncao(
    ctx: Context,
    val modulo: Modulos.Modulo,
    cor: Int = Neon.CIANO
) : FrameLayout(ctx) {
    val caixa = Caixinha(ctx, modulo.icone, modulo.nome, cor, Neon.CARTAO_A, Neon.SELECIONADO, Neon.BORDA)
    var aoInfo: (() -> Unit)? = null

    init {
        addView(caixa, LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT))
        val info = FrameLayout(ctx)
        val ic = Icone(ctx, "info")
        ic.tamanhoDp = 16
        ic.cor = Neon.SUAVE
        info.addView(ic, LayoutParams(ctx.dp(16), ctx.dp(16), Gravity.CENTER))
        info.setOnClickListener { aoInfo?.invoke() }
        addView(info, LayoutParams(ctx.dp(40), ctx.dp(40), Gravity.TOP or Gravity.END))
    }
}

/** Cartãozinho que explica uma função; aparece quando você toca no ⓘ. */
class CartaoInfo(ctx: Context) : LinearLayout(ctx) {
    private val tvTitulo = ctx.titulo("", 15f, Neon.CIANO)
    private val tvTexto = ctx.texto("", 12f, Neon.TEXTO)

    init {
        orientation = VERTICAL
        setPadding(ctx.dp(14), ctx.dp(12), ctx.dp(14), ctx.dp(12))
        background = ctx.forma(0xFF121A33.toInt(), 16, Neon.BORDA_SEL, 1)
        visibility = GONE
        addView(tvTitulo)
        addView(tvTexto, ctx.lp(CHEIO, AUTO, 4, 0))
        val ok = ctx.texto("Entendi", 12.5f, Neon.CIANO, true)
        ok.setPadding(0, ctx.dp(10), 0, 0)
        ok.setOnClickListener { visibility = GONE }
        addView(ok)
    }

    fun mostrar(titulo: String, texto: String) {
        tvTitulo.text = titulo
        tvTexto.text = texto
        visibility = VISIBLE
    }
}


/** Cartão de seção no estilo do Game Turbo. */
fun Context.cartaoNeon(pad: Int = 14): LinearLayout = vertical().apply {
    setPadding(dp(pad), dp(pad), dp(pad), dp(pad))
    background = degrade(Neon.CARTAO_A, Neon.CARTAO_B, 20, Neon.BORDA, 1)
}

/** Título de seção: texto em caixa alta com uma linha fina até o fim. */
fun Context.secaoNeon(nome: String): LinearLayout {
    val l = horizontal()
    val t = titulo(nome.uppercase(), 12.5f, Neon.CIANO)
    t.letterSpacing = 0.1f
    l.addView(t)
    val linha = View(this)
    linha.setBackgroundColor(Neon.BORDA)
    l.addView(linha, LinearLayout.LayoutParams(0, dp(1), 1f).apply { leftMargin = dp(12) })
    return l
}

/** Quadrado com o ícone da função, no estilo neon. */
fun Context.caixaIconeNeon(tipo: String): FrameLayout {
    val f = FrameLayout(this)
    f.background = forma(Neon.SELECIONADO, 14, Neon.BORDA, 1)
    val ic = Icone(this, tipo)
    ic.cor = Neon.CIANO
    f.addView(ic, FrameLayout.LayoutParams(AUTO, AUTO, Gravity.CENTER))
    return f
}

/** Botão principal em degradê azul/violeta. */
fun Context.botaoNeon(rotulo: String, aoClicar: () -> Unit): TextView {
    val t = texto(rotulo, 14f, Neon.TEXTO, true)
    t.gravity = Gravity.CENTER
    t.setPadding(dp(16), dp(14), dp(16), dp(14))
    t.background = fundoBotaoNeon()
    t.setOnClickListener { aoClicar() }
    return t
}
