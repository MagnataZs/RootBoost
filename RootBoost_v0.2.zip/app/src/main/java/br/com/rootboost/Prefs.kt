package br.com.rootboost

import android.content.Context

object Prefs {
    private fun sp(c: Context) = c.getSharedPreferences("rootboost", Context.MODE_PRIVATE)

    fun jogos(c: Context): Set<String> =
        HashSet<String>(sp(c).getStringSet("jogos", emptySet<String>()) ?: emptySet<String>())

    fun setJogos(c: Context, v: Set<String>) {
        sp(c).edit().putStringSet("jogos", HashSet<String>(v)).apply()
    }

    /** Perfil escolhido pelo usuário (volta para ele quando o jogo fecha). */
    fun base(c: Context): String = sp(c).getString("base", "equilibrado") ?: "equilibrado"
    fun setBase(c: Context, v: String) { sp(c).edit().putString("base", v).apply() }

    /** Perfil realmente aplicado agora. */
    fun aplicado(c: Context): String = sp(c).getString("aplicado", "equilibrado") ?: "equilibrado"
    fun setAplicado(c: Context, v: String) { sp(c).edit().putString("aplicado", v).apply() }

    fun turbo(c: Context): Boolean = sp(c).getBoolean("turbo", false)
    fun setTurbo(c: Context, v: Boolean) { sp(c).edit().putBoolean("turbo", v).apply() }

    fun overlay(c: Context): Boolean = sp(c).getBoolean("overlay", false)
    fun setOverlay(c: Context, v: Boolean) { sp(c).edit().putBoolean("overlay", v).apply() }

    fun limparAoJogar(c: Context): Boolean = sp(c).getBoolean("limpar_jogo", true)
    fun setLimparAoJogar(c: Context, v: Boolean) { sp(c).edit().putBoolean("limpar_jogo", v).apply() }

    fun str(c: Context, k: String, padrao: String): String = sp(c).getString(k, padrao) ?: padrao
    fun putStr(c: Context, k: String, v: String) { sp(c).edit().putString(k, v).apply() }
    fun lng(c: Context, k: String, padrao: Long): Long = sp(c).getLong(k, padrao)
    fun putLng(c: Context, k: String, v: Long) { sp(c).edit().putLong(k, v).apply() }
}
