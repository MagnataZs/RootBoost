package br.com.rootboost

import android.content.Context

object Prefs {
    private fun sp(c: Context) = c.getSharedPreferences("rootboost", Context.MODE_PRIVATE)

    fun lista(c: Context, k: String): Set<String> =
        HashSet<String>(sp(c).getStringSet(k, emptySet<String>()) ?: emptySet<String>())

    fun setLista(c: Context, k: String, v: Set<String>) {
        sp(c).edit().putStringSet(k, HashSet<String>(v)).apply()
    }

    fun jogos(c: Context): Set<String> = lista(c, "jogos")
    fun setJogos(c: Context, v: Set<String>) = setLista(c, "jogos", v)
    fun protegidos(c: Context): Set<String> = lista(c, "protegidos")

    /** Perfil escolhido pelo usuário (volta para ele quando o jogo fecha). */
    fun base(c: Context): String = sp(c).getString("base", "equilibrado") ?: "equilibrado"
    fun setBase(c: Context, v: String) { sp(c).edit().putString("base", v).apply() }

    /** Perfil realmente aplicado agora. */
    fun aplicado(c: Context): String = sp(c).getString("aplicado", "equilibrado") ?: "equilibrado"
    fun setAplicado(c: Context, v: String) { sp(c).edit().putString("aplicado", v).apply() }

    /** Perfil usado em cada jogo (padrão: Gaming). */
    fun perfilJogo(c: Context, pkg: String): String = str(c, "pj_$pkg", "gaming")
    fun setPerfilJogo(c: Context, pkg: String, v: String) = putStr(c, "pj_$pkg", v)

    fun modAuto(c: Context, id: String): Boolean = bool(c, "ma_$id", id == "chamadas")
    fun setModAuto(c: Context, id: String, v: Boolean) = putBool(c, "ma_$id", v)
    fun modAtivo(c: Context, id: String): Boolean = bool(c, "mo_$id", false)
    fun setModAtivo(c: Context, id: String, v: Boolean) = putBool(c, "mo_$id", v)

    /** Funções por jogo: o jogo pode ter escolha própria ("1" ligado, "0" desligado); vazio segue o global. */
    fun temModJogo(c: Context, pkg: String, id: String): Boolean = str(c, "mj_${pkg}_$id", "").isNotEmpty()
    fun modAutoJogo(c: Context, pkg: String, id: String): Boolean {
        val v = str(c, "mj_${pkg}_$id", "")
        return if (v.isEmpty()) modAuto(c, id) else v == "1"
    }
    fun setModJogo(c: Context, pkg: String, id: String, v: Boolean?) {
        if (v == null) apagar(c, "mj_${pkg}_$id") else putStr(c, "mj_${pkg}_$id", if (v) "1" else "0")
    }

    /** Filtro de cor do jogo (id do preset); vazio segue o filtro global. */
    fun filtroJogo(c: Context, pkg: String): String = str(c, "cj_$pkg", "")
    fun setFiltroJogo(c: Context, pkg: String, id: String) = putStr(c, "cj_$pkg", id)

    /** Resolução do jogo em % (100 = padrão), FPS alvo (0 = padrão), modo do sistema (0 padrão, 1 desempenho, 2 bateria). */
    fun escalaJogo(c: Context, pkg: String): Int = lng(c, "es_$pkg", 100L).toInt()
    fun setEscalaJogo(c: Context, pkg: String, v: Int) = putLng(c, "es_$pkg", v.toLong())
    fun fpsJogo(c: Context, pkg: String): Int = lng(c, "fp_$pkg", 0L).toInt()
    fun setFpsJogo(c: Context, pkg: String, v: Int) = putLng(c, "fp_$pkg", v.toLong())
    fun modoJogo(c: Context, pkg: String): Int = lng(c, "gm_$pkg", 0L).toInt()
    fun setModoJogo(c: Context, pkg: String, v: Int) = putLng(c, "gm_$pkg", v.toLong())

    /** Driver gráfico só para este jogo: 0 padrão, 1 Game Driver, 2 ANGLE. */
    fun driverJogo(c: Context, pkg: String): Int = lng(c, "dj_$pkg", 0L).toInt()
    fun setDriverJogo(c: Context, pkg: String, v: Int) = putLng(c, "dj_$pkg", v.toLong())

    /** Tamanho da janela dos apps rápidos: 0 pequena, 1 média, 2 grande. */
    fun janelaTam(c: Context): Int = lng(c, "janela_tam", 1L).toInt()
    fun setJanelaTam(c: Context, v: Int) = putLng(c, "janela_tam", v.toLong())

    fun turbo(c: Context): Boolean = bool(c, "turbo", false)
    fun setTurbo(c: Context, v: Boolean) = putBool(c, "turbo", v)
    fun overlay(c: Context): Boolean = bool(c, "overlay", false)
    fun setOverlay(c: Context, v: Boolean) = putBool(c, "overlay", v)
    fun fpsOn(c: Context): Boolean = bool(c, "fps_on", true)
    fun setFpsOn(c: Context, v: Boolean) = putBool(c, "fps_on", v)
    fun painelNoJogo(c: Context): Boolean = bool(c, "painel_jogo", true)
    fun setPainelNoJogo(c: Context, v: Boolean) = putBool(c, "painel_jogo", v)

    /** Jogos em que o RootBoost NÃO desenha nada por cima (contador de FPS, painel, medidor). */
    private val SEM_OVERLAY_PADRAO = setOf("com.dts.freefireth", "com.dts.freefiremax")

    fun semOverlay(c: Context, pkg: String): Boolean = bool(c, "so_$pkg", pkg in SEM_OVERLAY_PADRAO)
    fun setSemOverlay(c: Context, pkg: String, v: Boolean) = putBool(c, "so_$pkg", v)

    /** Apps que o Game Turbo abre em janela flutuante, sem sair do jogo. */
    fun atalhos(c: Context): Set<String> = lista(c, "atalhos")

    /** Apps de chamada que o Game Turbo mantém vivos enquanto você joga. */
    val CHAMADAS = setOf(
        "com.whatsapp", "com.whatsapp.w4b", "com.discord", "org.telegram.messenger",
        "com.google.android.apps.tachyon", "com.google.android.apps.meetings",
        "com.skype.raider", "us.zoom.videomeetings", "com.facebook.orca", "com.instagram.android",
        "com.teamspeak.ts3client", "com.microsoft.teams"
    )

    fun chamadasAtivas(c: Context): Set<String> = CHAMADAS + protegidos(c) + atalhos(c)

    fun apagar(c: Context, k: String) { sp(c).edit().remove(k).apply() }
    fun bool(c: Context, k: String, padrao: Boolean): Boolean = sp(c).getBoolean(k, padrao)
    fun putBool(c: Context, k: String, v: Boolean) { sp(c).edit().putBoolean(k, v).apply() }
    fun str(c: Context, k: String, padrao: String): String = sp(c).getString(k, padrao) ?: padrao
    fun putStr(c: Context, k: String, v: String) { sp(c).edit().putString(k, v).apply() }
    fun lng(c: Context, k: String, padrao: Long): Long = sp(c).getLong(k, padrao)
    fun putLng(c: Context, k: String, v: Long) { sp(c).edit().putLong(k, v).apply() }
}
