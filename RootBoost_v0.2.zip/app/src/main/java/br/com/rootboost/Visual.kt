package br.com.rootboost

import android.animation.ValueAnimator
import android.content.Context
import android.content.res.ColorStateList
import android.graphics.Matrix
import android.graphics.SweepGradient
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.RippleDrawable
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.LinearGradient
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.animation.LinearInterpolator
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import kotlin.math.abs

fun misturar(a: Int, b: Int, t: Float): Int {
    fun m(x: Int, y: Int) = x + ((y - x) * t).toInt()
    return Color.argb(
        m(Color.alpha(a), Color.alpha(b)), m(Color.red(a), Color.red(b)),
        m(Color.green(a), Color.green(b)), m(Color.blue(a), Color.blue(b))
    )
}

/** Mesma cor com outra transparência (a de 0 a 255). */
fun comAlfa(cor: Int, a: Int): Int = (cor and 0x00FFFFFF) or (a shl 24)

/** Paleta azul/roxa do painel dentro do jogo. */
object Neon {
    val PAINEL_A = 0xF2141B30.toInt()
    val PAINEL_B = 0xF20A0E1B.toInt()
    val CARTAO_A = 0xFF182038.toInt()
    val CARTAO_B = 0xFF0F1426.toInt()
    val BORDA = 0xFF26304F.toInt()
    val TEXTO = 0xFFF1F5FF.toInt()
    val SUAVE = 0xFF8B93AD.toInt()
    val CIANO = 0xFF22D3EE.toInt()
    val AZUL = 0xFF3B82F6.toInt()
    val LILAS = 0xFFC084FC.toInt()
    val ROXO = 0xFF8B5CF6.toInt()
    val VIOLETA = 0xFF7C5CFF.toInt()
    val OK = 0xFF34D399.toInt()
    val SELECIONADO = 0xFF1A2650.toInt()
    val BORDA_SEL = 0xFF3B5BDB.toInt()
}

/** Fundo do botão principal: degradê azul para violeta com efeito de toque. */
fun Context.fundoBotaoNeon(): RippleDrawable {
    val g = GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(Neon.AZUL, Neon.VIOLETA))
    g.cornerRadius = dp(16).toFloat()
    return RippleDrawable(ColorStateList.valueOf(0x33FFFFFF), g, forma(Color.WHITE, 16))
}

/** Ícones de traço desenhados em código (grade 24x24), sem imagens. */
class Icone(ctx: Context, private val tipo: String) : View(ctx) {
    var cor: Int = Cores.SUAVE
        set(v) { field = v; invalidate() }

    private val tr = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
        strokeWidth = 1.9f
    }
    private val pr = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }

    var tamanhoDp = 24

    override fun onMeasure(w: Int, h: Int) {
        val t = context.dp(tamanhoDp)
        setMeasuredDimension(t, t)
    }

    override fun onDraw(c: Canvas) {
        tr.color = cor
        pr.color = cor
        c.save()
        val s = width / 24f
        c.scale(s, s)
        when (tipo) {
            "inicio" -> {
                c.drawArc(RectF(3f, 3f, 21f, 21f), 150f, 240f, false, tr)
                c.drawLine(12f, 12f, 16.5f, 7.5f, tr)
                c.drawCircle(12f, 12f, 1.5f, pr)
            }
            "jogos" -> {
                c.drawRoundRect(RectF(2.5f, 7f, 21.5f, 17.5f), 4.5f, 4.5f, tr)
                c.drawLine(7f, 10.2f, 7f, 14.3f, tr)
                c.drawLine(4.95f, 12.25f, 9.05f, 12.25f, tr)
                c.drawCircle(16f, 11.3f, 1f, pr)
                c.drawCircle(18.4f, 13.4f, 1f, pr)
            }
            "modulos" -> {
                c.drawRoundRect(RectF(4f, 4f, 10.5f, 10.5f), 1.8f, 1.8f, tr)
                c.drawRoundRect(RectF(13.5f, 4f, 20f, 10.5f), 1.8f, 1.8f, tr)
                c.drawRoundRect(RectF(4f, 13.5f, 10.5f, 20f), 1.8f, 1.8f, tr)
                c.drawRoundRect(RectF(13.5f, 13.5f, 20f, 20f), 1.8f, 1.8f, tr)
            }
            "ajustes" -> {
                c.drawLine(4f, 6f, 7f, 6f, tr); c.drawLine(11f, 6f, 20f, 6f, tr); c.drawCircle(9f, 6f, 2f, tr)
                c.drawLine(4f, 12f, 13f, 12f, tr); c.drawLine(17f, 12f, 20f, 12f, tr); c.drawCircle(15f, 12f, 2f, tr)
                c.drawLine(4f, 18f, 6f, 18f, tr); c.drawLine(10f, 18f, 20f, 18f, tr); c.drawCircle(8f, 18f, 2f, tr)
            }
            "info" -> {
                c.drawCircle(12f, 12f, 9f, tr)
                c.drawLine(12f, 11f, 12f, 16.5f, tr)
                c.drawCircle(12f, 7.8f, 1f, pr)
            }
            "fechar" -> {
                c.drawLine(6f, 6f, 18f, 18f, tr)
                c.drawLine(18f, 6f, 6f, 18f, tr)
            }
            "cpu" -> {
                c.drawRoundRect(RectF(6f, 6f, 18f, 18f), 2.2f, 2.2f, tr)
                c.drawRect(RectF(9.5f, 9.5f, 14.5f, 14.5f), tr)
                for (v in listOf(9f, 12f, 15f)) {
                    c.drawLine(v, 3f, v, 6f, tr); c.drawLine(v, 18f, v, 21f, tr)
                    c.drawLine(3f, v, 6f, v, tr); c.drawLine(18f, v, 21f, v, tr)
                }
            }
            "memoria" -> {
                val a = Path(); a.moveTo(12f, 4f); a.lineTo(20f, 8f); a.lineTo(12f, 12f); a.lineTo(4f, 8f); a.close()
                c.drawPath(a, tr)
                val b = Path(); b.moveTo(4f, 12f); b.lineTo(12f, 16f); b.lineTo(20f, 12f); c.drawPath(b, tr)
                val d = Path(); d.moveTo(4f, 16f); d.lineTo(12f, 20f); d.lineTo(20f, 16f); c.drawPath(d, tr)
            }
            "atualizar" -> {
                c.drawArc(RectF(4f, 4f, 20f, 20f), 40f, 270f, false, tr)
                val a = Path(); a.moveTo(13.5f, 5.9f); a.lineTo(17.1f, 5.9f); a.lineTo(17.1f, 2.3f)
                c.drawPath(a, tr)
            }
            "toque" -> {
                c.drawCircle(12f, 12f, 1.8f, pr)
                c.drawCircle(12f, 12f, 5.5f, tr)
                c.drawArc(RectF(2.5f, 2.5f, 21.5f, 21.5f), 200f, 140f, false, tr)
            }
            "wifi" -> {
                for (r in listOf(4.5f, 8.5f, 12.5f)) {
                    c.drawArc(RectF(12f - r, 19f - r, 12f + r, 19f + r), 228f, 84f, false, tr)
                }
                c.drawCircle(12f, 19f, 1.2f, pr)
            }
            "limpar" -> {
                val a = Path()
                a.moveTo(12f, 3f); a.lineTo(14f, 10f); a.lineTo(21f, 12f); a.lineTo(14f, 14f)
                a.lineTo(12f, 21f); a.lineTo(10f, 14f); a.lineTo(3f, 12f); a.lineTo(10f, 10f); a.close()
                c.drawPath(a, tr)
            }
            "terminal" -> {
                c.drawRoundRect(RectF(3f, 4f, 21f, 20f), 3f, 3f, tr)
                val a = Path(); a.moveTo(7f, 9f); a.lineTo(11f, 12f); a.lineTo(7f, 15f); c.drawPath(a, tr)
                c.drawLine(13f, 15.5f, 17f, 15.5f, tr)
            }
            "tela" -> {
                val a = Path(); a.moveTo(4f, 9f); a.lineTo(4f, 4f); a.lineTo(9f, 4f); c.drawPath(a, tr)
                val b = Path(); b.moveTo(15f, 4f); b.lineTo(20f, 4f); b.lineTo(20f, 9f); c.drawPath(b, tr)
                val d = Path(); d.moveTo(20f, 15f); d.lineTo(20f, 20f); d.lineTo(15f, 20f); c.drawPath(d, tr)
                val e = Path(); e.moveTo(9f, 20f); e.lineTo(4f, 20f); e.lineTo(4f, 15f); c.drawPath(e, tr)
            }
            "cor" -> {
                c.drawCircle(12f, 12f, 9f, tr)
                c.drawArc(RectF(3f, 3f, 21f, 21f), 270f, 180f, true, pr)
            }
            "fps" -> {
                val a = Path()
                a.moveTo(3f, 13f); a.lineTo(7f, 13f); a.lineTo(9.5f, 6f); a.lineTo(13f, 19f)
                a.lineTo(15.5f, 11f); a.lineTo(17f, 13f); a.lineTo(21f, 13f)
                c.drawPath(a, tr)
            }
            "sino" -> {
                val a = Path()
                a.moveTo(7f, 17f); a.lineTo(7f, 10f); a.arcTo(RectF(7f, 5f, 17f, 15f), 180f, 180f, false)
                a.lineTo(17f, 17f); a.close()
                c.drawPath(a, tr)
                c.drawLine(5f, 17f, 19f, 17f, tr)
                c.drawArc(RectF(10f, 18f, 14f, 22f), 0f, 180f, false, tr)
            }
            "janela" -> {
                c.drawRoundRect(RectF(3f, 5f, 16f, 16f), 2.5f, 2.5f, tr)
                c.drawRoundRect(RectF(9f, 10f, 21f, 20f), 2.5f, 2.5f, tr)
            }
            "bateria" -> {
                c.drawRoundRect(RectF(2.5f, 7f, 19f, 17f), 2.5f, 2.5f, tr)
                c.drawLine(21f, 10.5f, 21f, 13.5f, tr)
                c.drawRoundRect(RectF(5f, 9.5f, 14f, 14.5f), 1f, 1f, pr)
            }
            "barras" -> {
                c.drawRoundRect(RectF(4.5f, 13f, 8.5f, 20f), 1.5f, 1.5f, pr)
                c.drawRoundRect(RectF(10f, 8.5f, 14f, 20f), 1.5f, 1.5f, pr)
                c.drawRoundRect(RectF(15.5f, 4f, 19.5f, 20f), 1.5f, 1.5f, pr)
            }
            "termometro" -> {
                c.drawRoundRect(RectF(10f, 3f, 14f, 15f), 2f, 2f, tr)
                c.drawCircle(12f, 17.5f, 3.5f, tr)
                c.drawLine(12f, 8f, 12f, 17f, tr)
            }
            "play" -> {
                val a = Path()
                a.moveTo(7f, 4.5f); a.lineTo(19f, 12f); a.lineTo(7f, 19.5f); a.close()
                c.drawPath(a, pr)
            }
            "gpu" -> {
                c.drawRoundRect(RectF(2.5f, 6.5f, 21.5f, 17.5f), 3f, 3f, tr)
                c.drawCircle(8.5f, 12f, 2.8f, tr)
                c.drawCircle(15.5f, 12f, 2.8f, tr)
            }
            "engrenagem" -> {
                c.drawCircle(12f, 12f, 3.2f, tr)
                c.drawCircle(12f, 12f, 7f, tr)
                for (k in 0 until 8) {
                    val ang = Math.toRadians(k * 45.0)
                    val x1 = (12.0 + 7.0 * Math.cos(ang)).toFloat()
                    val y1 = (12.0 + 7.0 * Math.sin(ang)).toFloat()
                    val x2 = (12.0 + 10.0 * Math.cos(ang)).toFloat()
                    val y2 = (12.0 + 10.0 * Math.sin(ang)).toFloat()
                    c.drawLine(x1, y1, x2, y2, tr)
                }
            }
            "raio" -> {
                val p = Path()
                p.moveTo(13.5f, 2.5f); p.lineTo(5.5f, 13.5f); p.lineTo(11f, 13.5f)
                p.lineTo(10f, 21.5f); p.lineTo(18.5f, 10f); p.lineTo(13f, 10f); p.close()
                c.drawPath(p, pr)
            }
        }
        c.restore()
    }
}

/** Medidor em arco com valor no centro. */
class Medidor(ctx: Context) : View(ctx) {
    var rotulo = ""
    var unidade = ""
    private var texto = "—"
    private var cor = Cores.ACENTO
    private var atual = 0f
    private var ultimoAlvo = 0f
    private var tend = 0          // 1 subindo, -1 descendo, 0 estável
    private var anim: ValueAnimator? = null

    private val trilha = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        color = Cores.LINHA
    }
    private val arco = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
    }
    private val num = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textAlign = Paint.Align.CENTER
        color = Cores.TEXTO
        typeface = FonteMedia
    }
    private val leg = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textAlign = Paint.Align.CENTER
        color = Cores.SUAVE
    }
    private val area = RectF()

    fun definir(frac: Float, valor: String, c: Int = Cores.ACENTO) {
        texto = valor
        cor = c
        val alvo = frac.coerceIn(0f, 1f)
        val dif = alvo - ultimoAlvo
        tend = if (dif > 0.03f) 1 else if (dif < -0.03f) -1 else 0
        ultimoAlvo = alvo
        anim?.cancel()
        val a = ValueAnimator.ofFloat(atual, alvo)
        a.duration = 700
        a.interpolator = android.view.animation.DecelerateInterpolator(1.4f)
        a.addUpdateListener { atual = it.animatedValue as Float; invalidate() }
        anim = a
        a.start()
    }

    override fun onMeasure(w: Int, h: Int) {
        val tam = if (MeasureSpec.getMode(w) == MeasureSpec.UNSPECIFIED) context.dp(88) else MeasureSpec.getSize(w)
        setMeasuredDimension(tam, tam)
    }

    override fun onDraw(c: Canvas) {
        val s = minOf(width, height).toFloat()
        val esp = s * 0.07f
        trilha.strokeWidth = esp
        arco.strokeWidth = esp
        arco.color = cor
        area.set(esp, esp, s - esp, s - esp)
        c.drawArc(area, 135f, 270f, false, trilha)
        if (atual > 0.001f) c.drawArc(area, 135f, 270f * atual, false, arco)
        num.textSize = s * 0.26f
        c.drawText(texto, s / 2f, s * 0.57f, num)
        leg.textSize = s * 0.12f
        c.drawText(rotulo, s / 2f, s * 0.34f, leg)
        c.drawText(unidade, s / 2f, s * 0.76f, leg)
        desenharSeta(c, s / 2f + leg.measureText(rotulo) / 2f + s * 0.07f, s * 0.305f, s * 0.045f, tend, seta)
    }

    private val seta = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
}

/** Setinha de tendência: ▲ subindo (laranja), ▼ descendo (verde). Nada se estiver estável. */
fun desenharSeta(c: Canvas, cx: Float, cy: Float, r: Float, tend: Int, p: Paint) {
    if (tend == 0) return
    val path = Path()
    if (tend > 0) {
        p.color = Cores.ACENTO
        path.moveTo(cx, cy - r); path.lineTo(cx + r, cy + r); path.lineTo(cx - r, cy + r)
    } else {
        p.color = Cores.OK
        path.moveTo(cx - r, cy - r); path.lineTo(cx + r, cy - r); path.lineTo(cx, cy + r)
    }
    path.close()
    c.drawPath(path, p)
}

/** Interruptor próprio (faixa + bolinha animada). */
class Chave(ctx: Context) : View(ctx) {
    var aoMudar: ((Boolean) -> Unit)? = null
    private var marcado = false
    private var t = 0f
    private var anim: ValueAnimator? = null
    private val faixa = Paint(Paint.ANTI_ALIAS_FLAG)
    private val bola = Paint(Paint.ANTI_ALIAS_FLAG)

    init {
        isClickable = true
        setOnClickListener {
            definir(!marcado, true)
            aoMudar?.invoke(marcado)
        }
    }

    fun estaMarcado(): Boolean = marcado

    fun somenteExibir() {
        setOnClickListener(null)
        isClickable = false
    }

    fun definir(v: Boolean, animar: Boolean = false) {
        marcado = v
        anim?.cancel()
        if (animar) {
            val a = ValueAnimator.ofFloat(t, if (v) 1f else 0f)
            a.duration = 240
            a.interpolator = android.view.animation.DecelerateInterpolator()
            a.addUpdateListener { t = it.animatedValue as Float; invalidate() }
            anim = a
            a.start()
        } else {
            t = if (v) 1f else 0f
            invalidate()
        }
    }

    override fun onMeasure(w: Int, h: Int) {
        setMeasuredDimension(context.dp(46), context.dp(28))
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        faixa.color = misturar(0xFF3A3E48.toInt(), Neon.AZUL, t)
        c.drawRoundRect(0f, 0f, w, h, h / 2f, h / 2f, faixa)
        val r = h / 2f - context.dp(3)
        val cx = h / 2f + (w - h) * t
        bola.color = misturar(0xFFB4B9C4.toInt(), Color.WHITE, t)
        c.drawCircle(cx, h / 2f, r, bola)
    }
}

/** Controle segmentado (ex.: Economia | Equilibrado | Performance | Gaming). */
class Segmentado(
    ctx: Context,
    opcoes: List<String>,
    sp: Float = 13f,
    private val cor: Int = Cores.ACENTO,
    fundo: Int = Cores.SUPERFICIE2
) : LinearLayout(ctx) {
    var aoEscolher: ((Int) -> Unit)? = null
    private val itens = ArrayList<TextView>()

    init {
        orientation = HORIZONTAL
        val d = context.dp(3)
        setPadding(d, d, d, d)
        background = context.forma(fundo, 14)
        for (i in opcoes.indices) {
            val t = TextView(context)
            t.text = opcoes[i]
            t.textSize = sp
            t.gravity = android.view.Gravity.CENTER
            t.typeface = FonteMedia
            t.setPadding(0, context.dp(10), 0, context.dp(10))
            t.setTextColor(Cores.SUAVE)
            t.setOnClickListener {
                definir(i)
                aoEscolher?.invoke(i)
            }
            addView(t, LayoutParams(0, AUTO, 1f))
            itens.add(t)
        }
    }

    /** Marca a opção i (use -1 para nenhuma). */
    fun definir(i: Int) {
        for (k in itens.indices) {
            val t = itens[k]
            if (k == i) {
                t.background = context.forma(cor, 11)
                t.setTextColor(Color.WHITE)
            } else {
                t.background = null
                t.setTextColor(Cores.SUAVE)
            }
        }
    }
}


fun Context.caixaIcone(tipo: String): FrameLayout {
    val f = FrameLayout(this)
    f.background = forma(Cores.SUPERFICIE2, 12, Cores.LINHA, 1)
    val ic = Icone(this, tipo)
    ic.cor = Cores.ACENTO
    f.addView(ic, FrameLayout.LayoutParams(AUTO, AUTO, Gravity.CENTER))
    return f
}

fun Context.botaoInfo(aoClicar: () -> Unit): FrameLayout {
    val f = FrameLayout(this)
    val ic = Icone(this, "info")
    ic.cor = Cores.SUAVE
    f.addView(ic, FrameLayout.LayoutParams(AUTO, AUTO, Gravity.CENTER))
    f.setOnClickListener { aoClicar() }
    return f
}

/** Gráfico de linha que rola sozinho a cada nova amostra (monitor em tempo real). */
class Grafico(ctx: Context) : View(ctx) {
    var rotulo = ""
    var maximo = 100f
    private var valorTexto = "—"
    private var corLinha = Cores.ACENTO
    private val pontos = ArrayList<Float>()
    private val capacidade = 36
    private var fase = 1f
    private var anim: ValueAnimator? = null
    private val linha = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
    }
    private val preench = Paint(Paint.ANTI_ALIAS_FLAG)
    private val grade = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Cores.LINHA; strokeWidth = 1f }
    private val tRot = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Cores.SUAVE }
    private val tVal = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Cores.TEXTO
        typeface = FonteMedia
        textAlign = Paint.Align.RIGHT
    }
    private val caminho = Path()
    private val area = Path()

    fun definirCor(c: Int) {
        corLinha = c
        refazerShader()
        invalidate()
    }

    private fun refazerShader() {
        if (height <= 0) return
        val topo = (corLinha and 0x00FFFFFF) or 0x66000000
        preench.shader = LinearGradient(0f, height * 0.3f, 0f, height.toFloat(), topo, Color.TRANSPARENT, Shader.TileMode.CLAMP)
    }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        super.onSizeChanged(w, h, ow, oh)
        refazerShader()
    }

    fun adicionar(v: Float, texto: String) {
        valorTexto = texto
        pontos.add(v.coerceAtLeast(0f))
        while (pontos.size > capacidade + 1) pontos.removeAt(0)
        anim?.cancel()
        val a = ValueAnimator.ofFloat(0f, 1f)
        a.duration = 900
        a.interpolator = LinearInterpolator()
        a.addUpdateListener { fase = it.animatedValue as Float; invalidate() }
        anim = a
        a.start()
    }

    override fun onMeasure(w: Int, h: Int) {
        setMeasuredDimension(MeasureSpec.getSize(w), context.dp(92))
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val d = context.dp(1).toFloat()
        val topo = h * 0.36f
        val base = h - 4f * d
        for (i in 0..2) {
            val y = topo + (base - topo) * i / 2f
            c.drawLine(0f, y, w, y, grade)
        }
        tRot.textSize = h * 0.13f
        c.drawText(rotulo, 10f * d, h * 0.22f, tRot)
        tVal.textSize = h * 0.22f
        c.drawText(valorTexto, w - 10f * d, h * 0.25f, tVal)
        if (pontos.size < 2) return
        val passo = w / (capacidade - 1).toFloat()
        caminho.reset()
        area.reset()
        var px = 0f
        var py = 0f
        for (i in pontos.indices) {
            val x = (i - fase) * passo
            val frac = (pontos[i] / maximo).coerceIn(0f, 1f)
            val y = base - (base - topo) * frac
            if (i == 0) {
                caminho.moveTo(x, y)
                area.moveTo(x, base)
                area.lineTo(x, y)
            } else {
                val mx = (px + x) / 2f
                caminho.cubicTo(mx, py, mx, y, x, y)
                area.cubicTo(mx, py, mx, y, x, y)
            }
            px = x
            py = y
        }
        area.lineTo(px, base)
        area.close()
        c.drawPath(area, preench)
        linha.color = corLinha
        linha.strokeWidth = 2f * d
        c.drawPath(caminho, linha)
    }
}

/** Controle deslizante com paradas fixas (ex.: Off, 60, 90, 120). */
class Passos(ctx: Context, private val rotulos: List<String>) : View(ctx) {
    var indice = 0
        private set
    var aoSoltar: ((Int) -> Unit)? = null
    private var posAnim = 0f
    private var anim: ValueAnimator? = null
    private val pFaixa = Paint(Paint.ANTI_ALIAS_FLAG).apply { strokeCap = Paint.Cap.ROUND }
    private val pBola = Paint(Paint.ANTI_ALIAS_FLAG)
    private val pTexto = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textAlign = Paint.Align.CENTER
        typeface = FonteMedia
    }

    fun definir(i: Int, animar: Boolean = false) {
        indice = i.coerceIn(0, rotulos.size - 1)
        mover(indice.toFloat(), animar)
    }

    private fun mover(alvo: Float, animar: Boolean) {
        anim?.cancel()
        if (animar) {
            val a = ValueAnimator.ofFloat(posAnim, alvo)
            a.duration = 160
            a.addUpdateListener { posAnim = it.animatedValue as Float; invalidate() }
            anim = a
            a.start()
        } else {
            posAnim = alvo
            invalidate()
        }
    }

    override fun onMeasure(w: Int, h: Int) {
        setMeasuredDimension(MeasureSpec.getSize(w), context.dp(64))
    }

    private fun xDe(i: Float): Float {
        val p = context.dp(22).toFloat()
        return p + i * (width - 2f * p) / (rotulos.size - 1).toFloat()
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.action) {
            MotionEvent.ACTION_DOWN -> {
                parent?.requestDisallowInterceptTouchEvent(true)
                escolher(e.x)
            }
            MotionEvent.ACTION_MOVE -> escolher(e.x)
            MotionEvent.ACTION_UP -> aoSoltar?.invoke(indice)
        }
        return true
    }

    private fun escolher(x: Float) {
        var melhor = 0
        var dist = Float.MAX_VALUE
        for (i in rotulos.indices) {
            val d = abs(xDe(i.toFloat()) - x)
            if (d < dist) {
                dist = d
                melhor = i
            }
        }
        if (melhor != indice) {
            indice = melhor
            mover(melhor.toFloat(), true)
        }
    }

    override fun onDraw(c: Canvas) {
        val d = context.dp(1).toFloat()
        pTexto.textSize = 13f * d
        for (i in rotulos.indices) {
            pTexto.color = if (i == indice) Neon.CIANO else Neon.SUAVE
            c.drawText(rotulos[i], xDe(i.toFloat()), 22f * d, pTexto)
        }
        val y = 44f * d
        pFaixa.strokeWidth = 2f * d
        pFaixa.color = Neon.BORDA
        c.drawLine(xDe(0f), y, xDe((rotulos.size - 1).toFloat()), y, pFaixa)
        pFaixa.color = Neon.CIANO
        c.drawLine(xDe(0f), y, xDe(posAnim), y, pFaixa)
        pBola.color = Neon.CIANO
        c.drawCircle(xDe(posAnim), y, 9f * d, pBola)
        pBola.color = Neon.CARTAO_A
        c.drawCircle(xDe(posAnim), y, 3.5f * d, pBola)
    }
}

/**
 * Caixinha de função: ícone, nome e estado. Quando ativa, o fundo ganha um brilho suave,
 * a borda e o ícone ficam na cor de destaque e o pontinho do canto acende (tudo animado).
 */
class Caixinha(
    ctx: Context,
    tipo: String,
    titulo: String,
    private val cor: Int = Cores.ACENTO,
    private val fundoOff: Int = Cores.SUPERFICIE,
    private val fundoOn: Int = Cores.SELECIONADO,
    private val bordaOff: Int = Cores.LINHA
) : LinearLayout(ctx) {
    var aoToque: (() -> Unit)? = null
    private var t = 0f
    private var ligada = false
    private var anim: ValueAnimator? = null
    private val icone = Icone(ctx, tipo)
    private val tvEstado: TextView
    private val pFundo = Paint(Paint.ANTI_ALIAS_FLAG)
    private val pBorda = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val pBrilho = Paint(Paint.ANTI_ALIAS_FLAG)
    private val pPonto = Paint(Paint.ANTI_ALIAS_FLAG)
    private val ret = RectF()

    init {
        orientation = VERTICAL
        setWillNotDraw(false)
        val p = ctx.dp(14)
        setPadding(p, p, p, p)
        addView(icone, LayoutParams(ctx.dp(24), ctx.dp(24)))
        addView(ctx.texto(titulo, 13f, Cores.TEXTO, true), ctx.lp(CHEIO, AUTO, 12, 0))
        tvEstado = ctx.texto("Desligado", 11.5f, Cores.SUAVE)
        addView(tvEstado, ctx.lp(CHEIO, AUTO, 2, 0))
        isClickable = true
        setOnClickListener { aoToque?.invoke() }
        pressionar()
    }

    fun definir(v: Boolean, estado: String, animar: Boolean = true) {
        ligada = v
        tvEstado.text = estado
        tvEstado.setTextColor(if (v) Cores.OK else Cores.SUAVE)
        anim?.cancel()
        if (animar) {
            val a = ValueAnimator.ofFloat(t, if (v) 1f else 0f)
            a.duration = 380
            a.interpolator = android.view.animation.DecelerateInterpolator(1.5f)
            a.addUpdateListener { t = it.animatedValue as Float; aplicarCor(); invalidate() }
            anim = a
            a.start()
        } else {
            t = if (v) 1f else 0f
            aplicarCor()
            invalidate()
        }
    }

    fun estaLigada(): Boolean = ligada

    private fun aplicarCor() {
        icone.cor = misturar(Cores.SUAVE, cor, t)
    }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        super.onSizeChanged(w, h, ow, oh)
        pBrilho.shader = RadialGradient(
            w * 0.18f, h * 0.22f, w * 0.75f,
            comAlfa(cor, 0x33), comAlfa(cor, 0x00), Shader.TileMode.CLAMP
        )
    }

    override fun onDraw(c: Canvas) {
        val d = context.dp(1).toFloat()
        ret.set(d, d, width - d, height - d)
        val r = context.dp(18).toFloat()
        pFundo.color = misturar(fundoOff, fundoOn, t)
        c.drawRoundRect(ret, r, r, pFundo)
        pBrilho.alpha = (t * 255f).toInt()
        c.drawRoundRect(ret, r, r, pBrilho)
        pBorda.strokeWidth = d
        pBorda.color = misturar(bordaOff, comAlfa(cor, 0x99), t)
        c.drawRoundRect(ret, r, r, pBorda)
        val cx = width - context.dp(16).toFloat()
        val cy = height - context.dp(16).toFloat()
        pPonto.color = misturar(Cores.LINHA, Cores.OK, t)
        pPonto.alpha = 60 + (t * 195f).toInt()
        c.drawCircle(cx, cy, context.dp(4).toFloat(), pPonto)
    }
}

/** Uma barra por núcleo da CPU: sobe e desce com a frequência, com seta de tendência. */
class Nucleos(ctx: Context) : View(ctx) {
    private var alvo = FloatArray(0)
    private var atual = FloatArray(0)
    private var mhz = IntArray(0)
    private var tend = IntArray(0)
    private var anim: ValueAnimator? = null
    private val faixa = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Cores.SUPERFICIE2 }
    private val barra = Paint(Paint.ANTI_ALIAS_FLAG)
    private val txt = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textAlign = Paint.Align.CENTER
        color = Cores.SUAVE
    }
    private val seta = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val ret = RectF()

    fun definir(freq: List<Int>, maxFreq: List<Int>) {
        val n = freq.size
        if (n == 0) return
        val novo = FloatArray(n)
        val maiorGeral = maxFreq.maxOrNull() ?: 0
        for (i in 0 until n) {
            val m = if (maxFreq.size == n) maxFreq[i] else maiorGeral
            novo[i] = if (m > 0) (freq[i].toFloat() / m).coerceIn(0f, 1f) else 0f
        }
        if (atual.size != n) {
            atual = FloatArray(n)
            alvo = FloatArray(n)
            tend = IntArray(n)
        }
        for (i in 0 until n) {
            val dif = novo[i] - alvo[i]
            tend[i] = if (dif > 0.06f) 1 else if (dif < -0.06f) -1 else 0
        }
        val de = atual.copyOf()
        alvo = novo
        mhz = freq.toIntArray()
        anim?.cancel()
        val a = ValueAnimator.ofFloat(0f, 1f)
        a.duration = 700
        a.interpolator = android.view.animation.DecelerateInterpolator(1.4f)
        a.addUpdateListener {
            val f = it.animatedValue as Float
            for (i in atual.indices) atual[i] = de[i] + (alvo[i] - de[i]) * f
            invalidate()
        }
        anim = a
        a.start()
    }

    override fun onMeasure(w: Int, h: Int) {
        setMeasuredDimension(MeasureSpec.getSize(w), context.dp(104))
    }

    override fun onDraw(c: Canvas) {
        val n = atual.size
        if (n == 0) return
        val d = context.dp(1).toFloat()
        val w = width.toFloat()
        val h = height.toFloat()
        val gap = 6f * d
        val bw = (w - gap * (n - 1)) / n
        val topo = 26f * d
        val base = h - 16f * d
        txt.textSize = 9.5f * d
        for (i in 0 until n) {
            val x = i * (bw + gap)
            ret.set(x, topo, x + bw, base)
            c.drawRoundRect(ret, 6f * d, 6f * d, faixa)
            val f = atual[i].coerceIn(0f, 1f)
            val altura = (base - topo) * f
            if (altura > 1f) {
                barra.color = if (f < 0.5f) misturar(Cores.OK, Cores.AMBAR, f / 0.5f)
                else misturar(Cores.AMBAR, Cores.ACENTO, (f - 0.5f) / 0.5f)
                ret.set(x, base - altura, x + bw, base)
                c.drawRoundRect(ret, 6f * d, 6f * d, barra)
            }
            c.drawText(if (i < mhz.size) mhz[i].toString() else "", x + bw / 2f, 14f * d, txt)
            desenharSeta(c, x + bw / 2f, 21f * d, 2.6f * d, tend[i], seta)
            c.drawText("N$i", x + bw / 2f, h - 3f * d, txt)
        }
    }
}


/**
 * Cartão de métrica do painel novo: ícone e nome, anel em degradê com brilho,
 * valor no centro, variação (seta + %) e mini-gráfico com as últimas leituras.
 */
class CartaoMetrica(
    ctx: Context,
    tipoIcone: String,
    private val rotulo: String,
    private val corA: Int,
    private val corB: Int
) : View(ctx) {
    var unidade = ""
    private var texto = "—"
    private var atual = 0f
    private var anterior = -1f
    private var delta = 0
    private var anim: ValueAnimator? = null
    private val hist = ArrayList<Float>()
    private val icone = Icone(ctx, tipoIcone)

    private val pFundo = Paint(Paint.ANTI_ALIAS_FLAG)
    private val pBorda = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        color = Neon.BORDA
    }
    private val pTrilha = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        color = 0xFF222A45.toInt()
    }
    private val pArco = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
    }
    private val pBrilho = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        alpha = 60
    }
    private val pRot = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Neon.TEXTO
        typeface = FonteTitulo
    }
    private val pNum = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Neon.TEXTO
        typeface = FonteTitulo
    }
    private val pUni = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Neon.SUAVE
        typeface = FonteMedia
    }
    private val pDelta = Paint(Paint.ANTI_ALIAS_FLAG).apply { typeface = FonteMedia }
    private val pSeta = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
    }
    private val pLinha = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
        color = corA
    }
    private val pFill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val area = RectF()
    private val ret = RectF()
    private val caminho = Path()
    private val sombra = Path()

    fun definir(frac: Float, valor: String) {
        texto = valor
        val alvo = frac.coerceIn(0f, 1f)
        if (anterior >= 0f) delta = Math.round((alvo - anterior) * 100f)
        anterior = alvo
        hist.add(alvo)
        while (hist.size > 24) hist.removeAt(0)
        anim?.cancel()
        val a = ValueAnimator.ofFloat(atual, alvo)
        a.duration = 700
        a.interpolator = android.view.animation.DecelerateInterpolator(1.4f)
        a.addUpdateListener { atual = it.animatedValue as Float; invalidate() }
        anim = a
        a.start()
    }

    override fun onMeasure(w: Int, h: Int) {
        val larg = if (MeasureSpec.getMode(w) == MeasureSpec.UNSPECIFIED) context.dp(100) else MeasureSpec.getSize(w)
        setMeasuredDimension(larg, (larg * 1.4f).toInt())
    }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        super.onSizeChanged(w, h, ow, oh)
        val fw = w.toFloat()
        val fh = h.toFloat()
        pFundo.shader = LinearGradient(0f, 0f, fw, fh, Neon.CARTAO_A, Neon.CARTAO_B, Shader.TileMode.CLAMP)
        val cx = fw / 2f
        val cy = fw * 0.62f
        val sw = SweepGradient(cx, cy, intArrayOf(corA, corB), floatArrayOf(0f, 1f))
        val m = Matrix()
        m.setRotate(-90f, cx, cy)
        sw.setLocalMatrix(m)
        pArco.shader = sw
        pBrilho.shader = sw
        pFill.shader = LinearGradient(
            0f, fw * 1.17f, 0f, fh - fw * 0.09f,
            comAlfa(corA, 0x55), Color.TRANSPARENT, Shader.TileMode.CLAMP
        )
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        if (w <= 0f) return
        val d = context.dp(1).toFloat()

        // fundo e borda
        val r = w * 0.17f
        ret.set(d, d, w - d, h - d)
        c.drawRoundRect(ret, r, r, pFundo)
        pBorda.strokeWidth = d
        c.drawRoundRect(ret, r, r, pBorda)

        // cabeçalho: ícone + nome
        val pad = w * 0.09f
        val ic = w * 0.17f
        icone.cor = corA
        icone.layout(0, 0, ic.toInt(), ic.toInt())
        c.save()
        c.translate(pad, pad)
        icone.draw(c)
        c.restore()
        pRot.textSize = w * 0.14f
        c.drawText(rotulo, pad + ic + w * 0.05f, pad + ic / 2f + pRot.textSize * 0.35f, pRot)

        // anel em degradê com brilho
        val cx = w / 2f
        val cy = w * 0.62f
        val rad = w * 0.27f
        val esp = w * 0.075f
        pTrilha.strokeWidth = esp
        pArco.strokeWidth = esp
        pBrilho.strokeWidth = esp * 2f
        area.set(cx - rad, cy - rad, cx + rad, cy + rad)
        c.drawCircle(cx, cy, rad, pTrilha)
        if (atual > 0.004f) {
            c.drawArc(area, -90f, 360f * atual, false, pBrilho)
            c.drawArc(area, -90f, 360f * atual, false, pArco)
        }

        // valor no centro
        val pct = unidade == "%"
        val maxL = (rad * 2f - esp) * 0.9f
        var tam = w * 0.24f
        while (tam > w * 0.10f) {
            pNum.textSize = tam
            pUni.textSize = tam * 0.5f
            val larg = pNum.measureText(texto) + (if (pct) pUni.measureText("%") else 0f)
            if (larg <= maxL) break
            tam -= 1f
        }
        pNum.textSize = tam
        if (pct) {
            pUni.textSize = tam * 0.5f
            val total = pNum.measureText(texto) + pUni.measureText("%")
            val x0 = cx - total / 2f
            val base = cy + tam * 0.36f
            c.drawText(texto, x0, base, pNum)
            c.drawText("%", x0 + pNum.measureText(texto), base, pUni)
        } else {
            c.drawText(texto, cx - pNum.measureText(texto) / 2f, cy + tam * 0.12f, pNum)
            pUni.textSize = w * 0.095f
            c.drawText(unidade, cx - pUni.measureText(unidade) / 2f, cy + w * 0.185f, pUni)
        }

        // variação: seta + %
        val yD = w * 1.07f
        pDelta.textSize = w * 0.125f
        val txt = "${abs(delta)}%"
        val tw = pDelta.measureText(txt)
        val aw = w * 0.09f
        val gap = w * 0.03f
        val xi = cx - (aw + gap + tw) / 2f
        val yc = yD - pDelta.textSize * 0.34f
        val corD = if (delta > 0) Neon.OK else if (delta < 0) corA else Neon.SUAVE
        pSeta.color = corD
        pDelta.color = corD
        pSeta.strokeWidth = d * 1.8f
        val ax = xi + aw / 2f
        val ah = aw * 0.5f
        if (delta > 0) {
            c.drawLine(ax, yc + ah, ax, yc - ah, pSeta)
            c.drawLine(ax - ah * 0.8f, yc - ah * 0.1f, ax, yc - ah, pSeta)
            c.drawLine(ax + ah * 0.8f, yc - ah * 0.1f, ax, yc - ah, pSeta)
        } else if (delta < 0) {
            c.drawLine(ax, yc - ah, ax, yc + ah, pSeta)
            c.drawLine(ax - ah * 0.8f, yc + ah * 0.1f, ax, yc + ah, pSeta)
            c.drawLine(ax + ah * 0.8f, yc + ah * 0.1f, ax, yc + ah, pSeta)
        } else {
            c.drawLine(ax - ah, yc, ax + ah, yc, pSeta)
        }
        c.drawText(txt, xi + aw + gap, yD, pDelta)

        // mini-gráfico das últimas leituras
        if (hist.size >= 2) {
            val xa = pad
            val xb = w - pad
            val yT = w * 1.17f
            val yB = h - w * 0.09f
            var lo = hist[0]
            var hi = hist[0]
            for (v in hist) {
                if (v < lo) lo = v
                if (v > hi) hi = v
            }
            val span = maxOf(hi - lo, 0.08f)
            val mid = (hi + lo) / 2f
            val passo = (xb - xa) / (hist.size - 1).toFloat()
            caminho.reset()
            sombra.reset()
            var px = 0f
            var py = 0f
            for (i in hist.indices) {
                val x = xa + i * passo
                val y = (yT + yB) / 2f - (hist[i] - mid) / span * (yB - yT)
                if (i == 0) {
                    caminho.moveTo(x, y)
                    sombra.moveTo(x, yB)
                    sombra.lineTo(x, y)
                } else {
                    val mx = (px + x) / 2f
                    caminho.cubicTo(mx, py, mx, y, x, y)
                    sombra.cubicTo(mx, py, mx, y, x, y)
                }
                px = x
                py = y
            }
            sombra.lineTo(px, yB)
            sombra.close()
            c.drawPath(sombra, pFill)
            pLinha.strokeWidth = d * 1.8f
            c.drawPath(caminho, pLinha)
        }
    }
}
