package br.com.rootboost

import android.content.Context
import android.graphics.Color
import java.util.Locale

/** Ajuste de cor da tela (saturação, contraste, brilho e ganho RGB) via SurfaceFlinger. */
object Cor {
    class Ajuste(val sat: Float, val con: Float, val bri: Float, val r: Float, val g: Float, val b: Float)
    class Preset(val id: String, val nome: String, val ajuste: Ajuste, val amostra: Int, val desc: String = "")

    val ORIGINAL = Ajuste(1f, 1f, 0f, 1f, 1f, 1f)

    val presets = listOf(
        Preset("original", "Original", ORIGINAL, 0xFF8D93A0.toInt(), "Cores do jogo, sem filtro"),
        Preset("natural", "Natural", Ajuste(1.08f, 1.04f, 0f, 1f, 1f, 1f), 0xFF6FCF97.toInt(), "Um toque de vida, sem exagero"),
        Preset("nitido", "Nítido", Ajuste(1.12f, 1.16f, 0f, 1f, 1f, 1f), 0xFF56CCF2.toInt(), "Mais contraste e bordas claras"),
        Preset("competitivo", "Competitivo", Ajuste(1.2f, 1.22f, 0.02f, 1f, 1f, 1f), 0xFF4CD9A0.toInt(), "Destaca inimigos e sombras"),
        Preset("cinema", "Cinema", Ajuste(1.1f, 1.12f, -0.02f, 1.03f, 1f, 0.95f), 0xFFC9A66B.toInt(), "Tom quente, clima de filme"),
        Preset("suave", "Suave", Ajuste(0.9f, 0.96f, 0.01f, 1f, 1f, 1f), 0xFF8FB7FF.toInt(), "Cores calmas, cansa menos a vista"),
        Preset("frio", "Frio", Ajuste(1.05f, 1.05f, 0f, 0.94f, 1f, 1.08f), 0xFF5BC0FF.toInt(), "Tom azulado e limpo"),
        Preset("quente", "Quente", Ajuste(1.05f, 1.04f, 0f, 1.06f, 1f, 0.92f), 0xFFFFA45B.toInt(), "Tom dourado e aconchegante"),
        Preset("noite", "Noite", Ajuste(1f, 1f, -0.03f, 1f, 0.92f, 0.76f), 0xFFFFB347.toInt(), "Menos luz azul à noite"),
        Preset("pastel", "Pastel", Ajuste(0.8f, 0.92f, 0.03f, 1f, 1f, 1f), 0xFFF2B5D4.toInt(), "Cores leves e claras"),
        Preset("vivo", "Vívido", Ajuste(1.3f, 1.06f, 0f, 1f, 1f, 1f), 0xFFFF5B1F.toInt(), "Cores fortes (use força Sutil)"),
        Preset("pb", "Preto e branco", Ajuste(0f, 1.1f, 0f, 1f, 1f, 1f), 0xFF9AA0AA.toInt(), "Sem cor, só contraste")
    )

    fun preset(id: String): Preset? = presets.firstOrNull { it.id == id }

    /** Aproxima o ajuste do original: k = 0 não muda nada, 1 é o preset inteiro, acima de 1 exagera. */
    fun mesclar(a: Ajuste, k: Float): Ajuste {
        fun m(o: Float, v: Float) = o + (v - o) * k
        return Ajuste(m(1f, a.sat), m(1f, a.con), m(0f, a.bri), m(1f, a.r), m(1f, a.g), m(1f, a.b))
    }

    /** Mostra como uma cor ficaria com o ajuste (usado nas prévias, sem imagens). */
    fun transformar(cor: Int, a: Ajuste): Int {
        val r0 = Color.red(cor) / 255f
        val g0 = Color.green(cor) / 255f
        val b0 = Color.blue(cor) / 255f
        val lum = 0.299f * r0 + 0.587f * g0 + 0.114f * b0
        val t = 0.5f * (1f - a.con) + a.bri
        val r = ((lum + (r0 - lum) * a.sat) * a.con * a.r + t).coerceIn(0f, 1f)
        val g = ((lum + (g0 - lum) * a.sat) * a.con * a.g + t).coerceIn(0f, 1f)
        val b = ((lum + (b0 - lum) * a.sat) * a.con * a.b + t).coerceIn(0f, 1f)
        return Color.rgb(Math.round(r * 255f), Math.round(g * 255f), Math.round(b * 255f))
    }

    /** Força do filtro (0.5 sutil, 1 normal, 1.5 forte). */
    fun forca(ctx: Context): Float = lerF(ctx, "cor_forca", 1f)

    fun salvarForca(ctx: Context, k: Float) = Prefs.putStr(ctx, "cor_forca", k.toString())

    /** Aplica um preset pelo id (com a força escolhida). Devolve false se o id não existe. */
    fun aplicarPreset(ctx: Context, id: String): Boolean {
        val p = preset(id) ?: return false
        aplicar(mesclar(p.ajuste, forca(ctx)))
        return true
    }

    private fun lerF(ctx: Context, k: String, padrao: Float): Float =
        Prefs.str(ctx, k, padrao.toString()).toFloatOrNull() ?: padrao

    fun salvo(ctx: Context): Ajuste = Ajuste(
        lerF(ctx, "cor_sat", 1f), lerF(ctx, "cor_con", 1f), lerF(ctx, "cor_bri", 0f),
        lerF(ctx, "cor_r", 1f), lerF(ctx, "cor_g", 1f), lerF(ctx, "cor_b", 1f)
    )

    fun salvar(ctx: Context, a: Ajuste) {
        Prefs.putStr(ctx, "cor_sat", a.sat.toString())
        Prefs.putStr(ctx, "cor_con", a.con.toString())
        Prefs.putStr(ctx, "cor_bri", a.bri.toString())
        Prefs.putStr(ctx, "cor_r", a.r.toString())
        Prefs.putStr(ctx, "cor_g", a.g.toString())
        Prefs.putStr(ctx, "cor_b", a.b.toString())
    }

    private fun f(v: Float): String = String.format(Locale.US, "%.3f", v)

    fun aplicar(a: Ajuste): String {
        val dr = a.con * a.r
        val dg = a.con * a.g
        val db = a.con * a.b
        val t = 0.5f * (1f - a.con) + a.bri
        // matriz 4x4 em colunas: ganho nas diagonais, deslocamento na última coluna
        val matriz = "service call SurfaceFlinger 1015 i32 1 " +
            "f ${f(dr)} f 0 f 0 f 0 " +
            "f 0 f ${f(dg)} f 0 f 0 " +
            "f 0 f 0 f ${f(db)} f 0 " +
            "f ${f(t)} f ${f(t)} f ${f(t)} f 1"
        val sat = "service call SurfaceFlinger 1022 f ${f(a.sat)}"
        RootShell.run(matriz + "\n" + sat) ?: return "Sem acesso root."
        return "Cores aplicadas."
    }
}
