package br.com.rootboost

import android.app.Activity
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.graphics.drawable.Drawable
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.TextView

/** Escolhe apps para uma lista: "jogos" (Game Turbo) ou "protegidos" (limpeza profunda). */
class GamesActivity : Activity() {

    private class Item(val pkg: String, val nome: String, val icone: Drawable?, val ehJogo: Boolean, var marcado: Boolean)

    private val todos = ArrayList<Item>()
    private val visiveis = ArrayList<Item>()
    private val escolhidos = HashSet<String>()
    private var chave = "jogos"
    private lateinit var adaptador: BaseAdapter
    private lateinit var tvContagem: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        chave = when (intent.getStringExtra("modo")) {
            "protegidos" -> "protegidos"
            "atalhos" -> "atalhos"
            else -> "jogos"
        }
        escolhidos.addAll(Prefs.lista(this, chave))

        val raiz = LinearLayout(this)
        raiz.orientation = LinearLayout.VERTICAL
        raiz.setBackgroundColor(Cores.FUNDO)
        aplicarInsets(raiz)

        val cabeca = LinearLayout(this)
        cabeca.orientation = LinearLayout.VERTICAL
        cabeca.setPadding(dp(20), dp(24), dp(20), dp(8))
        val titulo = when (chave) {
            "jogos" -> "Escolher jogos"
            "atalhos" -> "Apps rápidos"
            else -> "Apps protegidos"
        }
        val subtitulo = when (chave) {
            "jogos" -> "Os jogos marcados ativam o Game Turbo."
            "atalhos" -> "Os apps marcados abrem em janela flutuante por cima do jogo e ficam protegidos contra fechamento."
            else -> "Apps marcados nunca são encerrados pela limpeza profunda."
        }
        cabeca.addView(texto(titulo, 26f, Cores.TEXTO, true))
        cabeca.addView(texto(subtitulo, 13f, Cores.SUAVE), lp(CHEIO, AUTO, 4, 4))
        tvContagem = texto("", 12f, Cores.ACENTO, true)
        cabeca.addView(tvContagem, lp(CHEIO, AUTO, 0, 12))

        val busca = EditText(this)
        busca.hint = "Buscar app"
        busca.setHintTextColor(Cores.SUAVE)
        busca.setTextColor(Cores.TEXTO)
        busca.textSize = 15f
        busca.isSingleLine = true
        busca.setPadding(dp(16), dp(12), dp(16), dp(12))
        busca.background = forma(Cores.SUPERFICIE, 16, Cores.LINHA, 1)
        cabeca.addView(busca, lp(CHEIO, AUTO, 0, 4))
        raiz.addView(cabeca)

        val lista = ListView(this)
        lista.divider = null
        lista.dividerHeight = 0
        lista.clipToPadding = false
        lista.setPadding(dp(12), 0, dp(12), dp(16))
        adaptador = object : BaseAdapter() {
            override fun getCount() = visiveis.size
            override fun getItem(p: Int): Any = visiveis[p]
            override fun getItemId(p: Int) = p.toLong()
            override fun getView(p: Int, v: View?, pai: ViewGroup?): View {
                val item = visiveis[p]
                val linha = (v as? LinearLayout) ?: criarLinha()
                (linha.getChildAt(0) as ImageView).setImageDrawable(item.icone)
                (linha.getChildAt(1) as TextView).text = item.nome
                (linha.getChildAt(2) as Chave).definir(item.marcado)
                linha.background = if (item.marcado) forma(Cores.SELECIONADO, 14) else null
                return linha
            }
        }
        lista.adapter = adaptador
        lista.setOnItemClickListener { _, _, pos, _ ->
            val item = visiveis[pos]
            item.marcado = !item.marcado
            if (item.marcado) escolhidos.add(item.pkg) else escolhidos.remove(item.pkg)
            Prefs.setLista(this, chave, escolhidos)
            adaptador.notifyDataSetChanged()
            atualizarContagem()
        }
        raiz.addView(lista, LinearLayout.LayoutParams(CHEIO, 0, 1f))
        setContentView(raiz)
        atualizarContagem()

        busca.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) { filtrar(s?.toString() ?: "") }
        })

        Thread {
            val pm = packageManager
            val intencao = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
            @Suppress("DEPRECATION")
            val itens = pm.queryIntentActivities(intencao, 0)
                .filter { it.activityInfo.packageName != packageName }
                .map {
                    val ai = it.activityInfo.applicationInfo
                    val jogo = ai.category == ApplicationInfo.CATEGORY_GAME || (ai.flags and ApplicationInfo.FLAG_IS_GAME) != 0
                    Item(
                        it.activityInfo.packageName,
                        it.loadLabel(pm).toString(),
                        it.loadIcon(pm),
                        jogo,
                        escolhidos.contains(it.activityInfo.packageName)
                    )
                }
                .distinctBy { it.pkg }
                .sortedWith(
                    compareByDescending<Item> { it.marcado }
                        .thenByDescending { it.ehJogo && chave == "jogos" }
                        .thenBy { it.nome.lowercase() }
                )
            runOnUiThread {
                todos.clear()
                todos.addAll(itens)
                filtrar(busca.text.toString())
            }
        }.start()
    }

    private fun criarLinha(): LinearLayout {
        val l = LinearLayout(this)
        l.orientation = LinearLayout.HORIZONTAL
        l.gravity = Gravity.CENTER_VERTICAL
        l.setPadding(dp(12), dp(10), dp(12), dp(10))
        l.addView(ImageView(this), LinearLayout.LayoutParams(dp(40), dp(40)))
        val nome = lp(0, AUTO, 0, 0)
        nome.weight = 1f
        nome.leftMargin = dp(14)
        nome.rightMargin = dp(8)
        l.addView(texto("", 15f), nome)
        val c = Chave(this)
        c.somenteExibir()
        l.addView(c)
        return l
    }

    private fun filtrar(q: String) {
        visiveis.clear()
        visiveis.addAll(todos.filter { q.isBlank() || it.nome.contains(q.trim(), ignoreCase = true) })
        adaptador.notifyDataSetChanged()
    }

    private fun atualizarContagem() {
        tvContagem.text = "${escolhidos.size} marcados • toque para marcar ou desmarcar"
    }
}
