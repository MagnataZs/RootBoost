package br.com.rootboost

import java.io.BufferedReader
import java.io.InputStreamReader
import java.io.OutputStreamWriter

/** Um único shell `su` reaproveitado: evita abrir um processo root a cada comando. */
object RootShell {
    private var processo: Process? = null
    private var escritor: OutputStreamWriter? = null
    private var leitor: BufferedReader? = null
    private const val FIM = "__RB_FIM__"

    @Synchronized
    private fun garantir(): Boolean {
        val p = processo
        if (p != null && p.isAlive) return true
        return try {
            val novo = ProcessBuilder("su").redirectErrorStream(true).start()
            processo = novo
            escritor = OutputStreamWriter(novo.outputStream)
            leitor = BufferedReader(InputStreamReader(novo.inputStream))
            true
        } catch (e: Exception) {
            processo = null
            false
        }
    }

    @Synchronized
    private fun fechar() {
        try { processo?.destroy() } catch (e: Exception) { }
        processo = null
        escritor = null
        leitor = null
    }

    /** Roda o script como root e devolve a saída (stdout + stderr). Null se não houver root. */
    @Synchronized
    fun run(script: String): String? {
        if (!garantir()) return null
        val w = escritor ?: return null
        val r = leitor ?: return null
        return try {
            w.write(script)
            w.write("\necho $FIM\n")
            w.flush()
            val sb = StringBuilder()
            var resultado: String? = null
            while (true) {
                val linha = r.readLine() ?: break
                if (linha == FIM) {
                    resultado = sb.toString().trimEnd()
                    break
                }
                sb.append(linha).append('\n')
            }
            if (resultado == null) fechar()
            resultado
        } catch (e: Exception) {
            fechar()
            null
        }
    }

    fun root(): Boolean = run("id")?.contains("uid=0") == true
}

/** Nos scripts, § vira $ (evita conflito com templates de string do Kotlin). */
fun sh(s: String): String = s.replace('§', '$')
