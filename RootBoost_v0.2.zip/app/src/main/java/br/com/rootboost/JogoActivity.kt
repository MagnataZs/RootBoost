package br.com.rootboost

import android.app.Activity
import android.app.AlertDialog
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

/**
 * Ajustes de um jogo só: perfil, resolução, FPS alvo, modo do sistema, driver gráfico,
 * filtro de cor e funções próprias. Cada jogo da lista pode ter o seu jeito.
 */
class JogoActivity : Activity() {

    private lateinit var pkg: String
    private var nome = ""
    private val avancados = ArrayList<View>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val p = intent.getStringExtra("pkg")
        if (p == null) {
            finish()
            return
        }
        pkg = p
        nome = try {
            packageManager.getApplicationLabel(packageManager.getApplicationInfo(pkg, 0)).toString()
        } catch (e: Exception) {
            pkg
        }
        montar()
    }

    private fun montar() {
        val raiz = LinearLayout(this)
        raiz.orientation = LinearLayout.VERTICAL
        raiz.setBackgroundColor(0xFF080B16.toInt())
        val col = vertical()
        col.setPadding(dp(18), dp(14), dp(18), dp(28))

        // topo
        val topo = horizontal()
        val voltar = texto("‹", 32f, Neon.TEXTO, true)
        voltar.setPadding(0, 0, dp(14), dp(4))
        voltar.setOnClickListener { finish() }
        topo.addView(voltar)
        val ic = ImageView(this)
        try {
            ic.setImageDrawable(packageManager.getApplicationIcon(pkg))
        } catch (e: Exception) {
            // sem ícone
        }
        topo.addView(ic, LinearLayout.LayoutParams(dp(52), dp(52)))
        val tx = vertical()
        tx.addView(titulo(nome, 22f))
        val conhecido = Jogos.conhecido(pkg)
        tx.addView(
            texto(
                if (conhecido != null) "Otimização pronta para este jogo" else pkg, 11.5f,
                if (conhecido != null) Neon.OK else Neon.SUAVE
            ),
            lp(CHEIO, AUTO, 1, 0)
        )
        topo.addView(tx, LinearLayout.LayoutParams(0, AUTO, 1f).apply { leftMargin = dp(12) })
        col.addView(topo, lp(CHEIO, AUTO, 0, 14))

        // modo seguro
        val seguro = Prefs.modoSeguro(this, pkg)
        col.addView(cartaoSeguro(seguro), lp(CHEIO, AUTO, 0, 12))
        col.addView(cartaoEmulador(), lp(CHEIO, AUTO, 0, 12))

        // sugestão pronta
        val sug = Jogos.sugestaoPara(this, pkg)
        val cs = cartaoNeon()
        cs.addView(titulo("Sugestão do RootBoost", 16f, Neon.CIANO))
        cs.addView(texto(sug.nota, 12.5f, Neon.TEXTO), lp(CHEIO, AUTO, 4, 0))
        cs.addView(texto(resumoSugestao(sug, seguro), 11.5f, Neon.SUAVE), lp(CHEIO, AUTO, 4, 12))
        cs.addView(botaoPrimario("Aplicar sugestão") { aplicarSugestao(sug, seguro) }, lp(CHEIO, dp(44), 0, 0))
        col.addView(cs)

        // desempenho
        col.addView(secaoNeon("Desempenho"), lp(CHEIO, AUTO, 22, 10))

        val segPerfil = Segmentado(this, Tuner.perfis.map { it.nome }, 11f, Neon.AZUL, Neon.CARTAO_B)
        segPerfil.definir(Tuner.perfis.indexOfFirst { it.id == Prefs.perfilJogo(this, pkg) })
        segPerfil.aoEscolher = { i -> Prefs.setPerfilJogo(this, pkg, Tuner.perfis[i].id) }
        col.addView(
            bloco(
                "Perfil de desempenho",
                "O perfil de CPU e GPU que entra quando este jogo abre. Ao sair do jogo, tudo volta ao normal.",
                segPerfil
            ),
            lp(CHEIO, AUTO, 0, 10)
        )

        val escalas = listOf(100, 90, 80, 70, 60, 50)
        val segEsc = Segmentado(this, escalas.map { "$it%" }, 11f, Neon.ROXO, Neon.CARTAO_B)
        segEsc.definir(escalas.indexOf(Prefs.escalaJogo(this, pkg)).coerceAtLeast(0))
        segEsc.aoEscolher = { i ->
            Prefs.setEscalaJogo(this, pkg, escalas[i])
            aplicarModoJogo()
        }
        col.addView(
            bloco(
                "Resolução do jogo",
                "Reduz a resolução em que o jogo é desenhado (Android 12 ou mais novo). Menos resolução alivia a GPU, esquenta menos e segura o FPS. 100% é o normal. Vale na próxima vez que abrir o jogo e depende da ROM aceitar.",
                segEsc,
                true
            ),
            lp(CHEIO, AUTO, 0, 10)
        )

        val fpsLista = listOf(0, 30, 45, 60, 90, 120)
        val segFps = Segmentado(this, listOf("Padrão", "30", "45", "60", "90", "120"), 11f, Neon.ROXO, Neon.CARTAO_B)
        segFps.definir(fpsLista.indexOf(Prefs.fpsJogo(this, pkg)).coerceAtLeast(0))
        segFps.aoEscolher = { i ->
            Prefs.setFpsJogo(this, pkg, fpsLista[i])
            aplicarModoJogo()
        }
        col.addView(
            bloco(
                "FPS alvo",
                "Pede ao Android para limitar o jogo a esse FPS (modo jogo do sistema). FPS menor e estável costuma ser melhor do que FPS alto que oscila. Depende da ROM aceitar.",
                segFps,
                true
            ),
            lp(CHEIO, AUTO, 0, 10)
        )

        val segModo = Segmentado(this, listOf("Padrão", "Desempenho", "Bateria"), 11f, Neon.ROXO, Neon.CARTAO_B)
        segModo.definir(Prefs.modoJogo(this, pkg).coerceIn(0, 2))
        segModo.aoEscolher = { i ->
            Prefs.setModoJogo(this, pkg, i)
            aplicarModoJogo()
        }
        col.addView(
            bloco(
                "Modo jogo do sistema",
                "Usa o modo jogo do Android para este jogo: Desempenho prioriza FPS, Bateria prioriza autonomia.",
                segModo,
                true
            ),
            lp(CHEIO, AUTO, 0, 10)
        )

        // gráficos
        col.addView(secaoNeon("Gráficos"), lp(CHEIO, AUTO, 22, 10))

        val segDriver = Segmentado(this, listOf("Padrão", "Game Driver", "ANGLE"), 11.5f, Neon.AZUL, Neon.CARTAO_B)
        segDriver.definir(Prefs.driverJogo(this, pkg).coerceIn(0, 2))
        segDriver.aoEscolher = { i ->
            Prefs.setDriverJogo(this, pkg, i)
            emBg { Tuner.aplicarDriversPorJogo(this) }
        }
        col.addView(
            bloco(
                "Driver gráfico (Vulkan)",
                "Game Driver usa o driver atualizável da GPU, quando o aparelho tem. ANGLE roda jogos OpenGL ES por cima do Vulkan do aparelho, o que pode ajudar ou piorar conforme o jogo. Vale ao abrir o jogo de novo. Se o jogo tiver a opção Vulkan nos gráficos dele, escolha lá também.",
                segDriver,
                true
            ),
            lp(CHEIO, AUTO, 0, 10)
        )

        col.addView(blocoFiltro(), lp(CHEIO, AUTO, 0, 10))

        val efeitos = cartaoNeon()
        efeitos.addView(texto("Bloom, motion blur e sombras", 14f, Neon.TEXTO, true))
        efeitos.addView(
            texto(
                "Esses efeitos ficam nas configurações gráficas do próprio jogo, e o Android não deixa outro app desligar. Para aliviar a GPU por aqui, use resolução menor e FPS alvo.",
                12f, Neon.SUAVE
            ),
            lp(CHEIO, AUTO, 4, 0)
        )
        col.addView(efeitos)

        // funções
        col.addView(secaoNeon("Funções neste jogo"), lp(CHEIO, AUTO, 22, 10))
        col.addView(
            texto("Ligue só o que este jogo precisa. Sem escolha própria, vale a lista geral da aba Funções.", 12f, Neon.SUAVE),
            lp(CHEIO, AUTO, 0, 10)
        )
        for (m in Modulos.visiveis(this)) col.addView(linhaFuncao(m), lp(CHEIO, AUTO, 0, 8))

        // dentro do jogo
        val tituloDentro = secaoNeon("Dentro do jogo")
        avancados.add(tituloDentro)
        col.addView(tituloDentro, lp(CHEIO, AUTO, 18, 10))
        val linhaOverlay = linhaChave(
            "Mostrar FPS e painel", "Desligado: nada é desenhado por cima deste jogo.", !Prefs.semOverlay(this, pkg)
        ) { v -> Prefs.setSemOverlay(this, pkg, !v) }
        avancados.add(linhaOverlay)
        col.addView(linhaOverlay)

        col.addView(botaoSecundario("Restaurar este jogo") { restaurarJogo() }, lp(CHEIO, dp(46), 22, 0))
        col.addView(
            texto("RootBoost 0.7 • por Diparis / MagnataZs", 11f, Neon.SUAVE),
            lp(CHEIO, AUTO, 16, 0)
        )

        if (seguro) for (v in avancados) v.visibility = View.GONE
        val rolagem = ScrollView(this)
        rolagem.isVerticalScrollBarEnabled = false
        rolagem.addView(col)
        raiz.addView(rolagem, LinearLayout.LayoutParams(CHEIO, 0, 1f))
        aplicarInsets(raiz)
        setContentView(raiz)
    }

    // ---- blocos ------------------------------------------------------------

    private fun bloco(nomeBloco: String, info: String, conteudo: View, avancado: Boolean = false): LinearLayout {
        val c = cartaoNeon()
        if (avancado) avancados.add(c)
        val h = horizontal()
        h.addView(texto(nomeBloco, 14.5f, Neon.TEXTO, true), LinearLayout.LayoutParams(0, AUTO, 1f))
        h.addView(botaoInfo { dialogo(nomeBloco, info) }, LinearLayout.LayoutParams(dp(36), dp(32)))
        c.addView(h)
        c.addView(conteudo, lp(CHEIO, AUTO, 8, 0))
        return c
    }

    private fun blocoFiltro(): LinearLayout {
        val fila = LinearLayout(this)
        fila.orientation = LinearLayout.HORIZONTAL
        val cartoes = ArrayList<CartaoFiltro>()
        val atual = Prefs.filtroJogo(this, pkg)
        for (pr in Cor.presets) {
            val cf = CartaoFiltro(this, pr, 88)
            cf.forca = Cor.forca(this)
            cf.selecionado = atual == pr.id
            cf.aoToque = {
                Prefs.setFiltroJogo(this, pkg, pr.id)
                for (o in cartoes) o.selecionado = o.preset.id == pr.id
            }
            cartoes.add(cf)
            fila.addView(cf, LinearLayout.LayoutParams(AUTO, AUTO).apply { rightMargin = dp(8) })
        }
        val hs = HorizontalScrollView(this)
        hs.isHorizontalScrollBarEnabled = false
        hs.addView(fila)
        val caixa = vertical()
        caixa.addView(hs)
        val global = texto("Usar o filtro global", 13f, Neon.CIANO, true)
        global.setPadding(0, dp(10), 0, 0)
        global.setOnClickListener {
            Prefs.setFiltroJogo(this, pkg, "")
            for (o in cartoes) o.selecionado = false
            Toast.makeText(this, "Este jogo vai usar o filtro global.", Toast.LENGTH_SHORT).show()
        }
        caixa.addView(global)
        return bloco(
            "Filtro de cor deste jogo",
            "Entra só enquanto este jogo está aberto e sai quando você fecha. A força (sutil, normal, forte) é a que você escolheu na aba Tela. Para ajustar à mão, use a aba Tela.",
            caixa
        )
    }

    private fun linhaFuncao(m: Modulos.Modulo): LinearLayout {
        val l = horizontal()
        l.setPadding(dp(12), dp(10), dp(6), dp(10))
        l.background = degrade(Neon.CARTAO_A, Neon.CARTAO_B, 18, Neon.BORDA, 1)
        l.addView(caixaIconeNeon(m.icone), LinearLayout.LayoutParams(dp(40), dp(40)))
        val txt = vertical()
        txt.addView(texto(m.nome, 13.5f, Neon.TEXTO, true))
        val estado = texto("", 11f, Neon.SUAVE)
        txt.addView(estado, lp(CHEIO, AUTO, 1, 0))
        l.addView(txt, LinearLayout.LayoutParams(0, AUTO, 1f).apply { leftMargin = dp(12); rightMargin = dp(8) })
        val motivo = Modulos.indisponivel(this, m.id)
        if (motivo != null) {
            // função que este aparelho não tem: mostra o motivo em vez de uma chave que não funciona
            estado.text = "Indisponível neste aparelho"
            l.alpha = 0.6f
            l.addView(botaoInfo { dialogo(m.nome, motivo) }, LinearLayout.LayoutParams(dp(40), dp(40)))
            return l
        }
        fun rotular() {
            estado.text = if (Prefs.temModJogo(this, pkg, m.id)) "Escolha deste jogo" else "Segue a lista geral"
        }
        rotular()
        val ch = Chave(this)
        ch.definir(Prefs.modAutoJogo(this, pkg, m.id))
        ch.aoMudar = { v ->
            Prefs.setModJogo(this, pkg, m.id, v)
            rotular()
        }
        l.addView(ch)
        l.addView(botaoInfo { dialogo(m.nome, m.info) }, LinearLayout.LayoutParams(dp(40), dp(40)))
        return l
    }

    private fun linhaChave(titulo: String, sub: String, inicial: Boolean, aoMudar: (Boolean) -> Unit): LinearLayout {
        val l = horizontal()
        l.setPadding(dp(14), dp(12), dp(14), dp(12))
        l.background = degrade(Neon.CARTAO_A, Neon.CARTAO_B, 18, Neon.BORDA, 1)
        val txt = vertical()
        txt.addView(texto(titulo, 14f, Neon.TEXTO, true))
        txt.addView(texto(sub, 11.5f, Neon.SUAVE), lp(CHEIO, AUTO, 2, 0))
        l.addView(txt, LinearLayout.LayoutParams(0, AUTO, 1f))
        val ch = Chave(this)
        ch.definir(inicial)
        ch.aoMudar = aoMudar
        l.addView(ch, LinearLayout.LayoutParams(AUTO, AUTO).apply { leftMargin = dp(12) })
        return l
    }

    private fun botaoPrimario(rotulo: String, aoClicar: () -> Unit): TextView {
        val t = texto(rotulo, 14f, Neon.TEXTO, true)
        t.gravity = Gravity.CENTER
        t.background = fundoBotaoNeon()
        t.setOnClickListener { aoClicar() }
        return t
    }

    private fun botaoSecundario(rotulo: String, aoClicar: () -> Unit): TextView {
        val t = texto(rotulo, 14f, Neon.TEXTO, true)
        t.gravity = Gravity.CENTER
        t.background = clicavel(Neon.CARTAO_A, 16, Neon.BORDA, 1)
        t.setOnClickListener { aoClicar() }
        return t
    }

    // ---- ações -------------------------------------------------------------

    private fun resumoSugestao(s: Jogos.Sugestao, seguro: Boolean): String {
        val perfil = Tuner.perfis.firstOrNull { it.id == s.perfil }?.nome ?: s.perfil
        val filtro = Cor.preset(s.filtro)?.nome ?: "filtro global"
        val fps = if (s.fps > 0) "${s.fps} FPS" else "FPS padrão"
        val funcoes = if (s.funcoes.isNotEmpty()) " • funções recomendadas" else ""
        return if (seguro) "Perfil $perfil • $filtro$funcoes" else "Perfil $perfil • $fps • resolução ${s.escala}% • $filtro$funcoes"
    }

    /** Cartão do modo seguro: protege o jogo de qualquer coisa do RootBoost que mexa nele ou por cima dele. */
    private fun cartaoSeguro(seguro: Boolean): LinearLayout {
        val c = cartaoNeon(16)
        val l = horizontal()
        val txt = vertical()
        txt.addView(titulo("Modo seguro", 17f, Neon.OK))
        txt.addView(
            texto(
                "O RootBoost não altera o jogo. Com este modo, nada é desenhado por cima dele, o motor gráfico fica no padrão e nenhuma medição roda enquanto ele está aberto. Só entram o perfil de CPU/GPU, as funções do sistema e o filtro de cor.",
                12f, Neon.TEXTO
            ),
            lp(CHEIO, AUTO, 4, 0)
        )
        l.addView(txt, LinearLayout.LayoutParams(0, AUTO, 1f))
        val ch = Chave(this)
        ch.definir(seguro)
        ch.aoMudar = { v ->
            if (v) {
                Prefs.setModoSeguro(this, pkg, true)
                recreate()
            } else {
                ch.definir(true, false)
                AlertDialog.Builder(this)
                    .setTitle("Desligar o modo seguro?")
                    .setMessage("Sem ele, o RootBoost pode desenhar painel e FPS por cima do jogo e mexer no motor gráfico. Jogos com anti-cheat, como o Free Fire, podem entender isso como alteração e punir a conta. A decisão é sua.")
                    .setPositiveButton("Desligar mesmo") { _, _ ->
                        Prefs.setModoSeguro(this, pkg, false)
                        recreate()
                    }
                    .setNegativeButton("Manter ligado", null)
                    .show()
            }
        }
        l.addView(ch, LinearLayout.LayoutParams(AUTO, AUTO).apply { leftMargin = dp(12) })
        c.addView(l)
        return c
    }

    /** Cartão do modo emulador: ligado, o RootBoost sobe um pacote de ajustes pensado para CPU pesada. */
    private fun cartaoEmulador(): LinearLayout {
        val c = cartaoNeon(16)
        val l = horizontal()
        val txt = vertical()
        txt.addView(titulo("Modo emulador", 17f, Neon.CIANO))
        txt.addView(
            texto(
                "Para Winlator, GameHub, ARMSX2, NetherSX2, PPSSPP, Dolphin e outros. Ao abrir, sobe o clock da CPU e da GPU, libera RAM, encerra apps de fundo, acelera o disco e segura o desempenho sem cair. Tudo volta ao normal quando você fecha.",
                12f, Neon.TEXTO
            ),
            lp(CHEIO, AUTO, 4, 0)
        )
        l.addView(txt, LinearLayout.LayoutParams(0, AUTO, 1f))
        val ch = Chave(this)
        ch.definir(Jogos.ehEmulador(this, pkg))
        ch.aoMudar = { v ->
            Prefs.setTipoJogo(this, pkg, if (v) "emulador" else "jogo")
            recreate()
        }
        l.addView(ch, LinearLayout.LayoutParams(AUTO, AUTO).apply { leftMargin = dp(12) })
        c.addView(l)
        return c
    }

    private fun aplicarSugestao(s: Jogos.Sugestao, seguro: Boolean) {
        val jogos = HashSet<String>(Prefs.jogos(this))
        if (pkg !in jogos) {
            jogos.add(pkg)
            Prefs.setJogos(this, jogos)
        }
        Prefs.setPerfilJogo(this, pkg, s.perfil)
        Prefs.setFiltroJogo(this, pkg, s.filtro)
        // liga só as funções recomendadas que este aparelho realmente suporta
        for (id in s.funcoes) {
            val m = Modulos.visiveis(this).firstOrNull { it.id == id } ?: continue
            if (Modulos.indisponivel(this, id) != null) continue
            Prefs.setModJogo(this, pkg, m.id, true)
        }
        if (seguro) {
            // modo seguro: só perfil e filtro, nada de mexer em resolução, FPS ou driver do jogo
            Toast.makeText(this, "Sugestão aplicada (modo seguro).", Toast.LENGTH_SHORT).show()
            recreate()
            return
        }
        Prefs.setFpsJogo(this, pkg, s.fps)
        Prefs.setEscalaJogo(this, pkg, s.escala)
        if (s.fps == 0 && s.escala >= 100) {
            recreate()
            return
        }
        emBg(true) {
            Tuner.modoJogo(pkg, Prefs.modoJogo(this, pkg), s.escala, s.fps)
        }
    }

    private fun aplicarModoJogo() {
        val modo = Prefs.modoJogo(this, pkg)
        val escala = Prefs.escalaJogo(this, pkg)
        val fps = Prefs.fpsJogo(this, pkg)
        emBg { Tuner.modoJogo(pkg, modo, escala, fps) }
    }

    private fun restaurarJogo() {
        Prefs.setPerfilJogo(this, pkg, "gaming")
        Prefs.setEscalaJogo(this, pkg, 100)
        Prefs.setFpsJogo(this, pkg, 0)
        Prefs.setModoJogo(this, pkg, 0)
        Prefs.setDriverJogo(this, pkg, 0)
        Prefs.setFiltroJogo(this, pkg, "")
        for (m in Modulos.lista) Prefs.setModJogo(this, pkg, m.id, null)
        emBg(true) {
            Tuner.modoJogoRestaurar(pkg)
            Tuner.aplicarDriversPorJogo(this)
            "Este jogo voltou ao padrão."
        }
    }

    private fun dialogo(titulo: String, texto: String) {
        AlertDialog.Builder(this)
            .setTitle(titulo)
            .setMessage(texto)
            .setPositiveButton("Entendi", null)
            .show()
    }

    /** Roda o trabalho fora da tela e mostra o resultado; com recriar = true, redesenha a tela no fim. */
    private fun emBg(recriar: Boolean = false, trabalho: () -> String) {
        Thread {
            val msg = try {
                trabalho()
            } catch (e: Exception) {
                "Falhou: ${e.message}"
            }
            runOnUiThread {
                if (msg.isNotEmpty()) Toast.makeText(this, msg, Toast.LENGTH_LONG).show()
                if (recriar) recreate()
            }
        }.start()
    }
}
