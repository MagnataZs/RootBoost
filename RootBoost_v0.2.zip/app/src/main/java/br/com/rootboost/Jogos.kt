package br.com.rootboost

/** Jogos populares conhecidos e uma sugestão de ajustes para cada tipo de jogo. */
object Jogos {

    class Sugestao(val perfil: String, val fps: Int, val escala: Int, val filtro: String, val nota: String)
    class Conhecido(val nome: String, val sug: Sugestao)

    private val COMPETITIVO = Sugestao(
        "gaming", 60, 100, "competitivo",
        "Jogo competitivo: resposta rápida e inimigos mais fáceis de ver."
    )
    private val PESADO = Sugestao(
        "gaming", 30, 80, "natural",
        "Jogo pesado: menos resolução e FPS estável para o aparelho não engasgar nem esquentar."
    )
    private val LEVE = Sugestao(
        "performance", 60, 100, "",
        "Jogo leve: perfil Performance já resolve, gasta menos bateria."
    )
    private val PADRAO = Sugestao(
        "gaming", 60, 100, "",
        "Ajuste geral: perfil Gaming e 60 FPS."
    )

    private val conhecidos: Map<String, Conhecido> = mapOf(
        "com.dts.freefireth" to Conhecido("Free Fire", COMPETITIVO),
        "com.dts.freefiremax" to Conhecido("Free Fire MAX", COMPETITIVO),
        "com.tencent.ig" to Conhecido("PUBG Mobile", COMPETITIVO),
        "com.pubg.imobile" to Conhecido("BGMI", COMPETITIVO),
        "com.activision.callofduty.shooter" to Conhecido("Call of Duty Mobile", COMPETITIVO),
        "com.mobile.legends" to Conhecido("Mobile Legends", COMPETITIVO),
        "com.riotgames.league.wildrift" to Conhecido("Wild Rift", COMPETITIVO),
        "com.axlebolt.standoff2" to Conhecido("Standoff 2", COMPETITIVO),
        "com.netease.newspike" to Conhecido("Blood Strike", COMPETITIVO),
        "com.miHoYo.GenshinImpact" to Conhecido("Genshin Impact", PESADO),
        "com.HoYoverse.hkrpgoversea" to Conhecido("Honkai: Star Rail", PESADO),
        "com.proximabeta.mf.uamo" to Conhecido("Arena Breakout", PESADO),
        "com.mojang.minecraftpe" to Conhecido("Minecraft", PADRAO),
        "com.roblox.client" to Conhecido("Roblox", PADRAO),
        "com.supercell.brawlstars" to Conhecido("Brawl Stars", LEVE),
        "com.supercell.clashroyale" to Conhecido("Clash Royale", LEVE),
        "com.kiloo.subwaysurf" to Conhecido("Subway Surfers", LEVE)
    )

    fun conhecido(pkg: String): Conhecido? = conhecidos[pkg]

    /**
     * Jogos online com anti-cheat (competitivos e pesados). Neles o RootBoost entra em "modo seguro":
     * não desenha nada por cima, não mexe no motor gráfico e não mede nada enquanto o jogo está aberto.
     */
    fun sensivel(pkg: String): Boolean {
        val c = conhecidos[pkg] ?: return false
        return c.sug === COMPETITIVO || c.sug === PESADO
    }

    fun sugestao(pkg: String): Sugestao = conhecidos[pkg]?.sug ?: PADRAO
}
