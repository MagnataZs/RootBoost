package br.com.rootboost

import android.content.Context

/** Jogos e emuladores conhecidos e uma sugestão de ajustes para cada tipo. */
object Jogos {

    class Sugestao(
        val perfil: String,
        val fps: Int,
        val escala: Int,
        val filtro: String,
        val nota: String,
        /** Funções que esta sugestão liga para o jogo (só as que o aparelho suporta). */
        val funcoes: List<String> = emptyList()
    )

    class Conhecido(val nome: String, val sug: Sugestao)

    private val COMPETITIVO = Sugestao(
        "gaming", 60, 100, "competitivo",
        "Jogo competitivo: resposta rápida, ping estável e inimigos mais fáceis de ver.",
        listOf("chamadas", "antiqueda", "toque", "dados", "scan", "wifi", "headsup", "dnd", "animacoes", "cpuboost")
    )
    private val PESADO = Sugestao(
        "gaming", 60, 80, "natural",
        "Jogo pesado: GPU no talo, menos resolução e o sistema sem atrapalhar. Foco em fluidez sem esquentar demais.",
        listOf(
            "gpu", "mali", "sustentado", "ram", "cpuboost", "antiqueda", "io", "readahead",
            "scan", "poupanca", "chamadas", "headsup", "brilho"
        )
    )
    private val LEVE = Sugestao(
        "performance", 60, 100, "",
        "Jogo leve: o perfil Performance já resolve e gasta menos bateria.",
        listOf("chamadas", "animacoes", "headsup")
    )
    private val PADRAO = Sugestao(
        "gaming", 60, 100, "",
        "Ajuste geral: perfil Gaming, 60 FPS e o sistema sem atrapalhar.",
        listOf("chamadas", "antiqueda", "headsup", "cpuboost")
    )
    private val EMULADOR = Sugestao(
        "gaming", 0, 100, "",
        "Emulador: o que pesa é a CPU. Sobe o clock, libera RAM, tira apps do caminho e mantém o desempenho sem cair.",
        listOf(
            "cpuboost", "gpu", "mali", "sustentado", "readahead", "io", "ram", "profunda",
            "scan", "poupanca", "chamadas", "headsup"
        )
    )

    private val conhecidos: Map<String, Conhecido> = mapOf(
        "com.dts.freefireth" to Conhecido("Free Fire", COMPETITIVO),
        "com.dts.freefiremax" to Conhecido("Free Fire MAX", COMPETITIVO),
        "com.tencent.ig" to Conhecido("PUBG Mobile", COMPETITIVO),
        "com.pubg.imobile" to Conhecido("BGMI", COMPETITIVO),
        "com.activision.callofduty.shooter" to Conhecido("Call of Duty Mobile", COMPETITIVO),
        "com.mobile.legends" to Conhecido("Mobile Legends", COMPETITIVO),
        "com.riotgames.league.wildrift" to Conhecido("Wild Rift", COMPETITIVO),
        "com.axlebolt.standoff2" to Conhecido("Standoff 2", COMPETITIVO),
        "com.netease.newspike" to Conhecido("Blood Strike", COMPETITIVO),
        "com.proximabeta.dfm" to Conhecido("Delta Force", COMPETITIVO),
        "com.levelinfinite.sgameGlobal" to Conhecido("Honor of Kings", PESADO),
        "com.tencent.tmgp.sgame" to Conhecido("Honor of Kings (CN)", PESADO),
        "com.miHoYo.GenshinImpact" to Conhecido("Genshin Impact", PESADO),
        "com.HoYoverse.hkrpgoversea" to Conhecido("Honkai: Star Rail", PESADO),
        "com.HoYoverse.Nap" to Conhecido("Zenless Zone Zero", PESADO),
        "com.kurogame.wutheringwaves.global" to Conhecido("Wuthering Waves", PESADO),
        "com.proximabeta.mf.uamo" to Conhecido("Arena Breakout", PESADO),
        "com.activision.callofduty.warzone" to Conhecido("Warzone Mobile", PESADO),
        "com.pubg.newstate" to Conhecido("PUBG: New State", PESADO),
        "com.blizzard.diablo.immortal" to Conhecido("Diablo Immortal", PESADO),
        "com.gameloft.android.ANMP.GloftA9HM" to Conhecido("Asphalt 9", PESADO),
        "com.ea.gp.fifamobile" to Conhecido("EA SPORTS FC Mobile", PESADO),
        "jp.konami.pesam" to Conhecido("eFootball", PESADO),
        "com.mojang.minecraftpe" to Conhecido("Minecraft", PADRAO),
        "com.roblox.client" to Conhecido("Roblox", PADRAO),
        "com.supercell.brawlstars" to Conhecido("Brawl Stars", LEVE),
        "com.supercell.clashroyale" to Conhecido("Clash Royale", LEVE),
        "com.kiloo.subwaysurf" to Conhecido("Subway Surfers", LEVE)
    )

    /** Nomes que identificam emuladores (no pacote ou no nome do app). */
    private val EMULADORES = listOf(
        "winlator", "gamehub", "armsx2", "nethersx2", "aethersx2", "pcsx2", "ppsspp", "dolphin",
        "citra", "lime3ds", "yuzu", "sudachi", "eden", "skyline", "duckstation", "retroarch",
        "drastic", "vita3k", "mobox", "exagear", "box64", "cemu", "rpcs3", "redream", "flycast",
        "melonds", "mupen", "scummvm", "dosbox", "emulator", "emulador"
    )

    fun conhecido(pkg: String): Conhecido? = conhecidos[pkg]

    /** Nome parecido com o de um emulador? Nomes curtos precisam bater com uma palavra inteira. */
    fun pareceEmulador(pkg: String, nome: String): Boolean {
        val s = (pkg + " " + nome).lowercase()
        val palavras = s.split(Regex("[^a-z0-9]+")).filter { it.isNotEmpty() }
        for (e in EMULADORES) {
            if (e.length >= 6) {
                if (s.contains(e)) return true
            } else if (e in palavras) return true
        }
        return false
    }

    /** Vale a escolha do usuário; sem escolha, tenta adivinhar pelo nome. */
    fun ehEmulador(ctx: Context, pkg: String): Boolean {
        when (Prefs.tipoJogo(ctx, pkg)) {
            "emulador" -> return true
            "jogo" -> return false
        }
        val nome = try {
            ctx.packageManager.getApplicationLabel(ctx.packageManager.getApplicationInfo(pkg, 0)).toString()
        } catch (e: Exception) {
            ""
        }
        return pareceEmulador(pkg, nome)
    }

    /**
     * Jogos online com anti-cheat (competitivos e pesados). Quem quiser pode ligar o "modo seguro":
     * nada por cima do jogo, motor gráfico no padrão e nenhuma medição enquanto ele está aberto.
     */
    fun sensivel(pkg: String): Boolean {
        val c = conhecidos[pkg] ?: return false
        return c.sug === COMPETITIVO || c.sug === PESADO
    }

    fun sugestao(pkg: String): Sugestao = conhecidos[pkg]?.sug ?: PADRAO

    fun sugestaoPara(ctx: Context, pkg: String): Sugestao = if (ehEmulador(ctx, pkg)) EMULADOR else sugestao(pkg)
}
