package br.com.rootboost

import android.app.Service
import android.content.Intent
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.util.Locale
import kotlin.math.abs

/**
 * Painel do Game Turbo dentro do jogo: uma alça na borda esquerda que abre o painel
 * (medidores, perfis, módulos e dados da sessão). Toque fora para fechar.
 */
class PainelJogoService : Service() {

    private var wm: WindowManager? = null
    private var raizV: FrameLayout? = null
    private lateinit var alca: View
    private lateinit var painel: LinearLayout
    private lateinit var params: WindowManager.LayoutParams
    private var aberto = false
    private var yAlca = 0
    private var alcaDireita = false
    private lateinit var infoFuncao: CartaoInfo
    @Volatile private var ativo = false
    private val main = Handler(Looper.getMainLooper())

    private lateinit var cCpu: CartaoMetrica
    private lateinit var cGpu: CartaoMetrica
    private lateinit var cRam: CartaoMetrica
    private lateinit var cFps: CartaoMetrica
    private lateinit var gradeBox: LinearLayout
    private var gradePaisagem: Boolean? = null
    private lateinit var tvHora: TextView
    private lateinit var tvBat: TextView
    private val rotulosRail = ArrayList<TextView>()
    private val formatoHora = java.text.SimpleDateFormat("HH:mm", Locale.getDefault())
    private lateinit var seg: Segmentado
    private lateinit var tvDesc: TextView
    private lateinit var nuc: Nucleos
    private lateinit var tvGpu: TextView
    private lateinit var segGpu: Segmentado
    private val caixas = HashMap<String, Caixinha>()
    private val sessao = HashMap<String, TextView>()
    private val paginas = ArrayList<View>()
    private val icones = ArrayList<Icone>()
    private val fundos = ArrayList<LinearLayout>()

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (!Settings.canDrawOverlays(this)) { stopSelf(); return START_NOT_STICKY }
        if (raizV != null) return START_NOT_STICKY

        val gerente = getSystemService(WINDOW_SERVICE) as WindowManager
        wm = gerente
        val dm = resources.displayMetrics
        val r = FrameLayout(this)
        raizV = r

        // alça
        val a = FrameLayout(this)
        alca = a
        estiloAlca(false)
        val raioIcone = Icone(this, "raio")
        raioIcone.cor = Neon.CIANO
        a.addView(raioIcone, FrameLayout.LayoutParams(AUTO, AUTO, Gravity.CENTER))
        r.addView(a, FrameLayout.LayoutParams(dp(30), dp(60)))

        // painel
        painel = construirPainel()
        painel.visibility = View.GONE
        r.addView(painel, FrameLayout.LayoutParams(dp(400), dp(300)))

        params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        )
        params.gravity = Gravity.TOP or Gravity.START
        params.x = 0
        yAlca = dm.heightPixels / 3
        params.y = yAlca

        // arrastar a alça para qualquer lugar; ao soltar ela gruda na borda mais perto; um toque abre o painel
        var ix = 0
        var iy = 0
        var tx = 0f
        var ty = 0f
        var moveu = false
        a.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    ix = params.x; iy = params.y; tx = e.rawX; ty = e.rawY; moveu = false
                    a.alpha = 1f
                }
                MotionEvent.ACTION_MOVE -> {
                    val ddx = (e.rawX - tx).toInt()
                    val ddy = (e.rawY - ty).toInt()
                    if (abs(ddx) > dp(6) || abs(ddy) > dp(6)) moveu = true
                    if (moveu) {
                        val tela = resources.displayMetrics
                        params.x = (ix + ddx).coerceIn(0, tela.widthPixels - dp(30))
                        params.y = (iy + ddy).coerceIn(0, tela.heightPixels - dp(60))
                        gerente.updateViewLayout(r, params)
                    }
                }
                MotionEvent.ACTION_UP -> {
                    if (moveu) {
                        val tela = resources.displayMetrics
                        alcaDireita = params.x + dp(15) > tela.widthPixels / 2
                        params.x = if (alcaDireita) tela.widthPixels - dp(30) else 0
                        yAlca = params.y
                        estiloAlca(alcaDireita)
                        gerente.updateViewLayout(r, params)
                    } else {
                        abrir()
                    }
                }
                MotionEvent.ACTION_CANCEL -> estiloAlca(alcaDireita)
            }
            true
        }
        r.setOnTouchListener { _, e ->
            if (e.action == MotionEvent.ACTION_OUTSIDE && aberto) fechar()
            false
        }

        gerente.addView(r, params)
        selecionarPagina(0)

        ativo = true
        Thread {
            while (ativo) {
                if (aberto) {
                    val s = Stats.ler()
                    val b = Stats.bateria(this)
                    main.post { aplicarLeitura(s, b) }
                }
                try {
                    Thread.sleep(2000)
                } catch (e: InterruptedException) {
                    break
                }
            }
        }.start()
        return START_NOT_STICKY
    }

    // ---- abrir / fechar ----------------------------------------------------

    /** Visual da alça: cantos arredondados do lado de dentro da tela e meio transparente quando parada. */
    private fun estiloAlca(direita: Boolean) {
        val raio = dp(14).toFloat()
        alca.background = GradientDrawable().apply {
            setColor(0xDD141B30.toInt())
            cornerRadii = if (direita) floatArrayOf(raio, raio, 0f, 0f, 0f, 0f, raio, raio)
            else floatArrayOf(0f, 0f, raio, raio, raio, raio, 0f, 0f)
            setStroke(dp(1), Neon.BORDA)
        }
        alca.alpha = 0.7f
    }

    private fun abrir() {
        val r = raizV ?: return
        val dm = resources.displayMetrics
        val paisagem = dm.widthPixels > dm.heightPixels
        val larg = if (paisagem) minOf((dm.widthPixels * 0.62f).toInt(), dp(500)) else (dm.widthPixels * 0.94f).toInt()
        val alt = if (paisagem) minOf((dm.heightPixels * 0.9f).toInt(), dp(340))
        else minOf((dm.heightPixels * 0.78f).toInt(), dp(540))
        montarGrade()
        val lpPainel = painel.layoutParams
        lpPainel.width = larg
        lpPainel.height = alt
        painel.layoutParams = lpPainel
        aberto = true
        alca.visibility = View.GONE
        painel.visibility = View.VISIBLE
        painel.alpha = 0f
        painel.scaleX = 0.96f
        painel.scaleY = 0.96f
        painel.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(260)
            .setInterpolator(android.view.animation.DecelerateInterpolator(1.6f)).start()
        params.gravity = Gravity.CENTER_VERTICAL or Gravity.START
        params.x = dp(10)
        params.y = 0
        wm?.updateViewLayout(r, params)
        Thread {
            val s = Stats.ler()
            val b = Stats.bateria(this)
            main.post { aplicarLeitura(s, b) }
        }.start()
    }

    private fun fechar() {
        val r = raizV ?: return
        aberto = false
        painel.visibility = View.GONE
        alca.visibility = View.VISIBLE
        params.gravity = Gravity.TOP or Gravity.START
        params.x = if (alcaDireita) resources.displayMetrics.widthPixels - dp(30) else 0
        params.y = yAlca.coerceIn(0, resources.displayMetrics.heightPixels - dp(60))
        estiloAlca(alcaDireita)
        wm?.updateViewLayout(r, params)
    }

    // ---- construção do painel ----------------------------------------------

    private fun construirPainel(): LinearLayout {
        val p = LinearLayout(this)
        p.orientation = LinearLayout.VERTICAL
        p.background = degrade(Neon.PAINEL_A, Neon.PAINEL_B, 26, Neon.BORDA, 1)

        // cabeçalho: marca, wifi, bateria, hora e fechar
        val cab = horizontal()
        cab.setPadding(dp(16), dp(10), dp(8), dp(4))
        val logo = Icone(this, "raio")
        logo.cor = Neon.CIANO
        logo.tamanhoDp = 20
        cab.addView(logo, LinearLayout.LayoutParams(dp(20), dp(20)))
        cab.addView(titulo("RootBoost", 18f), LinearLayout.LayoutParams(AUTO, AUTO).apply { leftMargin = dp(8) })
        cab.addView(View(this), LinearLayout.LayoutParams(0, 1, 1f))
        val wifi = Icone(this, "wifi")
        wifi.cor = Neon.TEXTO
        wifi.tamanhoDp = 18
        cab.addView(wifi, LinearLayout.LayoutParams(dp(18), dp(18)))
        val bateria = Icone(this, "bateria")
        bateria.cor = Neon.TEXTO
        bateria.tamanhoDp = 18
        cab.addView(bateria, LinearLayout.LayoutParams(dp(18), dp(18)).apply { leftMargin = dp(8) })
        tvBat = texto("", 11.5f, Neon.SUAVE)
        cab.addView(tvBat, LinearLayout.LayoutParams(AUTO, AUTO).apply { leftMargin = dp(3) })
        tvHora = texto("--:--", 12.5f, Neon.TEXTO)
        cab.addView(tvHora, LinearLayout.LayoutParams(AUTO, AUTO).apply { leftMargin = dp(10) })
        val fecharCx = FrameLayout(this)
        val fecharIc = Icone(this, "fechar")
        fecharIc.cor = Neon.TEXTO
        fecharCx.addView(fecharIc, FrameLayout.LayoutParams(AUTO, AUTO, Gravity.CENTER))
        fecharCx.setOnClickListener { fechar() }
        cab.addView(fecharCx, LinearLayout.LayoutParams(dp(40), dp(40)).apply { leftMargin = dp(4) })
        p.addView(cab, LinearLayout.LayoutParams(CHEIO, AUTO))

        val corpo = LinearLayout(this)
        corpo.orientation = LinearLayout.HORIZONTAL

        // trilho de abas com legenda (rola se a tela for baixa)
        val rail = vertical()
        rail.gravity = Gravity.CENTER_HORIZONTAL
        rail.setPadding(dp(4), dp(4), dp(4), dp(8))
        val tipos = listOf("jogos", "modulos", "cor", "janela", "barras")
        val nomes = listOf("Game Turbo", "Funções", "Filtros", "Apps rápidos", "Sessão")
        for (i in tipos.indices) {
            val item = vertical()
            item.gravity = Gravity.CENTER
            item.setPadding(dp(2), dp(6), dp(2), dp(6))
            val ic = Icone(this, tipos[i])
            ic.tamanhoDp = 22
            item.addView(ic, LinearLayout.LayoutParams(dp(22), dp(22)))
            val rot = texto(nomes[i], 9f, Neon.SUAVE)
            rot.gravity = Gravity.CENTER
            rot.maxLines = 1
            rot.ellipsize = android.text.TextUtils.TruncateAt.END
            item.addView(rot, lp(CHEIO, AUTO, 3, 0))
            item.setOnClickListener { selecionarPagina(i) }
            rail.addView(item, LinearLayout.LayoutParams(dp(66), dp(50)).apply { bottomMargin = dp(4) })
            icones.add(ic)
            rotulosRail.add(rot)
            fundos.add(item)
        }
        val trilho = ScrollView(this)
        trilho.isVerticalScrollBarEnabled = false
        trilho.addView(rail)
        corpo.addView(trilho, LinearLayout.LayoutParams(dp(76), CHEIO))

        val linhaV = View(this)
        linhaV.setBackgroundColor(Neon.BORDA)
        corpo.addView(linhaV, LinearLayout.LayoutParams(dp(1), CHEIO).apply {
            topMargin = dp(6)
            bottomMargin = dp(10)
        })

        val conteudo = FrameLayout(this)
        paginas.add(paginaDesempenho())
        paginas.add(paginaFuncoes())
        paginas.add(paginaFiltros())
        paginas.add(paginaApps())
        paginas.add(paginaSessao())
        for (pg in paginas) conteudo.addView(pg, FrameLayout.LayoutParams(CHEIO, CHEIO))
        corpo.addView(conteudo, LinearLayout.LayoutParams(0, CHEIO, 1f))
        p.addView(corpo, LinearLayout.LayoutParams(CHEIO, 0, 1f))
        return p
    }

    private fun paginaDesempenho(): View {
        val pagina = vertical()

        val col = vertical()
        col.setPadding(dp(14), dp(6), dp(14), dp(8))
        col.addView(titulo("Game Turbo", 22f))
        col.addView(texto("Mais performance para o seu jogo.", 12f, Neon.SUAVE), lp(CHEIO, AUTO, 1, 8))

        cCpu = CartaoMetrica(this, "cpu", "CPU", Neon.CIANO, Neon.AZUL)
        cCpu.unidade = "MHz"
        cGpu = CartaoMetrica(this, "gpu", "GPU", Neon.LILAS, Neon.ROXO)
        cGpu.unidade = "%"
        cRam = CartaoMetrica(this, "memoria", "RAM", Neon.CIANO, Neon.AZUL)
        cRam.unidade = "%"
        cFps = CartaoMetrica(this, "barras", "FPS", Neon.LILAS, Neon.ROXO)
        cFps.unidade = "FPS"
        gradeBox = vertical()
        col.addView(gradeBox, lp(CHEIO, AUTO, 0, 0))
        montarGrade()

        col.addView(texto("Perfil de desempenho", 12.5f, Neon.TEXTO, true), lp(CHEIO, AUTO, 14, 6))
        seg = Segmentado(this, Tuner.perfis.map { it.nome }, 11f, Neon.AZUL, Neon.CARTAO_A)
        seg.aoEscolher = { i -> aplicarPerfil(Tuner.perfis[i].id) }
        col.addView(seg, lp(CHEIO, AUTO, 0, 0))
        tvDesc = texto("", 11.5f, Neon.SUAVE)
        col.addView(tvDesc, lp(CHEIO, AUTO, 8, 0))

        col.addView(texto("GPU Adreno", 12.5f, Neon.TEXTO, true), lp(CHEIO, AUTO, 14, 6))
        segGpu = Segmentado(this, listOf("Automática", "Alta", "Máxima"), 11f, Neon.ROXO, Neon.CARTAO_A)
        segGpu.definir(Prefs.lng(this, "gpu_modo", 0L).toInt())
        segGpu.aoEscolher = { i -> aplicarGpu(i) }
        col.addView(segGpu, lp(CHEIO, AUTO, 0, 0))
        tvGpu = texto("GPU —", 12f, Neon.CIANO, true)
        col.addView(tvGpu, lp(CHEIO, AUTO, 8, 0))
        col.addView(texto("Máxima trava a GPU no clock mais alto: esquenta mais.", 11f, Neon.SUAVE), lp(CHEIO, AUTO, 4, 0))

        col.addView(texto("Núcleos da CPU (MHz)", 12.5f, Neon.TEXTO, true), lp(CHEIO, AUTO, 14, 4))
        nuc = Nucleos(this)
        col.addView(nuc, lp(CHEIO, AUTO, 0, 0))

        val rolagem = ScrollView(this)
        rolagem.isVerticalScrollBarEnabled = false
        rolagem.addView(col)
        pagina.addView(rolagem, LinearLayout.LayoutParams(CHEIO, 0, 1f))

        val botoes = LinearLayout(this)
        botoes.orientation = LinearLayout.HORIZONTAL
        botoes.setPadding(dp(14), dp(4), dp(14), dp(12))
        botoes.addView(
            botaoAcao("modulos", "Abrir app", false) { abrirTela(MainActivity::class.java) },
            LinearLayout.LayoutParams(0, dp(44), 1f).apply { rightMargin = dp(8) }
        )
        botoes.addView(
            botaoAcao("play", "Voltar ao jogo", true) { fechar() },
            LinearLayout.LayoutParams(0, dp(44), 1.25f)
        )
        pagina.addView(botoes, LinearLayout.LayoutParams(CHEIO, AUTO))
        return pagina
    }

    /** Quatro cartões: em linha na horizontal, 2 x 2 na vertical. Remonta se o aparelho girar. */
    private fun montarGrade() {
        val dm = resources.displayMetrics
        val paisagem = dm.widthPixels > dm.heightPixels
        if (gradePaisagem == paisagem) return
        gradePaisagem = paisagem
        gradeBox.removeAllViews()
        val cartoes = listOf(cCpu, cGpu, cRam, cFps)
        val porLinha = if (paisagem) 4 else 2
        var i = 0
        while (i < cartoes.size) {
            val linha = LinearLayout(this)
            linha.orientation = LinearLayout.HORIZONTAL
            for (k in 0 until porLinha) {
                val lpc = LinearLayout.LayoutParams(0, AUTO, 1f)
                if (k < porLinha - 1) lpc.rightMargin = dp(8)
                linha.addView(cartoes[i + k], lpc)
            }
            gradeBox.addView(linha, lp(CHEIO, AUTO, if (i == 0) 0 else 8, 0))
            i += porLinha
        }
    }

    private fun botaoAcao(tipo: String, rotulo: String, principal: Boolean, aoClicar: () -> Unit): LinearLayout {
        val b = horizontal()
        b.gravity = Gravity.CENTER
        b.background = if (principal) fundoBotaoNeon() else clicavel(Neon.CARTAO_A, 16, Neon.BORDA, 1)
        val ic = Icone(this, tipo)
        ic.tamanhoDp = 18
        ic.cor = Neon.TEXTO
        b.addView(ic, LinearLayout.LayoutParams(dp(18), dp(18)))
        b.addView(texto(rotulo, 13.5f, Neon.TEXTO, true), LinearLayout.LayoutParams(AUTO, AUTO).apply { leftMargin = dp(8) })
        b.setOnClickListener { aoClicar() }
        return b
    }

    private fun abrirTela(destino: Class<*>, pkg: String? = null) {
        fechar()
        try {
            val i = Intent(this, destino)
            if (pkg != null) i.putExtra("pkg", pkg)
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            startActivity(i)
        } catch (e: Exception) {
            aviso("Não consegui abrir.")
        }
    }

    private fun paginaFuncoes(): View {
        val pagina = vertical()
        pagina.setPadding(dp(14), dp(8), dp(14), 0)
        pagina.addView(titulo("Funções", 22f))
        pagina.addView(
            texto("Toque para ligar ou desligar. O ⓘ explica o que cada função faz.", 12f, Neon.SUAVE),
            lp(CHEIO, AUTO, 1, 8)
        )
        infoFuncao = CartaoInfo(this)
        pagina.addView(infoFuncao, lp(CHEIO, AUTO, 0, 8))

        val col = vertical()
        col.setPadding(0, 0, 0, dp(12))
        val dm = resources.displayMetrics
        val porLinha = if (dm.widthPixels > dm.heightPixels) 3 else 2
        val fpsMod = Modulos.Modulo(
            "fps_overlay", "Contador de FPS", "Mostra o FPS do jogo.", "fps",
            "Põe uma pílula pequena no canto da tela com o FPS do jogo. Toque nela para ver o gráfico e o 1% low. Arraste para mudar de lugar."
        )
        val itens = ArrayList<Modulos.Modulo>()
        itens.add(fpsMod)
        itens.addAll(Modulos.lista)
        var linhaAtual: LinearLayout? = null
        for (i in itens.indices) {
            val m = itens[i]
            if (i % porLinha == 0) {
                val l = LinearLayout(this)
                l.orientation = LinearLayout.HORIZONTAL
                linhaAtual = l
                col.addView(l, lp(CHEIO, AUTO, 8, 0))
            }
            val cf = CartaoFuncao(this, m, Neon.CIANO)
            cf.aoInfo = { infoFuncao.mostrar(m.nome, m.info) }
            val cx = cf.caixa
            if (m.id == "fps_overlay") {
                cx.definir(Prefs.fpsOn(this), if (Prefs.fpsOn(this)) "Ativo" else "Desligado", false)
                cx.aoToque = {
                    val novo = !Prefs.fpsOn(this)
                    alternarFps(novo)
                    cx.definir(novo, if (novo) "Ativo" else "Desligado")
                }
                caixas["fps_overlay"] = cx
            } else if (m.reversivel) {
                cx.definir(Prefs.modAtivo(this, m.id), if (Prefs.modAtivo(this, m.id)) "Ativo" else "Desligado", false)
                cx.aoToque = { alternarModulo(m, !cx.estaLigada()) }
                caixas[m.id] = cx
            } else {
                cx.definir(false, "Toque para executar", false)
                cx.aoToque = { executarModulo(m) }
            }
            val lpCel = LinearLayout.LayoutParams(0, AUTO, 1f)
            if (i % porLinha != porLinha - 1) lpCel.rightMargin = dp(8)
            linhaAtual?.addView(cf, lpCel)
        }
        val sobra = (porLinha - itens.size % porLinha) % porLinha
        for (k in 0 until sobra) {
            val vazio = View(this)
            val lpV = LinearLayout.LayoutParams(0, 1, 1f)
            if (k != sobra - 1) lpV.rightMargin = dp(8)
            linhaAtual?.addView(vazio, lpV)
        }
        val rolagem = ScrollView(this)
        rolagem.isVerticalScrollBarEnabled = false
        rolagem.addView(col)
        pagina.addView(rolagem, LinearLayout.LayoutParams(CHEIO, 0, 1f))
        return pagina
    }

    private fun paginaFiltros(): View {
        val col = vertical()
        col.setPadding(dp(14), dp(8), dp(14), dp(14))
        col.addView(FiltrosPainel(this, true) { msg -> aviso(msg) })
        val rolagem = ScrollView(this)
        rolagem.isVerticalScrollBarEnabled = false
        rolagem.addView(col)
        return rolagem
    }

    /** Apps escolhidos no RootBoost: abrem em janela flutuante sem tirar você do jogo. */
    private fun paginaApps(): View {
        val col = vertical()
        col.setPadding(dp(16), dp(14), dp(16), dp(14))
        col.addView(titulo("Apps rápidos", 22f))
        col.addView(texto("Tamanho da janela", 12.5f, Neon.TEXTO, true), lp(CHEIO, AUTO, 8, 6))
        val segJanela = Segmentado(this, listOf("Pequena", "Média", "Grande"), 11.5f, Neon.AZUL, Neon.CARTAO_A)
        segJanela.definir(Prefs.janelaTam(this))
        segJanela.aoEscolher = { i -> Prefs.setJanelaTam(this, i) }
        col.addView(segJanela, lp(CHEIO, AUTO, 0, 4))
        val pm = packageManager
        val lista = Prefs.atalhos(this).toList().sortedBy {
            try { pm.getApplicationLabel(pm.getApplicationInfo(it, 0)).toString().lowercase() } catch (e: Exception) { it }
        }
        if (lista.isEmpty()) {
            col.addView(
                texto("Nenhum app escolhido. No RootBoost, em Início > Apps rápidos, escolha os que você quer abrir por cima do jogo.", 12f, Neon.SUAVE),
                lp(CHEIO, AUTO, 10, 0)
            )
        } else {
            col.addView(texto("Toque para abrir em janela flutuante.", 11.5f, Neon.SUAVE), lp(CHEIO, AUTO, 2, 6))
            val dm = resources.displayMetrics
            val porLinha = if (dm.widthPixels > dm.heightPixels) 4 else 3
            var linhaAtual: LinearLayout? = null
            for (i in lista.indices) {
                val pkg = lista[i]
                if (i % porLinha == 0) {
                    val l = LinearLayout(this)
                    l.orientation = LinearLayout.HORIZONTAL
                    linhaAtual = l
                    col.addView(l, lp(CHEIO, AUTO, 8, 0))
                }
                val cel = vertical()
                cel.gravity = Gravity.CENTER_HORIZONTAL
                cel.setPadding(dp(6), dp(10), dp(6), dp(10))
                cel.background = clicavel(Neon.CARTAO_A, 16)
                val ic = ImageView(this)
                try { ic.setImageDrawable(pm.getApplicationIcon(pkg)) } catch (e: Exception) { }
                cel.addView(ic, LinearLayout.LayoutParams(dp(40), dp(40)))
                val nome = try { pm.getApplicationLabel(pm.getApplicationInfo(pkg, 0)).toString() } catch (e: Exception) { pkg }
                val tv = texto(nome, 11f, Neon.TEXTO)
                tv.maxLines = 1
                tv.gravity = Gravity.CENTER
                tv.ellipsize = android.text.TextUtils.TruncateAt.END
                cel.addView(tv, lp(CHEIO, AUTO, 6, 0))
                cel.setOnClickListener { abrirApp(pkg) }
                cel.pressionar()
                val lpCel = LinearLayout.LayoutParams(0, AUTO, 1f)
                lpCel.rightMargin = dp(8)
                linhaAtual?.addView(cel, lpCel)
            }
            val sobra = (porLinha - lista.size % porLinha) % porLinha
            for (k in 0 until sobra) linhaAtual?.addView(View(this), LinearLayout.LayoutParams(0, 1, 1f).apply { rightMargin = dp(8) })
        }
        val rolagem = ScrollView(this)
        rolagem.isVerticalScrollBarEnabled = false
        rolagem.addView(col)
        return rolagem
    }

    private fun paginaSessao(): View {
        val col = vertical()
        col.setPadding(dp(16), dp(14), dp(16), dp(14))
        col.addView(titulo("Sessão", 22f))
        for (rotulo in listOf("Jogo", "Tempo de jogo", "Temperatura", "Bateria", "Perfil ativo", "Governor")) {
            val l = horizontal()
            l.setPadding(0, dp(10), 0, dp(10))
            l.addView(texto(rotulo, 12.5f, Neon.SUAVE), LinearLayout.LayoutParams(0, AUTO, 1f))
            val v = texto("—", 13f, Neon.TEXTO, true)
            l.addView(v)
            sessao[rotulo] = v
            col.addView(l, lp(CHEIO, AUTO, 0, 0))
            col.addView(divisor(), LinearLayout.LayoutParams(CHEIO, dp(1)))
        }
        col.addView(
            botaoAcao("engrenagem", "Configurar este jogo", false) { configurarJogoAtual() },
            lp(CHEIO, dp(44), 14, 0)
        )
        col.addView(texto("RootBoost 0.7 • por Diparis / MagnataZs", 11f, Neon.SUAVE), lp(CHEIO, AUTO, 14, 0))
        val rolagem = ScrollView(this)
        rolagem.isVerticalScrollBarEnabled = false
        rolagem.addView(col)
        return rolagem
    }

    private fun configurarJogoAtual() {
        val pkg = jogoAtual()
        if (pkg == null) {
            aviso("Nenhum jogo em sessão agora.")
            return
        }
        abrirTela(JogoActivity::class.java, pkg)
    }

    private fun selecionarPagina(i: Int) {
        for (k in paginas.indices) paginas[k].visibility = if (k == i) View.VISIBLE else View.GONE
        for (k in icones.indices) {
            val on = k == i
            icones[k].cor = if (on) Neon.CIANO else Neon.SUAVE
            rotulosRail[k].setTextColor(if (on) Neon.TEXTO else Neon.SUAVE)
            fundos[k].background = if (on) forma(Neon.SELECIONADO, 16, Neon.BORDA_SEL, 1) else null
        }
    }

    // ---- ações -------------------------------------------------------------

    private fun aviso(msg: String) {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
    }

    private fun aplicarPerfil(id: String) {
        Thread {
            val m = Tuner.aplicar(this, id)
            main.post { aviso(m); atualizarAgora() }
        }.start()
    }

    private fun alternarFps(ligado: Boolean) {
        Prefs.setFpsOn(this, ligado)
        if (ligado) startService(Intent(this, FpsService::class.java))
        else stopService(Intent(this, FpsService::class.java))
    }

    private fun jogoAtual(): String? = Prefs.str(this, "em_jogo", "").takeIf { it.isNotEmpty() }

    private fun alternarModulo(m: Modulos.Modulo, ligar: Boolean) {
        Thread {
            val r = if (ligar) Modulos.ligar(this, m.id, jogoAtual()) else Modulos.desligar(this, m.id)
            main.post {
                aviso(r.msg)
                val on = Prefs.modAtivo(this, m.id)
                caixas[m.id]?.definir(on, if (on) "Ativo" else "Desligado")
            }
        }.start()
    }

    private fun abrirApp(pkg: String) {
        fechar()
        Thread {
            val m = Tuner.abrirFlutuante(this, pkg)
            main.post { aviso(m) }
        }.start()
    }

    /** 0 = automática (valores do aparelho), 1 = alta (piso em 60%), 2 = máxima (trava no topo). */
    private fun aplicarGpu(modo: Int) {
        Prefs.putLng(this, "gpu_modo", modo.toLong())
        Thread {
            val msg = if (modo == 0) {
                Tuner.gpuRestaurar(this)
            } else {
                val g = Tuner.infoGpu()
                if (g == null || g.freqsHz.isEmpty()) {
                    "Não consegui ler a GPU."
                } else {
                    val topo = g.freqsHz.last()
                    val piso = if (modo == 2) topo else g.freqsHz.minByOrNull { abs(it - (topo * 0.6).toLong()) } ?: topo
                    Tuner.gpuManual(this, null, piso, topo)
                }
            }
            main.post { aviso(msg) }
        }.start()
    }

    private fun executarModulo(m: Modulos.Modulo) {
        Thread {
            val r = Modulos.ligar(this, m.id, jogoAtual())
            main.post { aviso(r.msg) }
        }.start()
    }

    private fun atualizarAgora() {
        Thread {
            val s = Stats.ler()
            val b = Stats.bateria(this)
            main.post { aplicarLeitura(s, b) }
        }.start()
    }

    private fun duracao(ms: Long): String {
        val s = ms / 1000L
        val h = s / 3600L
        val m = (s % 3600L) / 60L
        val seg = s % 60L
        return if (h > 0) String.format(Locale.US, "%d:%02d:%02d", h, m, seg)
        else String.format(Locale.US, "%02d:%02d", m, seg)
    }

    private fun aplicarLeitura(s: Stats.Leitura?, bat: Int) {
        if (s != null) {
            if (s.cpuPct >= 0) {
                cCpu.unidade = "%"
                cCpu.definir(s.cpuPct / 100f, s.cpuPct.toString())
            } else {
                val fracCpu = if (s.cpuMaxMhz > 0) s.cpuMhz.toFloat() / s.cpuMaxMhz else 0f
                cCpu.unidade = "MHz"
                cCpu.definir(fracCpu, s.cpuMhz.toString())
            }
            if (s.gpuPct >= 0) cGpu.definir(s.gpuPct / 100f, s.gpuPct.toString()) else cGpu.definir(0f, "—")
            val pct = if (s.ramTotalMb > 0) s.ramUsadaMb * 100 / s.ramTotalMb else 0
            cRam.definir(pct / 100f, pct.toString())
            nuc.definir(s.cores, s.coresMax)
            tvGpu.text = if (s.gpuMhz > 0) "GPU Adreno • ${s.gpuMhz} MHz" + (if (s.gpuMaxMhz > 0) " de ${s.gpuMaxMhz}" else "") else "GPU —"
            sessao["Governor"]?.text = s.governor
            val t = s.temp
            sessao["Temperatura"]?.text = if (t != null) String.format(Locale.US, "%.0f °C", t) else "—"
        }
        val f = Fps.atual
        if (f != null) {
            val topo = maxOf(60f, Fps.historico().maxOrNull() ?: 0f)
            cFps.definir(f.fps / topo, Math.round(f.fps).toString())
        } else {
            cFps.definir(0f, "—")
        }
        tvHora.text = formatoHora.format(java.util.Date())
        tvBat.text = if (bat >= 0) "$bat%" else ""

        val aplicado = Prefs.aplicado(this)
        seg.definir(Tuner.perfis.indexOfFirst { it.id == aplicado })
        tvDesc.text = Tuner.perfis.firstOrNull { it.id == aplicado }?.desc ?: "Ajuste manual em uso."
        for ((id, cx) in caixas) {
            if (id == "fps_overlay") continue
            val v = Prefs.modAtivo(this, id)
            if (cx.estaLigada() != v) cx.definir(v, if (v) "Ativo" else "Desligado")
        }

        val pkg = jogoAtual()
        var nome = "—"
        if (pkg != null) {
            nome = try {
                packageManager.getApplicationLabel(packageManager.getApplicationInfo(pkg, 0)).toString()
            } catch (e: Exception) {
                pkg
            }
        }
        sessao["Jogo"]?.text = nome
        val ini = Prefs.lng(this, "jogo_inicio", 0L)
        sessao["Tempo de jogo"]?.text = if (pkg != null && ini > 0L) duracao(System.currentTimeMillis() - ini) else "—"
        val b0 = Prefs.str(this, "jogo_bat0", "").toIntOrNull()
        sessao["Bateria"]?.text = if (b0 != null && b0 >= 0 && bat >= 0) "$b0% → $bat%" else if (bat >= 0) "$bat%" else "—"
        sessao["Perfil ativo"]?.text = Tuner.perfis.firstOrNull { it.id == aplicado }?.nome ?: "Manual"
    }

    override fun onDestroy() {
        ativo = false
        val r = raizV
        if (r != null) {
            try { wm?.removeView(r) } catch (e: Exception) { }
        }
        raizV = null
        wm = null
        super.onDestroy()
    }
}
