package br.com.rootboost

import android.app.Service
import android.content.Intent
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.util.Locale
import kotlin.math.abs

/**
 * Painel do Game Turbo dentro do jogo: uma alça na borda esquerda que abre o painel
 * (medidores, perfis, módulos e dados da sessão). Toque fora para fechar.
 */
class PainelJogoService : Service() {

    private var wm: WindowManager? = null
    private var raizV: FrameLayout? = null
    private lateinit var alca: View
    private lateinit var painel: LinearLayout
    private lateinit var params: WindowManager.LayoutParams
    private var aberto = false
    private var yAlca = 0
    @Volatile private var ativo = false
    private val main = Handler(Looper.getMainLooper())

    private lateinit var medCpu: Medidor
    private lateinit var medGpu: Medidor
    private lateinit var medRam: Medidor
    private lateinit var medFps: Medidor
    private lateinit var seg: Segmentado
    private lateinit var tvDesc: TextView
    private val chaves = HashMap<String, Chave>()
    private val sessao = HashMap<String, TextView>()
    private val paginas = ArrayList<View>()
    private val icones = ArrayList<Icone>()
    private val fundos = ArrayList<FrameLayout>()

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (!Settings.canDrawOverlays(this)) { stopSelf(); return START_NOT_STICKY }
        if (raizV != null) return START_NOT_STICKY

        val gerente = getSystemService(WINDOW_SERVICE) as WindowManager
        wm = gerente
        val dm = resources.displayMetrics
        val r = FrameLayout(this)
        raizV = r

        // alça
        val raio = dp(14).toFloat()
        val a = FrameLayout(this)
        a.background = GradientDrawable().apply {
            setColor(0xDD16181D.toInt())
            cornerRadii = floatArrayOf(0f, 0f, raio, raio, raio, raio, 0f, 0f)
            setStroke(dp(1), Cores.LINHA)
        }
        val raioIcone = Icone(this, "raio")
        raioIcone.cor = Cores.ACENTO
        a.addView(raioIcone, FrameLayout.LayoutParams(AUTO, AUTO, Gravity.CENTER))
        alca = a
        r.addView(a, FrameLayout.LayoutParams(dp(30), dp(60)))

        // painel
        painel = construirPainel()
        painel.visibility = View.GONE
        r.addView(painel, FrameLayout.LayoutParams(dp(400), dp(300)))

        params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        )
        params.gravity = Gravity.TOP or Gravity.START
        params.x = 0
        yAlca = dm.heightPixels / 3
        params.y = yAlca

        // arrastar a alça na vertical; toque abre o painel
        var iy = 0
        var ty = 0f
        var moveu = false
        a.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { iy = params.y; ty = e.rawY; moveu = false }
                MotionEvent.ACTION_MOVE -> {
                    val d = (e.rawY - ty).toInt()
                    if (abs(d) > dp(6)) moveu = true
                    if (moveu) {
                        val max = resources.displayMetrics.heightPixels - dp(60)
                        params.y = (iy + d).coerceIn(0, max)
                        yAlca = params.y
                        gerente.updateViewLayout(r, params)
                    }
                }
                MotionEvent.ACTION_UP -> if (!moveu) abrir()
            }
            true
        }
        r.setOnTouchListener { _, e ->
            if (e.action == MotionEvent.ACTION_OUTSIDE && aberto) fechar()
            false
        }

        gerente.addView(r, params)
        selecionarPagina(0)

        ativo = true
        Thread {
            while (ativo) {
                if (aberto) {
                    val s = Stats.ler()
                    val b = Stats.bateria(this)
                    main.post { aplicarLeitura(s, b) }
                }
                try {
                    Thread.sleep(2000)
                } catch (e: InterruptedException) {
                    break
                }
            }
        }.start()
        return START_NOT_STICKY
    }

    // ---- abrir / fechar ----------------------------------------------------

    private fun abrir() {
        val r = raizV ?: return
        val dm = resources.displayMetrics
        val paisagem = dm.widthPixels > dm.heightPixels
        val larg = if (paisagem) minOf((dm.widthPixels * 0.62f).toInt(), dp(480)) else (dm.widthPixels * 0.94f).toInt()
        val alt = minOf((dm.heightPixels * 0.86f).toInt(), dp(330))
        val lpPainel = painel.layoutParams
        lpPainel.width = larg
        lpPainel.height = alt
        painel.layoutParams = lpPainel
        aberto = true
        alca.visibility = View.GONE
        painel.visibility = View.VISIBLE
        params.gravity = Gravity.CENTER_VERTICAL or Gravity.START
        params.x = dp(10)
        params.y = 0
        wm?.updateViewLayout(r, params)
        Thread {
            val s = Stats.ler()
            val b = Stats.bateria(this)
            main.post { aplicarLeitura(s, b) }
        }.start()
    }

    private fun fechar() {
        val r = raizV ?: return
        aberto = false
        painel.visibility = View.GONE
        alca.visibility = View.VISIBLE
        params.gravity = Gravity.TOP or Gravity.START
        params.x = 0
        params.y = yAlca.coerceIn(0, resources.displayMetrics.heightPixels - dp(60))
        wm?.updateViewLayout(r, params)
    }

    // ---- construção do painel ----------------------------------------------

    private fun construirPainel(): LinearLayout {
        val p = LinearLayout(this)
        p.orientation = LinearLayout.HORIZONTAL
        p.background = forma(0xF2121418.toInt(), 22, Cores.LINHA, 1)

        // trilho de abas
        val rail = vertical()
        rail.gravity = Gravity.CENTER_HORIZONTAL
        rail.setPadding(dp(6), dp(12), dp(6), dp(12))
        val tipos = listOf("inicio", "modulos", "info")
        for (i in tipos.indices) {
            val caixa = FrameLayout(this)
            val ic = Icone(this, tipos[i])
            caixa.addView(ic, FrameLayout.LayoutParams(AUTO, AUTO, Gravity.CENTER))
            caixa.setOnClickListener { selecionarPagina(i) }
            rail.addView(caixa, LinearLayout.LayoutParams(dp(44), dp(44)).apply { bottomMargin = dp(6) })
            icones.add(ic)
            fundos.add(caixa)
        }
        rail.addView(View(this), LinearLayout.LayoutParams(1, 0, 1f))
        val fecharCx = FrameLayout(this)
        val fecharIc = Icone(this, "fechar")
        fecharCx.addView(fecharIc, FrameLayout.LayoutParams(AUTO, AUTO, Gravity.CENTER))
        fecharCx.setOnClickListener { fechar() }
        rail.addView(fecharCx, LinearLayout.LayoutParams(dp(44), dp(44)))
        p.addView(rail, LinearLayout.LayoutParams(dp(56), CHEIO))

        val linhaV = View(this)
        linhaV.setBackgroundColor(Cores.LINHA)
        p.addView(linhaV, LinearLayout.LayoutParams(dp(1), CHEIO))

        val conteudo = FrameLayout(this)
        paginas.add(paginaDesempenho())
        paginas.add(paginaModulos())
        paginas.add(paginaSessao())
        for (pg in paginas) conteudo.addView(pg, FrameLayout.LayoutParams(CHEIO, CHEIO))
        p.addView(conteudo, LinearLayout.LayoutParams(0, CHEIO, 1f))
        return p
    }

    private fun paginaDesempenho(): View {
        val col = vertical()
        col.setPadding(dp(16), dp(14), dp(16), dp(10))
        col.addView(texto("Game Turbo", 15f, Cores.TEXTO, true))

        val medidores = LinearLayout(this)
        medidores.orientation = LinearLayout.HORIZONTAL
        medCpu = Medidor(this); medCpu.rotulo = "CPU"; medCpu.unidade = "MHz"
        medGpu = Medidor(this); medGpu.rotulo = "GPU"; medGpu.unidade = "%"
        medRam = Medidor(this); medRam.rotulo = "RAM"; medRam.unidade = "%"
        medFps = Medidor(this); medFps.rotulo = "Jogo"; medFps.unidade = "FPS"
        for (m in listOf(medCpu, medGpu, medRam, medFps)) {
            medidores.addView(m, LinearLayout.LayoutParams(0, AUTO, 1f))
        }
        col.addView(medidores, lp(CHEIO, AUTO, 6, 8))

        seg = Segmentado(this, Tuner.perfis.map { it.nome }, 11f)
        seg.aoEscolher = { i -> aplicarPerfil(Tuner.perfis[i].id) }
        col.addView(seg, lp(CHEIO, AUTO, 4, 0))

        tvDesc = texto("", 11.5f, Cores.SUAVE)
        col.addView(tvDesc, lp(CHEIO, AUTO, 8, 0))

        val rolagem = ScrollView(this)
        rolagem.isVerticalScrollBarEnabled = false
        rolagem.addView(col)
        return rolagem
    }

    private fun paginaModulos(): View {
        val col = vertical()
        col.setPadding(dp(16), dp(14), dp(16), dp(14))
        col.addView(texto("Módulos", 15f, Cores.TEXTO, true))
        var linhaAtual: LinearLayout? = null
        val itens = ArrayList<String>()
        itens.add("fps_overlay")
        for (m in Modulos.lista) itens.add(m.id)
        for (i in itens.indices) {
            val idItem = itens[i]
            val m = Modulos.lista.firstOrNull { it.id == idItem }
            if (i % 2 == 0) {
                val l = LinearLayout(this)
                l.orientation = LinearLayout.HORIZONTAL
                linhaAtual = l
                col.addView(l, lp(CHEIO, AUTO, 8, 0))
            }
            val cel = horizontal()
            cel.setPadding(dp(12), dp(10), dp(10), dp(10))
            cel.background = forma(Cores.SUPERFICIE2, 12)
            cel.addView(texto(m?.nome ?: "Contador de FPS", 12f, Cores.TEXTO), LinearLayout.LayoutParams(0, AUTO, 1f))
            if (m == null) {
                val ch = Chave(this)
                ch.definir(Prefs.fpsOn(this))
                ch.aoMudar = { ligado -> alternarFps(ligado) }
                cel.addView(ch)
            } else if (m.reversivel) {
                val ch = Chave(this)
                ch.definir(Prefs.modAtivo(this, m.id))
                ch.aoMudar = { ligado -> alternarModulo(m, ligado) }
                chaves[m.id] = ch
                cel.addView(ch)
            } else {
                val b = texto("Executar", 11.5f, Cores.ACENTO, true)
                b.setPadding(dp(8), dp(6), dp(4), dp(6))
                b.setOnClickListener { executarModulo(m) }
                cel.addView(b)
            }
            val lpCel = LinearLayout.LayoutParams(0, AUTO, 1f)
            if (i % 2 == 0) lpCel.rightMargin = dp(8)
            linhaAtual?.addView(cel, lpCel)
        }
        val rolagem = ScrollView(this)
        rolagem.isVerticalScrollBarEnabled = false
        rolagem.addView(col)
        return rolagem
    }

    private fun paginaSessao(): View {
        val col = vertical()
        col.setPadding(dp(16), dp(14), dp(16), dp(14))
        col.addView(texto("Sessão", 15f, Cores.TEXTO, true))
        for (rotulo in listOf("Jogo", "Tempo de jogo", "Temperatura", "Bateria", "Perfil ativo", "Governor")) {
            val l = horizontal()
            l.setPadding(0, dp(10), 0, dp(10))
            l.addView(texto(rotulo, 12.5f, Cores.SUAVE), LinearLayout.LayoutParams(0, AUTO, 1f))
            val v = texto("—", 13f, Cores.TEXTO, true)
            l.addView(v)
            sessao[rotulo] = v
            col.addView(l, lp(CHEIO, AUTO, 0, 0))
            col.addView(divisor(), LinearLayout.LayoutParams(CHEIO, dp(1)))
        }
        val rolagem = ScrollView(this)
        rolagem.isVerticalScrollBarEnabled = false
        rolagem.addView(col)
        return rolagem
    }

    private fun selecionarPagina(i: Int) {
        for (k in paginas.indices) paginas[k].visibility = if (k == i) View.VISIBLE else View.GONE
        for (k in icones.indices) icones[k].cor = if (k == i) Cores.ACENTO else Cores.SUAVE
        for (k in fundos.indices) fundos[k].background = if (k == i) forma(Cores.SELECIONADO, 12) else null
    }

    // ---- ações -------------------------------------------------------------

    private fun aviso(msg: String) {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
    }

    private fun aplicarPerfil(id: String) {
        Thread {
            val m = Tuner.aplicar(this, id)
            main.post { aviso(m); atualizarAgora() }
        }.start()
    }

    private fun alternarFps(ligado: Boolean) {
        Prefs.setFpsOn(this, ligado)
        if (ligado) startService(Intent(this, FpsService::class.java))
        else stopService(Intent(this, FpsService::class.java))
    }

    private fun jogoAtual(): String? = Prefs.str(this, "em_jogo", "").takeIf { it.isNotEmpty() }

    private fun alternarModulo(m: Modulos.Modulo, ligar: Boolean) {
        Thread {
            val r = if (ligar) Modulos.ligar(this, m.id, jogoAtual()) else Modulos.desligar(this, m.id)
            main.post {
                aviso(r.msg)
                chaves[m.id]?.definir(Prefs.modAtivo(this, m.id), true)
            }
        }.start()
    }

    private fun executarModulo(m: Modulos.Modulo) {
        Thread {
            val r = Modulos.ligar(this, m.id, jogoAtual())
            main.post { aviso(r.msg) }
        }.start()
    }

    private fun atualizarAgora() {
        Thread {
            val s = Stats.ler()
            val b = Stats.bateria(this)
            main.post { aplicarLeitura(s, b) }
        }.start()
    }

    private fun duracao(ms: Long): String {
        val s = ms / 1000L
        val h = s / 3600L
        val m = (s % 3600L) / 60L
        val seg = s % 60L
        return if (h > 0) String.format(Locale.US, "%d:%02d:%02d", h, m, seg)
        else String.format(Locale.US, "%02d:%02d", m, seg)
    }

    private fun aplicarLeitura(s: Stats.Leitura?, bat: Int) {
        if (s != null) {
            val fracCpu = if (s.cpuMaxMhz > 0) s.cpuMhz.toFloat() / s.cpuMaxMhz else 0f
            medCpu.definir(fracCpu, s.cpuMhz.toString())
            if (s.gpuPct >= 0) medGpu.definir(s.gpuPct / 100f, s.gpuPct.toString()) else medGpu.definir(0f, "—")
            val pct = if (s.ramTotalMb > 0) s.ramUsadaMb * 100 / s.ramTotalMb else 0
            medRam.definir(pct / 100f, pct.toString())
            sessao["Governor"]?.text = s.governor
            val t = s.temp
            sessao["Temperatura"]?.text = if (t != null) String.format(Locale.US, "%.0f °C", t) else "—"
        }
        val f = Fps.atual
        if (f != null) {
            val topo = maxOf(60f, Fps.historico().maxOrNull() ?: 0f)
            medFps.definir(f.fps / topo, Math.round(f.fps).toString(), if (f.fps >= topo * 0.9f) Cores.OK else Cores.ACENTO)
        } else {
            medFps.definir(0f, "—")
        }

        val aplicado = Prefs.aplicado(this)
        seg.definir(Tuner.perfis.indexOfFirst { it.id == aplicado })
        tvDesc.text = Tuner.perfis.firstOrNull { it.id == aplicado }?.desc ?: "Ajuste manual em uso."
        for ((id, ch) in chaves) {
            val v = Prefs.modAtivo(this, id)
            if (ch.estaMarcado() != v) ch.definir(v, true)
        }

        val pkg = jogoAtual()
        var nome = "—"
        if (pkg != null) {
            nome = try {
                packageManager.getApplicationLabel(packageManager.getApplicationInfo(pkg, 0)).toString()
            } catch (e: Exception) {
                pkg
            }
        }
        sessao["Jogo"]?.text = nome
        val ini = Prefs.lng(this, "jogo_inicio", 0L)
        sessao["Tempo de jogo"]?.text = if (pkg != null && ini > 0L) duracao(System.currentTimeMillis() - ini) else "—"
        val b0 = Prefs.str(this, "jogo_bat0", "").toIntOrNull()
        sessao["Bateria"]?.text = if (b0 != null && b0 >= 0 && bat >= 0) "$b0% → $bat%" else if (bat >= 0) "$bat%" else "—"
        sessao["Perfil ativo"]?.text = Tuner.perfis.firstOrNull { it.id == aplicado }?.nome ?: "Manual"
    }

    override fun onDestroy() {
        ativo = false
        val r = raizV
        if (r != null) {
            try { wm?.removeView(r) } catch (e: Exception) { }
        }
        raizV = null
        wm = null
        super.onDestroy()
    }
}
