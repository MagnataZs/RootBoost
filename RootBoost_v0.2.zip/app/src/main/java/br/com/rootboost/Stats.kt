package br.com.rootboost

import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import java.io.File

object Stats {
    class Leitura(
        val cpuMhz: Int,
        val cpuMaxMhz: Int,
        val cpuPct: Int,      // -1 na primeira leitura
        val gpuPct: Int,      // -1 se o aparelho não informa
        val gpuMhz: Int,
        val temp: Float?,
        val ramUsadaMb: Int,
        val ramTotalMb: Int,
        val governor: String,
        val cores: List<Int> = emptyList(),       // MHz de cada núcleo online
        val coresMax: List<Int> = emptyList(),
        val gpuMaxMhz: Int = 0
    )

    private var cpuAnterior: LongArray? = null

    private val SCRIPT = sh("""
cat /sys/devices/system/cpu/cpu[0-9]*/cpufreq/scaling_cur_freq 2>/dev/null
echo "#M"
cat /sys/devices/system/cpu/cpu[0-9]*/cpufreq/cpuinfo_max_freq 2>/dev/null
echo "#T"
for z in /sys/class/thermal/thermal_zone*; do t=§(cat §z/type 2>/dev/null); v=§(cat §z/temp 2>/dev/null); echo "§t §v"; done
echo "#B"
cat /sys/class/power_supply/battery/temp 2>/dev/null
echo "#G"
cat /sys/devices/system/cpu/cpufreq/policy0/scaling_governor 2>/dev/null || cat /sys/devices/system/cpu/cpu0/cpufreq/scaling_governor 2>/dev/null
echo "#S"
head -n 1 /proc/stat
echo "#U"
cat /sys/class/kgsl/kgsl-3d0/gpu_busy_percentage 2>/dev/null || cat /sys/class/kgsl/kgsl-3d0/gpubusy 2>/dev/null
echo "#H"
cat /sys/class/kgsl/kgsl-3d0/devfreq/cur_freq 2>/dev/null || cat /sys/class/kgsl/kgsl-3d0/gpuclk 2>/dev/null
echo "#X"
cat /sys/class/kgsl/kgsl-3d0/devfreq/max_freq 2>/dev/null || cat /sys/class/kgsl/kgsl-3d0/max_gpuclk 2>/dev/null
echo "#MU"
cat /sys/kernel/ged/hal/gpu_utilization 2>/dev/null || cat /sys/kernel/gpu/gpu_busy 2>/dev/null || cat /sys/class/devfreq/*mali*/load 2>/dev/null
echo "#MH"
cat /sys/class/devfreq/*mali*/cur_freq 2>/dev/null || cat /sys/kernel/ged/hal/current_freqency 2>/dev/null
echo "#MX"
cat /sys/class/devfreq/*mali*/max_freq 2>/dev/null
""")

    private fun mhz(v: Long): Int = when {
        v > 10_000_000L -> (v / 1_000_000L).toInt()
        v > 10_000L -> (v / 1_000L).toInt()
        else -> v.toInt()
    }

    private fun normalizar(v: Float?): Float? {
        if (v == null) return null
        val graus = if (v >= 1000f) v / 1000f else v
        return if (graus in 15f..120f) graus else null
    }

    fun memInfo(): Map<String, Long> = try {
        File("/proc/meminfo").readLines().mapNotNull { l ->
            val p = l.split(":")
            if (p.size == 2) p[0].trim() to (p[1].trim().split(" ")[0].toLongOrNull() ?: 0L) else null
        }.toMap()
    } catch (e: Exception) {
        emptyMap()
    }

    fun ramLivreMb(): Int = ((memInfo()["MemAvailable"] ?: 0L) / 1024L).toInt()

    /** Nível da bateria em % (-1 se não der para ler). Não precisa de root. */
    fun bateria(ctx: Context): Int {
        val i: Intent = ctx.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED)) ?: return -1
        val nivel = i.getIntExtra("level", -1)
        val escala = i.getIntExtra("scale", 100)
        return if (nivel < 0 || escala <= 0) -1 else nivel * 100 / escala
    }

    @Synchronized
    fun ler(): Leitura? {
        val saida = RootShell.run(SCRIPT) ?: return null
        var secao = "F"
        var khz = 0L
        var khzMax = 0L
        var tempCpu: Float? = null
        var tempBat: Float? = null
        var gov = "—"
        var cpuPct = -1
        var gpuPct = -1
        var gpuMhz = 0
        var gpuMax = 0
        val nucleos = ArrayList<Int>()
        val nucleosMax = ArrayList<Int>()
        for (l in saida.lines()) {
            val t = l.trim()
            if (t.startsWith("#")) { secao = t.substring(1); continue }
            when (secao) {
                "F" -> {
                    val v = t.toLongOrNull()
                    if (v != null && v > khz) khz = v
                    if (v != null) nucleos.add((v / 1000L).toInt())
                }
                "M" -> {
                    val v = t.toLongOrNull()
                    if (v != null && v > khzMax) khzMax = v
                    if (v != null) nucleosMax.add((v / 1000L).toInt())
                }
                "T" -> {
                    val p = t.split(" ").filter { it.isNotEmpty() }
                    if (p.size >= 2) {
                        val tipo = p.dropLast(1).joinToString(" ").lowercase()
                        val v = normalizar(p.last().toFloatOrNull())
                        val atual = tempCpu
                        if (v != null && tipo.contains("cpu") && (atual == null || v > atual)) tempCpu = v
                    }
                }
                "B" -> {
                    val v = t.toFloatOrNull()
                    if (v != null) tempBat = normalizar(v / 10f)
                }
                "G" -> if (t.isNotEmpty() && !t.startsWith("cat:")) gov = t
                "S" -> if (t.startsWith("cpu")) {
                    val n = t.split(Regex("\\s+")).drop(1).mapNotNull { it.toLongOrNull() }
                    if (n.size >= 5) {
                        val total = n.take(8).sum()
                        val ocioso = n[3] + n[4]
                        val ant = cpuAnterior
                        if (ant != null) {
                            val dt = total - ant[0]
                            val di = ocioso - ant[1]
                            if (dt > 0L) cpuPct = (100L * (dt - di) / dt).toInt().coerceIn(0, 100)
                        }
                        cpuAnterior = longArrayOf(total, ocioso)
                    }
                }
                "U" -> if (t.isNotEmpty() && !t.startsWith("cat:")) {
                    val nums = Regex("\\d+").findAll(t).map { it.value.toLong() }.toList()
                    if (nums.isNotEmpty()) {
                        if (t.contains("%") || nums.size == 1) {
                            gpuPct = nums[0].toInt().coerceIn(0, 100)
                        } else if (nums[1] > 0L) {
                            gpuPct = (100L * nums[0] / nums[1]).toInt().coerceIn(0, 100)
                        }
                    }
                }
                "H" -> {
                    val v = t.toLongOrNull()
                    if (v != null) gpuMhz = if (v > 1_000_000L) (v / 1_000_000L).toInt() else v.toInt()
                }
                "X" -> {
                    val v = t.toLongOrNull()
                    if (v != null) gpuMax = if (v > 1_000_000L) (v / 1_000_000L).toInt() else v.toInt()
                }
                // Mali e MediaTek: o primeiro número da linha é a carga em %; as frequências vêm em Hz, kHz ou MHz
                "MU" -> if (gpuPct < 0 && t.isNotEmpty() && !t.startsWith("cat:")) {
                    val n = Regex("\\d+").find(t)?.value?.toIntOrNull()
                    if (n != null) gpuPct = n.coerceIn(0, 100)
                }
                "MH" -> if (gpuMhz == 0 && t.isNotEmpty()) {
                    val v = Regex("\\d+").findAll(t).map { it.value.toLong() }.maxOrNull()
                    if (v != null) gpuMhz = mhz(v)
                }
                "MX" -> if (gpuMax == 0 && t.isNotEmpty()) {
                    val v = Regex("\\d+").findAll(t).map { it.value.toLong() }.maxOrNull()
                    if (v != null) gpuMax = mhz(v)
                }
            }
        }
        val mem = memInfo()
        val total = ((mem["MemTotal"] ?: 0L) / 1024L).toInt()
        val livre = ((mem["MemAvailable"] ?: 0L) / 1024L).toInt()
        return Leitura(
            (khz / 1000L).toInt(), (khzMax / 1000L).toInt(), cpuPct, gpuPct, gpuMhz,
            tempCpu ?: tempBat, total - livre, total, gov,
            nucleos, nucleosMax, gpuMax
        )
    }
}
