package br.com.rootboost

import java.io.File

object Stats {
    class Leitura(
        val cpuMhz: Int,
        val temp: Float?,
        val ramUsadaMb: Int,
        val ramTotalMb: Int,
        val governor: String
    )

    // § vira $ (evita conflito com templates de string do Kotlin)
    private val SCRIPT = """
cat /sys/devices/system/cpu/cpu[0-9]*/cpufreq/scaling_cur_freq 2>/dev/null
echo "#T"
for z in /sys/class/thermal/thermal_zone*; do t=§(cat §z/type 2>/dev/null); v=§(cat §z/temp 2>/dev/null); echo "§t §v"; done
echo "#B"
cat /sys/class/power_supply/battery/temp 2>/dev/null
echo "#G"
cat /sys/devices/system/cpu/cpufreq/policy0/scaling_governor 2>/dev/null || cat /sys/devices/system/cpu/cpu0/cpufreq/scaling_governor 2>/dev/null
""".replace('§', '$')

    private fun normalizar(v: Float?): Float? {
        if (v == null) return null
        val graus = if (v >= 1000f) v / 1000f else v
        return if (graus in 15f..120f) graus else null
    }

    fun memInfo(): Map<String, Long> = try {
        File("/proc/meminfo").readLines().mapNotNull { l ->
            val p = l.split(":")
            if (p.size == 2) p[0].trim() to (p[1].trim().split(" ")[0].toLongOrNull() ?: 0L) else null
        }.toMap()
    } catch (e: Exception) {
        emptyMap()
    }

    fun ramLivreMb(): Int = ((memInfo()["MemAvailable"] ?: 0L) / 1024L).toInt()

    fun ler(): Leitura? {
        val saida = RootShell.run(SCRIPT) ?: return null
        var secao = "F"
        var khz = 0L
        var tempCpu: Float? = null
        var tempBat: Float? = null
        var gov = "—"
        for (l in saida.lines()) {
            val t = l.trim()
            if (t.startsWith("#")) { secao = t.substring(1); continue }
            when (secao) {
                "F" -> {
                    val v = t.toLongOrNull()
                    if (v != null && v > khz) khz = v
                }
                "T" -> {
                    val p = t.split(" ").filter { it.isNotEmpty() }
                    if (p.size >= 2) {
                        val tipo = p.dropLast(1).joinToString(" ").lowercase()
                        val v = normalizar(p.last().toFloatOrNull())
                        val atual = tempCpu
                        if (v != null && tipo.contains("cpu") && (atual == null || v > atual)) tempCpu = v
                    }
                }
                "B" -> {
                    val v = t.toFloatOrNull()
                    if (v != null) tempBat = normalizar(v / 10f)
                }
                "G" -> if (t.isNotEmpty() && !t.startsWith("cat:")) gov = t
            }
        }
        val mem = memInfo()
        val total = ((mem["MemTotal"] ?: 0L) / 1024L).toInt()
        val livre = ((mem["MemAvailable"] ?: 0L) / 1024L).toInt()
        return Leitura((khz / 1000L).toInt(), tempCpu ?: tempBat, total - livre, total, gov)
    }
}
