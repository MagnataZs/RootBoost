package br.com.rootboost

import java.util.Locale

/**
 * FPS real: lê os tempos de apresentação dos quadros do jogo no SurfaceFlinger
 * (dumpsys SurfaceFlinger --latency) e conta os quadros do último segundo.
 */
object Fps {
    class Medida(val fps: Float, val baixo1: Float, val frameMs: Float)
    private class Bruto(val m: Medida, val tMax: Long)

    @Volatile var atual: Medida? = null
    private val hist = ArrayList<Float>()
    private var camada: String? = null
    private var camadaPkg: String? = null
    private var ultimoMax = 0L

    @Synchronized
    fun registrar(v: Float) {
        hist.add(v)
        while (hist.size > 120) hist.removeAt(0)
    }

    @Synchronized
    fun historico(): List<Float> = ArrayList(hist)

    @Synchronized
    fun limpar() {
        hist.clear()
        atual = null
        camada = null
        camadaPkg = null
        ultimoMax = 0L
    }

    private fun calcular(saida: String): Bruto? {
        val ts = ArrayList<Long>()
        for (l in saida.lines().drop(1)) {
            val p = l.trim().split(Regex("\\s+"))
            if (p.size < 3) continue
            val t = p[1].toLongOrNull() ?: continue
            if (t > 0L && t < Long.MAX_VALUE / 2) ts.add(t)
        }
        if (ts.size < 3) return null
        ts.sort()
        val tMax = ts[ts.size - 1]
        val janela = ts.filter { it > tMax - 1_000_000_000L }
        var fps = 0f
        if (janela.size >= 2) {
            val span = janela[janela.size - 1] - janela[0]
            if (span > 0L) fps = (janela.size - 1) * 1e9f / span
        }
        val diffs = ArrayList<Long>()
        for (i in 1 until ts.size) {
            val d = ts[i] - ts[i - 1]
            if (d > 0L) diffs.add(d)
        }
        if (diffs.isEmpty()) return null
        diffs.sort()
        val p99 = diffs[((diffs.size - 1) * 0.99).toInt()]
        val baixo1 = 1e9f / p99
        val frameMs = if (fps > 0f) 1000f / fps else 0f
        return Bruto(Medida(fps, baixo1, frameMs), tMax)
    }

    private fun latencia(nome: String): String? {
        if (nome.contains("'")) return null
        return RootShell.run("dumpsys SurfaceFlinger --latency '$nome' 2>/dev/null")
    }

    private fun acharCamada(pkg: String): String? {
        val lista = RootShell.run("dumpsys SurfaceFlinger --list 2>/dev/null") ?: return null
        val cand = lista.lines().map { it.trim() }
            .filter {
                it.contains(pkg) && !it.contains("'") && !it.startsWith("Bounds for") &&
                    !it.startsWith("Background for") && !it.contains("Splash")
            }
            .sortedByDescending { if (it.startsWith("SurfaceView")) 1 else 0 }
            .take(5)
        var melhor: String? = null
        var melhorFps = -1f
        for (n in cand) {
            val saida = latencia(n) ?: continue
            val b = calcular(saida) ?: continue
            if (b.m.fps > melhorFps) {
                melhorFps = b.m.fps
                melhor = n
            }
        }
        return melhor ?: cand.firstOrNull()
    }

    /** Mede o FPS do jogo [pkg]. Null se não achou a camada do jogo. */
    fun medir(pkg: String): Medida? {
        if (camada == null || camadaPkg != pkg) {
            camada = acharCamada(pkg)
            camadaPkg = pkg
            ultimoMax = 0L
        }
        val c = camada ?: return null
        val saida = latencia(c)
        val b = if (saida == null) null else calcular(saida)
        if (b == null) {
            camada = null
            return null
        }
        if (b.tMax == ultimoMax) return Medida(0f, b.m.baixo1, 0f)   // nenhum quadro novo no último segundo
        ultimoMax = b.tMax
        return b.m
    }

    fun camadaAtual(): String? = camada

    fun diagnostico(pkg: String?): String {
        if (pkg == null) return "FPS: nenhum jogo em primeiro plano\n"
        val lista = RootShell.run("dumpsys SurfaceFlinger --list 2>/dev/null") ?: return "FPS: sem root\n"
        val cand = lista.lines().map { it.trim() }.filter { it.contains(pkg) }.take(4)
        val sb = StringBuilder("FPS, camadas de ").append(pkg).append(": ").append(cand.size).append('\n')
        for (n in cand) {
            val saida = latencia(n)
            val b = if (saida == null) null else calcular(saida)
            sb.append(" - ").append(n.take(64)).append(": ")
                .append(if (b == null) "sem dados" else String.format(Locale.US, "%.0f fps", b.m.fps))
                .append('\n')
        }
        return sb.toString()
    }
}
