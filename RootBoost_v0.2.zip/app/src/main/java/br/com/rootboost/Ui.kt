package br.com.rootboost

import android.content.Context
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.view.View
import android.view.WindowInsets
import android.widget.LinearLayout
import android.widget.TextView

const val CHEIO = -1
const val AUTO = -2

/** Paleta: azul-noite com periwinkle como cor de ação e âmbar reservado ao "turbo". */
object Cores {
    val FUNDO = 0xFF0F1220.toInt()
    val SUPERFICIE = 0xFF1A1F33.toInt()
    val SUPERFICIE2 = 0xFF232A45.toInt()
    val SELECIONADO = 0xFF222B52.toInt()
    val LINHA = 0xFF2C3354.toInt()
    val TEXTO = 0xFFEEF1FF.toInt()
    val SUAVE = 0xFF9AA3C7.toInt()
    val ACENTO = 0xFF8AA4FF.toInt()
    val TURBO = 0xFFFFB547.toInt()
    val OK = 0xFF6FE3B0.toInt()
    val ERRO = 0xFFFF7A7A.toInt()
}

fun Context.dp(v: Int): Int = (v * resources.displayMetrics.density + 0.5f).toInt()

fun Context.forma(cor: Int, raioDp: Int, borda: Int = 0, larguraDp: Int = 0): GradientDrawable =
    GradientDrawable().apply {
        setColor(cor)
        cornerRadius = dp(raioDp).toFloat()
        if (larguraDp > 0) setStroke(dp(larguraDp), borda)
    }

fun Context.texto(valor: String, sp: Float, cor: Int = Cores.TEXTO, negrito: Boolean = false): TextView =
    TextView(this).apply {
        text = valor
        textSize = sp
        setTextColor(cor)
        if (negrito) setTypeface(typeface, Typeface.BOLD)
    }

fun Context.lp(w: Int = CHEIO, h: Int = AUTO, topo: Int = 0, base: Int = 0): LinearLayout.LayoutParams =
    LinearLayout.LayoutParams(w, h).apply {
        topMargin = dp(topo)
        bottomMargin = dp(base)
    }

/** No Android 15 o app desenha atrás das barras do sistema; isto devolve o espaço delas. */
@Suppress("DEPRECATION")
fun aplicarInsets(v: View) {
    v.setOnApplyWindowInsetsListener { view, insets ->
        val topo: Int
        val base: Int
        if (Build.VERSION.SDK_INT >= 30) {
            val b = insets.getInsets(WindowInsets.Type.systemBars())
            topo = b.top
            base = b.bottom
        } else {
            topo = insets.systemWindowInsetTop
            base = insets.systemWindowInsetBottom
        }
        view.setPadding(0, topo, 0, base)
        insets
    }
}
