package br.com.rootboost

import android.content.Context
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.RippleDrawable
import android.os.Build
import android.view.Gravity
import android.view.View
import android.view.WindowInsets
import android.widget.LinearLayout
import android.widget.TextView

const val CHEIO = -1
const val AUTO = -2

/** Grafite neutro com laranja como única cor de ação. */
object Cores {
    val FUNDO = 0xFF080B16.toInt()
    val SUPERFICIE = 0xFF141B31.toInt()
    val SUPERFICIE2 = 0xFF182038.toInt()
    val SELECIONADO = 0xFF1A2650.toInt()
    val LINHA = 0xFF26304F.toInt()
    val TEXTO = 0xFFF1F5FF.toInt()
    val SUAVE = 0xFF8B93AD.toInt()
    val ACENTO = 0xFF3B82F6.toInt()
    val ACENTO2 = 0xFF22D3EE.toInt()
    val TURBO = ACENTO
    val OK = 0xFF34D399.toInt()
    val ERRO = 0xFFFF7676.toInt()
    val AMBAR = 0xFFFFC066.toInt()
    val AZUL = 0xFF8FB7FF.toInt()
}

val FonteMedia: Typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)

/** Fonte dos títulos: condensada e firme, no clima de painel de jogo (vem com o Android, não pesa no APK). */
val FonteTitulo: Typeface = Typeface.create("sans-serif-condensed", Typeface.BOLD)

fun Context.titulo(valor: String, sp: Float, cor: Int = Cores.TEXTO): TextView =
    TextView(this).apply {
        text = valor
        textSize = sp
        setTextColor(cor)
        typeface = FonteTitulo
        letterSpacing = 0.03f
    }

fun Context.dp(v: Int): Int = (v * resources.displayMetrics.density + 0.5f).toInt()

fun Context.forma(cor: Int, raioDp: Int, borda: Int = 0, larguraDp: Int = 0): GradientDrawable =
    GradientDrawable().apply {
        setColor(cor)
        cornerRadius = dp(raioDp).toFloat()
        if (larguraDp > 0) setStroke(dp(larguraDp), borda)
    }

/** Fundo arredondado com efeito de toque (ripple) que respeita os cantos. */
fun Context.clicavel(cor: Int, raioDp: Int, borda: Int = 0, larguraDp: Int = 0): RippleDrawable =
    RippleDrawable(
        ColorStateList.valueOf(0x33FFFFFF),
        forma(cor, raioDp, borda, larguraDp),
        forma(Color.WHITE, raioDp)
    )

fun Context.texto(valor: String, sp: Float, cor: Int = Cores.TEXTO, negrito: Boolean = false): TextView =
    TextView(this).apply {
        text = valor
        textSize = sp
        setTextColor(cor)
        if (negrito) typeface = FonteMedia
    }

fun Context.lp(w: Int = CHEIO, h: Int = AUTO, topo: Int = 0, base: Int = 0): LinearLayout.LayoutParams =
    LinearLayout.LayoutParams(w, h).apply {
        topMargin = dp(topo)
        bottomMargin = dp(base)
    }

fun Context.vertical(): LinearLayout = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }

fun Context.horizontal(): LinearLayout = LinearLayout(this).apply {
    orientation = LinearLayout.HORIZONTAL
    gravity = Gravity.CENTER_VERTICAL
}

/** Fundo em degradê suave na diagonal (menos "chapado" que uma cor única). */
fun Context.degrade(c1: Int, c2: Int, raioDp: Int, borda: Int = 0, larguraDp: Int = 0): GradientDrawable =
    GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(c1, c2)).apply {
        cornerRadius = dp(raioDp).toFloat()
        if (larguraDp > 0) setStroke(dp(larguraDp), borda)
    }

fun Context.cartao(pad: Int = 16): LinearLayout = vertical().apply {
    setPadding(dp(pad), dp(pad), dp(pad), dp(pad))
    background = degrade(Cores.SUPERFICIE2, Cores.SUPERFICIE, 22, Cores.LINHA, 1)
}

fun Context.divisor(): View = View(this).apply { setBackgroundColor(Cores.LINHA) }

fun Context.botao(rotulo: String, aoClicar: () -> Unit): TextView {
    val t = texto(rotulo, 15f, Color.WHITE, true)
    t.gravity = Gravity.CENTER
    t.setPadding(dp(16), dp(14), dp(16), dp(14))
    t.background = clicavel(Cores.ACENTO, 16)
    t.setOnClickListener { aoClicar() }
    return t
}

/** No Android 15 o app desenha atrás das barras do sistema; isto devolve o espaço delas. */
@Suppress("DEPRECATION")
fun aplicarInsets(v: View) {
    v.setOnApplyWindowInsetsListener { view, insets ->
        val topo: Int
        val base: Int
        if (Build.VERSION.SDK_INT >= 30) {
            val b = insets.getInsets(WindowInsets.Type.systemBars())
            topo = b.top
            base = b.bottom
        } else {
            topo = insets.systemWindowInsetTop
            base = insets.systemWindowInsetBottom
        }
        view.setPadding(0, topo, 0, base)
        insets
    }
}

/** Cabeçalho de seção: título em caixa alta com linha fina até o fim. */
fun Context.secaoLinha(titulo: String): LinearLayout {
    val l = horizontal()
    val t = texto(titulo.uppercase(), 12.5f, Cores.ACENTO, true)
    t.letterSpacing = 0.08f
    l.addView(t)
    l.addView(divisor(), LinearLayout.LayoutParams(0, dp(1), 1f).apply { leftMargin = dp(12) })
    return l
}
