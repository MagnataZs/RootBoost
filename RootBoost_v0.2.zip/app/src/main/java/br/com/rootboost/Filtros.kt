package br.com.rootboost

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.Gravity
import android.view.View
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.TextView
import java.util.Locale

/**
 * Filtros de imagem (estilo "filtro de cores" do Game Turbo): galeria de visuais com prévia,
 * força do efeito, pad de saturação e contraste, tom (frio/quente) e brilho. Sem barras deslizantes.
 * É usado igual no app e no painel dentro do jogo.
 */
class FiltrosPainel(ctx: Context, compacto: Boolean, private val aviso: (String) -> Unit) : LinearLayout(ctx) {

    private val cartoes = ArrayList<CartaoFiltro>()
    private val segForca: Segmentado
    private val rotForca: TextView
    private val pad: Pad2D
    private val tvLeitura: TextView
    private val segTom: Segmentado
    private val passoBrilho: Stepper
    private val main = Handler(Looper.getMainLooper())
    private var ultimoAoVivo = 0L
    private val forcas = floatArrayOf(0.5f, 1f, 1.5f)
    private var forcaAtual = Cor.forca(ctx)
    private var presetAtual: String? = null

    init {
        orientation = VERTICAL
        val c = ctx

        addView(c.titulo("Filtros de imagem", if (compacto) 18f else 22f))
        addView(
            c.texto("Escolha um visual e veja a prévia antes de aplicar. Vale em qualquer jogo (precisa de root).", 12f, Neon.SUAVE),
            c.lp(CHEIO, AUTO, 2, 10)
        )

        // galeria
        val fila = LinearLayout(c)
        fila.orientation = HORIZONTAL
        val larg = if (compacto) 84 else 94
        for (p in Cor.presets) {
            val cartao = CartaoFiltro(c, p, larg)
            cartao.forca = forcaAtual
            cartao.aoToque = { escolher(p) }
            cartoes.add(cartao)
            fila.addView(cartao, LayoutParams(AUTO, AUTO).apply { rightMargin = c.dp(8) })
        }
        val rolagem = HorizontalScrollView(c)
        rolagem.isHorizontalScrollBarEnabled = false
        rolagem.addView(fila)
        addView(rolagem, c.lp(CHEIO, AUTO, 0, 0))

        // força
        rotForca = c.texto("Força do filtro", 12.5f, Neon.TEXTO, true)
        addView(rotForca, c.lp(CHEIO, AUTO, 14, 6))
        segForca = Segmentado(c, listOf("Sutil", "Normal", "Forte"), 11.5f, Neon.AZUL, Neon.CARTAO_A)
        segForca.definir(indiceForca(forcaAtual))
        segForca.aoEscolher = { i -> mudarForca(forcas[i]) }
        addView(segForca, c.lp(CHEIO, AUTO, 0, 0))

        // ajuste fino
        addView(c.titulo("Ajuste fino", 15f), c.lp(CHEIO, AUTO, 18, 6))
        pad = Pad2D(c)
        pad.alturaDp = if (compacto) 118 else 150
        tvLeitura = c.texto("", 11.5f, Neon.SUAVE)
        pad.aoMudar = { s, k ->
            mostrarLeitura(s, k)
            val a = montar(s, k, null, null, null)
            aplicarAoVivo(a)
        }
        pad.aoSoltar = { s, k ->
            val a = montar(s, k, null, null, null)
            manual(a)
        }
        addView(pad, c.lp(CHEIO, AUTO, 0, 0))
        addView(tvLeitura, c.lp(CHEIO, AUTO, 6, 0))

        addView(c.texto("Tom", 12.5f, Neon.TEXTO, true), c.lp(CHEIO, AUTO, 12, 6))
        segTom = Segmentado(c, listOf("Frio", "Neutro", "Quente"), 11.5f, Neon.ROXO, Neon.CARTAO_A)
        segTom.aoEscolher = { i ->
            val atual = Cor.salvo(c)
            val r = if (i == 0) 0.94f else if (i == 2) 1.06f else 1f
            val b = if (i == 0) 1.08f else if (i == 2) 0.92f else 1f
            manual(Cor.Ajuste(atual.sat, atual.con, atual.bri, r, 1f, b))
        }
        addView(segTom, c.lp(CHEIO, AUTO, 0, 0))

        addView(c.texto("Brilho", 12.5f, Neon.TEXTO, true), c.lp(CHEIO, AUTO, 12, 6))
        passoBrilho = Stepper(c, -0.2f, 0.2f, 0.02f) { v -> String.format(Locale.US, "%+.2f", v) }
        passoBrilho.aoMudar = { v ->
            val atual = Cor.salvo(c)
            manual(Cor.Ajuste(atual.sat, atual.con, v, atual.r, atual.g, atual.b))
        }
        addView(passoBrilho, c.lp(CHEIO, AUTO, 0, 0))

        // só durante o jogo
        val linhaAuto = LinearLayout(c)
        linhaAuto.orientation = HORIZONTAL
        linhaAuto.gravity = Gravity.CENTER_VERTICAL
        linhaAuto.setPadding(c.dp(14), c.dp(12), c.dp(14), c.dp(12))
        linhaAuto.background = c.forma(Neon.CARTAO_A, 16, Neon.BORDA, 1)
        val txtAuto = LinearLayout(c)
        txtAuto.orientation = VERTICAL
        txtAuto.addView(c.texto("Aplicar só durante o jogo", 13.5f, Neon.TEXTO, true))
        txtAuto.addView(c.texto("Ao fechar o jogo, as cores voltam ao normal.", 11.5f, Neon.SUAVE), c.lp(CHEIO, AUTO, 2, 0))
        linhaAuto.addView(txtAuto, LayoutParams(0, AUTO, 1f))
        val chAuto = Chave(c)
        chAuto.definir(Prefs.modAuto(c, "cor"))
        chAuto.aoMudar = { v -> Prefs.setModAuto(c, "cor", v) }
        linhaAuto.addView(chAuto, LayoutParams(AUTO, AUTO).apply { leftMargin = c.dp(10) })
        addView(linhaAuto, c.lp(CHEIO, AUTO, 16, 0))

        val restaurar = c.texto("Restaurar cores originais", 13f, Neon.CIANO, true)
        restaurar.setPadding(0, c.dp(12), 0, c.dp(4))
        restaurar.setOnClickListener { escolher(Cor.presets[0]) }
        addView(restaurar)

        // estado inicial
        val id = Prefs.str(c, "cor_preset", "original")
        val salvo = Cor.salvo(c)
        sincronizar(salvo)
        marcar(if (id == "custom") null else id)
    }

    private fun indiceForca(k: Float): Int {
        var melhor = 1
        var dist = 9f
        for (i in forcas.indices) {
            val dd = Math.abs(forcas[i] - k)
            if (dd < dist) {
                dist = dd
                melhor = i
            }
        }
        return melhor
    }

    private fun montar(sat: Float?, con: Float?, bri: Float?, r: Float?, b: Float?): Cor.Ajuste {
        val a = Cor.salvo(context)
        return Cor.Ajuste(sat ?: a.sat, con ?: a.con, bri ?: a.bri, r ?: a.r, a.g, b ?: a.b)
    }

    private fun mostrarLeitura(sat: Float, con: Float) {
        tvLeitura.text = String.format(Locale.US, "Saturação %.2f  •  Contraste %.2f", sat, con)
    }

    /** Põe os controles de ajuste fino de acordo com o que está salvo. */
    private fun sincronizar(a: Cor.Ajuste) {
        pad.definir(a.sat, a.con)
        mostrarLeitura(a.sat, a.con)
        segTom.definir(if (a.r < 0.97f) 0 else if (a.r > 1.03f) 2 else 1)
        passoBrilho.definir(a.bri)
    }

    private fun marcar(id: String?) {
        presetAtual = id
        for (c in cartoes) c.selecionado = c.preset.id == id
        val v = if (id != null) View.VISIBLE else View.GONE
        segForca.visibility = v
        rotForca.visibility = v
    }

    private fun escolher(p: Cor.Preset) {
        Prefs.putStr(context, "cor_preset", p.id)
        val a = Cor.mesclar(p.ajuste, forcaAtual)
        Cor.salvar(context, a)
        sincronizar(a)
        marcar(p.id)
        aplicar(a, true)
    }

    private fun mudarForca(k: Float) {
        forcaAtual = k
        Cor.salvarForca(context, k)
        for (c in cartoes) c.forca = k
        val p = Cor.preset(presetAtual ?: return) ?: return
        escolher(p)
    }

    /** O usuário mexeu à mão: deixa de ser um preset pronto. */
    private fun manual(a: Cor.Ajuste) {
        Prefs.putStr(context, "cor_preset", "custom")
        Cor.salvar(context, a)
        sincronizar(a)
        marcar(null)
        aplicar(a, true)
    }

    private fun aplicarAoVivo(a: Cor.Ajuste) {
        val agora = SystemClock.uptimeMillis()
        if (agora - ultimoAoVivo < 200L) return
        ultimoAoVivo = agora
        aplicar(a, false)
    }

    private fun aplicar(a: Cor.Ajuste, avisar: Boolean) {
        Thread {
            val msg = Cor.aplicar(a)
            if (avisar && msg.startsWith("Sem")) main.post { aviso(msg) }
        }.start()
    }
}
