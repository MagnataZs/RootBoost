package br.com.rootboost

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Environment
import android.os.StatFs
import android.os.SystemClock
import android.provider.Settings
import java.util.Locale
import kotlin.math.abs

/**
 * Aplica perfis lendo e escrevendo no sysfs (CPU cpufreq e GPU devfreq/kgsl).
 * - Só mexe no que o aparelho expõe.
 * - Guarda os valores originais (por boot) e consegue restaurá-los.
 * - Não toca em proteção térmica.
 */
object Tuner {

    class Perfil(val id: String, val nome: String, val desc: String)

    val perfis = listOf(
        Perfil("eco", "Economia", "Limita o teto da CPU para gastar menos bateria."),
        Perfil("equilibrado", "Equilibrado", "Volta aos valores originais do aparelho."),
        Perfil("performance", "Performance", "Sobe a frequência mínima; o teto fica livre."),
        Perfil("gaming", "Gaming", "Resposta máxima. Esquenta mais e gasta mais bateria.")
    )

    class InfoCpu(val govs: List<String>, val gov: String, val minMhz: Int, val maxMhz: Int)

    private class Cpu(
        val path: String, val gov: String,
        val infoMin: Long, val infoMax: Long,
        val min: Long, val max: Long,
        val govs: List<String>, val freqs: List<Long>
    )

    private class Gpu(
        val path: String, val gov: String,
        val min: Long, val max: Long,
        val govs: List<String>, val freqs: List<Long>
    )

    private class Varredura(val cpus: List<Cpu>, val gpu: Gpu?)

    private val SCAN = sh("""
for d in /sys/devices/system/cpu/cpufreq/policy* /sys/devices/system/cpu/cpu[0-9]*/cpufreq; do
  [ -f "§d/scaling_governor" ] || continue
  r=§(readlink -f "§d")
  echo "CPU|§r|§(cat §d/scaling_governor)|§(cat §d/cpuinfo_min_freq)|§(cat §d/cpuinfo_max_freq)|§(cat §d/scaling_min_freq)|§(cat §d/scaling_max_freq)|§(cat §d/scaling_available_governors)|§(cat §d/scaling_available_frequencies 2>/dev/null)"
done
for d in /sys/class/kgsl/kgsl-3d0/devfreq /sys/class/devfreq/*kgsl* /sys/class/devfreq/*gpu* /sys/class/devfreq/*mali*; do
  [ -f "§d/governor" ] || continue
  r=§(readlink -f "§d")
  echo "GPU|§r|§(cat §d/governor)|§(cat §d/min_freq)|§(cat §d/max_freq)|§(cat §d/available_governors 2>/dev/null)|§(cat §d/available_frequencies 2>/dev/null)"
  break
done
""")

    private fun nums(s: String): List<Long> =
        s.trim().split(Regex("\\s+")).mapNotNull { it.toLongOrNull() }

    private fun palavras(s: String): List<String> =
        s.trim().split(Regex("\\s+")).filter { it.isNotEmpty() }

    private fun varrer(): Varredura? {
        val saida = RootShell.run(SCAN) ?: return null
        val cpus = ArrayList<Cpu>()
        var gpu: Gpu? = null
        for (linha in saida.lines()) {
            val p = linha.split("|")
            if (p[0] == "CPU" && p.size >= 9) {
                cpus.add(
                    Cpu(
                        p[1].trim(), p[2].trim(),
                        p[3].trim().toLongOrNull() ?: 0L, p[4].trim().toLongOrNull() ?: 0L,
                        p[5].trim().toLongOrNull() ?: 0L, p[6].trim().toLongOrNull() ?: 0L,
                        palavras(p[7]), nums(p[8])
                    )
                )
            } else if (p[0] == "GPU" && p.size >= 7) {
                gpu = Gpu(
                    p[1].trim(), p[2].trim(),
                    p[3].trim().toLongOrNull() ?: 0L, p[4].trim().toLongOrNull() ?: 0L,
                    palavras(p[5]), nums(p[6])
                )
            }
        }
        val validas = cpus.filter { it.infoMax > 0 }.distinctBy { it.path }
        return Varredura(validas, gpu)
    }

    fun infoCpu(): InfoCpu? {
        val v = varrer() ?: return null
        if (v.cpus.isEmpty()) return null
        val comuns = v.cpus.map { it.govs.toSet() }.reduce { a, b -> a intersect b }.toList()
        val grande = v.cpus.maxByOrNull { it.infoMax } ?: return null
        return InfoCpu(
            comuns, grande.gov,
            (v.cpus.minOf { it.infoMin } / 1000L).toInt(),
            (v.cpus.maxOf { it.infoMax } / 1000L).toInt()
        )
    }

    // ---- valores originais -------------------------------------------------

    /** Guarda os valores originais uma vez por boot (antes de qualquer escrita nossa). */
    private fun garantirOriginais(ctx: Context, v: Varredura) {
        val boot = System.currentTimeMillis() - SystemClock.elapsedRealtime()
        val salvo = Prefs.lng(ctx, "orig_boot", -1L)
        if (abs(boot - salvo) < 60_000L) return
        for (c in v.cpus) Prefs.putStr(ctx, "orig_" + c.path, "${c.gov}|${c.min}|${c.max}")
        val g = v.gpu
        if (g != null) Prefs.putStr(ctx, "orig_" + g.path, "${g.gov}|${g.min}|${g.max}")
        Prefs.putLng(ctx, "orig_boot", boot)
    }

    private fun original(ctx: Context, path: String): List<String>? {
        val s = Prefs.str(ctx, "orig_$path", "")
        return if (s.isEmpty()) null else s.split("|")
    }

    // ---- escrita -----------------------------------------------------------

    private fun esc(sb: StringBuilder, caminho: String, valor: Any) {
        sb.append("chmod 644 ").append(caminho).append(" 2>/dev/null; ")
            .append("{ echo ").append(valor).append(" > ").append(caminho).append("; } 2>/dev/null\n")
    }

    private fun escolher(disp: List<String>, vararg prefs: String): String? =
        prefs.firstOrNull { it in disp }

    private fun freq(c: Cpu, fracao: Double): Long {
        val alvo = (c.infoMax * fracao).toLong()
        val cand = c.freqs.filter { it in c.infoMin..c.infoMax }
        val f = cand.minByOrNull { abs(it - alvo) } ?: alvo
        return f.coerceIn(c.infoMin, c.infoMax)
    }

    private fun cpuLinhas(sb: StringBuilder, c: Cpu, gov: String?, min: Long, max: Long) {
        if (gov != null && gov != c.gov) esc(sb, c.path + "/scaling_governor", gov)
        esc(sb, c.path + "/scaling_min_freq", c.infoMin)   // abre espaço antes de mexer no teto
        esc(sb, c.path + "/scaling_max_freq", max)
        esc(sb, c.path + "/scaling_min_freq", min)
    }

    private fun resumo(): String {
        val depois = varrer()
        val govs = depois?.cpus?.map { it.gov }?.distinct()?.joinToString("/") ?: "?"
        val topoMhz = (depois?.cpus?.maxOfOrNull { it.max } ?: 0L) / 1000L
        return "CPU $govs, até $topoMhz MHz"
    }

    /** Aplica um perfil e devolve uma mensagem pronta para mostrar ao usuário. */
    fun aplicar(ctx: Context, id: String): String {
        val nome = perfis.firstOrNull { it.id == id }?.nome ?: id
        val antes = varrer() ?: return "Sem acesso root. Conceda no Magisk/KernelSU."
        if (antes.cpus.isEmpty()) return "Este aparelho não expõe controles de CPU em /sys."
        garantirOriginais(ctx, antes)

        val sb = StringBuilder()
        for (c in antes.cpus) {
            val o = original(ctx, c.path)
            when (id) {
                "eco" -> cpuLinhas(sb, c, escolher(c.govs, "schedutil", "interactive", "ondemand"), c.infoMin, freq(c, 0.65))
                "performance" -> cpuLinhas(sb, c, escolher(c.govs, "schedutil", "interactive", "ondemand"), freq(c, 0.40), c.infoMax)
                "gaming" -> cpuLinhas(sb, c, escolher(c.govs, "performance", "schedutil", "interactive"), freq(c, 0.60), c.infoMax)
                else -> {
                    val govOrig = o?.getOrNull(0)?.takeIf { it.isNotEmpty() }
                    val minOrig = (o?.getOrNull(1)?.toLongOrNull() ?: c.infoMin).coerceIn(c.infoMin, c.infoMax)
                    cpuLinhas(sb, c, govOrig, minOrig, c.infoMax)
                }
            }
        }

        val g = antes.gpu
        if (g != null) {
            val o = original(ctx, g.path)
            if (id == "gaming") {
                val topo = g.freqs.maxOrNull() ?: g.max
                val alvo = (topo * 0.6).toLong()
                var minAlvo = g.freqs.minByOrNull { abs(it - alvo) } ?: alvo
                if (g.max > 0 && minAlvo > g.max) minAlvo = g.max
                if ("performance" in g.govs && g.gov != "performance") esc(sb, g.path + "/governor", "performance")
                esc(sb, g.path + "/min_freq", minAlvo)
            } else if (o != null) {
                val govOrig = o.getOrNull(0) ?: ""
                val minOrig = o.getOrNull(1)?.toLongOrNull()
                if (govOrig.isNotEmpty() && govOrig != g.gov) esc(sb, g.path + "/governor", govOrig)
                if (minOrig != null) esc(sb, g.path + "/min_freq", minOrig)
            }
        }

        RootShell.run(sb.toString()) ?: return "Sem acesso root."
        Prefs.setAplicado(ctx, id)
        return "$nome aplicado • " + resumo()
    }

    /** Ajuste manual: governor (opcional) e limites de frequência em % do máximo de cada cluster. */
    fun cpuManual(ctx: Context, gov: String?, minPct: Int, maxPct: Int): String {
        val antes = varrer() ?: return "Sem acesso root."
        if (antes.cpus.isEmpty()) return "Este aparelho não expõe controles de CPU em /sys."
        garantirOriginais(ctx, antes)
        val sb = StringBuilder()
        for (c in antes.cpus) {
            val alvoGov = if (gov != null && gov in c.govs) gov else null
            val mx = freq(c, maxPct / 100.0)
            var mn = freq(c, minPct / 100.0)
            if (mn > mx) mn = mx
            cpuLinhas(sb, c, alvoGov, mn, mx)
        }
        RootShell.run(sb.toString()) ?: return "Sem acesso root."
        Prefs.setAplicado(ctx, "custom")
        return "Ajuste manual aplicado • " + resumo()
    }

    // ---- ferramentas -------------------------------------------------------

    fun limparRam(): String {
        val antes = Stats.ramLivreMb()
        RootShell.run("am kill-all 2>/dev/null; sync; { echo 3 > /proc/sys/vm/drop_caches; } 2>/dev/null; { echo 1 > /proc/sys/vm/compact_memory; } 2>/dev/null; sleep 1")
            ?: return "Sem acesso root."
        val depois = Stats.ramLivreMb()
        return "RAM livre: $antes MB → $depois MB"
    }

    private val NOME_PKG = Regex("[A-Za-z0-9_.]+")

    /** Encerra apps de terceiros, menos os protegidos, o launcher, o teclado e o jogo atual. */
    fun limpezaProfunda(ctx: Context, jogo: String?): String {
        val lista = RootShell.run("pm list packages -3 2>/dev/null") ?: return "Sem acesso root."
        val protegidos = HashSet<String>(Prefs.protegidos(ctx))
        protegidos.add(ctx.packageName)
        if (jogo != null) protegidos.add(jogo)
        val home = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME)
        ctx.packageManager.resolveActivity(home, PackageManager.MATCH_DEFAULT_ONLY)
            ?.activityInfo?.packageName?.let { protegidos.add(it) }
        Settings.Secure.getString(ctx.contentResolver, "default_input_method")
            ?.substringBefore('/')?.let { protegidos.add(it) }
        val alvos = lista.lines()
            .map { it.trim().removePrefix("package:") }
            .filter { NOME_PKG.matches(it) && it !in protegidos }
        if (alvos.isEmpty()) return "Nada para encerrar."
        val sb = StringBuilder()
        for (p in alvos) sb.append("am force-stop ").append(p).append(" 2>/dev/null\n")
        RootShell.run(sb.toString()) ?: return "Sem acesso root."
        return "${alvos.size} apps encerrados."
    }

    fun otimizarArmazenamento(): String {
        val saida = RootShell.run("fstrim -v /data 2>&1; fstrim -v /cache 2>&1") ?: return "Sem acesso root."
        return if (saida.contains("trimmed", ignoreCase = true)) "Armazenamento otimizado."
        else "O fstrim não respondeu: ${saida.take(80)}"
    }

    fun saturacao(valor: Float): String {
        val v = String.format(Locale.US, "%.2f", valor)
        RootShell.run("service call SurfaceFlinger 1022 f $v") ?: return "Sem acesso root."
        return "Saturação $v"
    }

    /** hz = 0 volta ao automático. */
    fun taxaTela(hz: Int): String {
        val cmd = if (hz == 0) "settings delete system min_refresh_rate; settings delete system peak_refresh_rate"
        else "settings put system min_refresh_rate $hz.0; settings put system peak_refresh_rate $hz.0"
        RootShell.run(cmd) ?: return "Sem acesso root."
        return if (hz == 0) "Taxa de atualização automática." else "Taxa de atualização em $hz Hz."
    }

    // ---- resolução, gráficos e sistema -----------------------------------------

    /** valor <= 0 volta à densidade original. */
    fun dpi(valor: Int): String {
        val cmd = if (valor <= 0) "wm density reset" else "wm density $valor"
        RootShell.run(cmd) ?: return "Sem acesso root."
        return if (valor <= 0) "Resolução restaurada." else "Densidade em $valor dpi."
    }

    /** 0 = padrão do sistema, 1 = Skia GL, 2 = Skia Vulkan (vale para apps abertos depois). */
    fun renderizador(modo: Int): String {
        val v = when (modo) {
            1 -> "skiagl"
            2 -> "skiavk"
            else -> ""
        }
        RootShell.run("setprop debug.hwui.renderer \"$v\"") ?: return "Sem acesso root."
        return when (modo) {
            1 -> "Renderizador Skia GL. Abra os apps de novo."
            2 -> "Renderizador Skia Vulkan. Abra os apps de novo."
            else -> "Renderizador padrão do sistema."
        }
    }

    /** 0 = padrão, 1 = Game Driver, 2 = ANGLE (vale para apps abertos depois). */
    fun driver(modo: Int): String {
        val cmd = when (modo) {
            1 -> "settings put global game_driver_all_apps 1; settings put global updatable_driver_all_apps 1; settings delete global angle_gl_driver_all_angle"
            2 -> "settings delete global game_driver_all_apps; settings delete global updatable_driver_all_apps; settings put global angle_gl_driver_all_angle 1"
            else -> "settings delete global game_driver_all_apps; settings delete global updatable_driver_all_apps; settings delete global angle_gl_driver_all_angle"
        }
        RootShell.run(cmd) ?: return "Sem acesso root."
        return when (modo) {
            1 -> "Game Driver ligado. Abra o jogo de novo."
            2 -> "ANGLE ligado. Abra o jogo de novo."
            else -> "Driver gráfico padrão."
        }
    }

    fun limparCache(): String {
        val pasta = Environment.getDataDirectory().path
        val antes = StatFs(pasta).availableBytes
        RootShell.run("pm trim-caches 999G 2>/dev/null; sync") ?: return "Sem acesso root."
        val depois = StatFs(pasta).availableBytes
        val mb = (depois - antes) / (1024L * 1024L)
        return if (mb > 0L) "Cache limpo: $mb MB liberados." else "Cache limpo."
    }

    /** Executa um comando como root (com limite de 10 s para não travar o shell). */
    fun terminal(cmd: String): String {
        val seguro = "'" + cmd.replace("'", "'\\''") + "'"
        val saida = RootShell.run("timeout 10 sh -c $seguro 2>&1") ?: return "Sem acesso root."
        return if (saida.isEmpty()) "(sem saída)" else saida.take(6000)
    }

    /** Anti-queda de FPS: sobe a frequência mínima por alguns segundos e depois volta ao perfil. */
    fun impulso(ctx: Context) {
        val t = Stats.ler()?.temp
        if (t != null && t >= 46f) return     // não força o aparelho quente
        val v = varrer() ?: return
        val sb = StringBuilder()
        for (c in v.cpus) esc(sb, c.path + "/scaling_min_freq", freq(c, 0.9))
        RootShell.run(sb.toString()) ?: return
        try {
            Thread.sleep(3500)
        } catch (e: InterruptedException) {
            return
        }
        aplicar(ctx, Prefs.aplicado(ctx))
    }

    // ---- jogo em primeiro plano --------------------------------------------

    private val FOCO = Regex("""(?:u\d+\s+|ACTIVITY\s+)([A-Za-z0-9_.]+)/""")

    /** Pacote do app em primeiro plano (null se não deu para descobrir). Tenta 4 fontes. */
    fun primeiroPlano(): String? {
        val saida = RootShell.run(sh("""
o=§(dumpsys activity activities 2>/dev/null | grep -m1 'topResumedActivity')
[ -z "§o" ] && o=§(dumpsys activity top 2>/dev/null | grep -m1 'ACTIVITY ')
[ -z "§o" ] && o=§(dumpsys window 2>/dev/null | grep -m1 'mCurrentFocus=Window')
[ -z "§o" ] && o=§(dumpsys activity activities 2>/dev/null | grep -m1 'ResumedActivity:')
echo "§o"
""")) ?: return null
        for (linha in saida.lines()) {
            val pkg = FOCO.find(linha)?.groupValues?.get(1)
            if (pkg != null) return pkg
        }
        return null
    }

    // ---- diagnóstico -------------------------------------------------------

    fun diagnostico(ctx: Context): String {
        val sb = StringBuilder()
        val versao = try {
            ctx.packageManager.getPackageInfo(ctx.packageName, 0).versionName
        } catch (e: Exception) {
            "?"
        }
        sb.append("RootBoost ").append(versao).append('\n')
        sb.append("Aparelho: ").append(Build.MANUFACTURER).append(' ').append(Build.MODEL).append('\n')
        sb.append("Android ").append(Build.VERSION.RELEASE).append(" (API ").append(Build.VERSION.SDK_INT).append(")\n")
        val saida = RootShell.run(sh("""
echo "Kernel: §(uname -r)"
echo "su: §(su -v 2>/dev/null)"
echo "SELinux: §(getenforce 2>/dev/null)"
echo "[1] §(dumpsys activity activities 2>/dev/null | grep -m1 'topResumedActivity')"
echo "[2] §(dumpsys activity top 2>/dev/null | grep -m1 'ACTIVITY ')"
echo "[3] §(dumpsys window 2>/dev/null | grep -m1 'mCurrentFocus=Window')"
echo "[4] §(dumpsys activity activities 2>/dev/null | grep -m1 'ResumedActivity:')"
"""))
        if (saida == null) {
            sb.append("Root: indisponível\n")
            return sb.toString()
        }
        sb.append(saida).append('\n')
        sb.append("Detectado agora: ").append(primeiroPlano() ?: "nada").append('\n')
        val v = varrer()
        if (v != null) {
            for (c in v.cpus) {
                sb.append("CPU ").append(c.path.substringAfterLast('/')).append(": ").append(c.gov).append(' ')
                    .append(c.min / 1000L).append('-').append(c.max / 1000L).append(" MHz (de ")
                    .append(c.infoMin / 1000L).append('-').append(c.infoMax / 1000L).append(") govs=")
                    .append(c.govs.joinToString(",")).append('\n')
            }
            val g = v.gpu
            if (g != null) {
                sb.append("GPU ").append(g.path.substringAfterLast('/')).append(": ").append(g.gov).append(' ')
                    .append(g.min / 1000000L).append('-').append(g.max / 1000000L).append(" MHz govs=")
                    .append(g.govs.joinToString(",")).append('\n')
            } else {
                sb.append("GPU: não encontrada\n")
            }
        }
        val busy = RootShell.run(sh("echo \"§(cat /sys/class/kgsl/kgsl-3d0/gpu_busy_percentage 2>/dev/null) | §(cat /sys/class/kgsl/kgsl-3d0/gpubusy 2>/dev/null)\""))
        sb.append("GPU busy: ").append(busy ?: "?").append('\n')
        sb.append(Fps.diagnostico(primeiroPlano()))
        sb.append("Jogos: ").append(Prefs.jogos(ctx).joinToString(", ")).append('\n')
        return sb.toString()
    }
}
