package br.com.rootboost

import android.content.Context
import android.os.SystemClock
import java.util.Locale
import kotlin.math.abs

/**
 * Aplica perfis de desempenho lendo e escrevendo no sysfs (CPU cpufreq e GPU devfreq/kgsl).
 * - Só mexe no que o aparelho expõe.
 * - Guarda os valores originais (por boot) e consegue restaurá-los.
 * - Não toca em proteção térmica.
 */
object Tuner {

    class Perfil(val id: String, val nome: String, val desc: String)

    val perfis = listOf(
        Perfil("eco", "Economia", "Limita o teto da CPU para gastar menos bateria."),
        Perfil("equilibrado", "Equilibrado", "Volta aos valores originais do aparelho."),
        Perfil("performance", "Performance", "Sobe a frequência mínima; o teto fica livre."),
        Perfil("gaming", "Gaming", "Resposta máxima. Esquenta mais e gasta mais bateria.")
    )

    private class Cpu(
        val path: String, val gov: String,
        val infoMin: Long, val infoMax: Long,
        val min: Long, val max: Long,
        val govs: List<String>, val freqs: List<Long>
    )

    private class Gpu(
        val path: String, val gov: String,
        val min: Long, val max: Long,
        val govs: List<String>, val freqs: List<Long>
    )

    private class Varredura(val cpus: List<Cpu>, val gpu: Gpu?)

    // § vira $ (evita conflito com templates de string do Kotlin)
    private fun sh(s: String) = s.replace('§', '$')

    private val SCAN = sh("""
for d in /sys/devices/system/cpu/cpufreq/policy* /sys/devices/system/cpu/cpu[0-9]*/cpufreq; do
  [ -f "§d/scaling_governor" ] || continue
  r=§(readlink -f "§d")
  echo "CPU|§r|§(cat §d/scaling_governor)|§(cat §d/cpuinfo_min_freq)|§(cat §d/cpuinfo_max_freq)|§(cat §d/scaling_min_freq)|§(cat §d/scaling_max_freq)|§(cat §d/scaling_available_governors)|§(cat §d/scaling_available_frequencies 2>/dev/null)"
done
for d in /sys/class/kgsl/kgsl-3d0/devfreq /sys/class/devfreq/*kgsl* /sys/class/devfreq/*gpu* /sys/class/devfreq/*mali*; do
  [ -f "§d/governor" ] || continue
  r=§(readlink -f "§d")
  echo "GPU|§r|§(cat §d/governor)|§(cat §d/min_freq)|§(cat §d/max_freq)|§(cat §d/available_governors 2>/dev/null)|§(cat §d/available_frequencies 2>/dev/null)"
  break
done
""")

    private fun nums(s: String): List<Long> =
        s.trim().split(Regex("\\s+")).mapNotNull { it.toLongOrNull() }

    private fun palavras(s: String): List<String> =
        s.trim().split(Regex("\\s+")).filter { it.isNotEmpty() }

    private fun varrer(): Varredura? {
        val saida = RootShell.run(SCAN) ?: return null
        val cpus = ArrayList<Cpu>()
        var gpu: Gpu? = null
        for (linha in saida.lines()) {
            val p = linha.split("|")
            if (p[0] == "CPU" && p.size >= 9) {
                cpus.add(
                    Cpu(
                        p[1].trim(), p[2].trim(),
                        p[3].trim().toLongOrNull() ?: 0L, p[4].trim().toLongOrNull() ?: 0L,
                        p[5].trim().toLongOrNull() ?: 0L, p[6].trim().toLongOrNull() ?: 0L,
                        palavras(p[7]), nums(p[8])
                    )
                )
            } else if (p[0] == "GPU" && p.size >= 7) {
                gpu = Gpu(
                    p[1].trim(), p[2].trim(),
                    p[3].trim().toLongOrNull() ?: 0L, p[4].trim().toLongOrNull() ?: 0L,
                    palavras(p[5]), nums(p[6])
                )
            }
        }
        val validas = cpus.filter { it.infoMax > 0 }.distinctBy { it.path }
        return Varredura(validas, gpu)
    }

    // ---- valores originais -------------------------------------------------

    /** Guarda os valores originais uma vez por boot (antes de qualquer escrita nossa). */
    private fun garantirOriginais(ctx: Context, v: Varredura) {
        val boot = System.currentTimeMillis() - SystemClock.elapsedRealtime()
        val salvo = Prefs.lng(ctx, "orig_boot", -1L)
        if (abs(boot - salvo) < 60_000L) return
        for (c in v.cpus) Prefs.putStr(ctx, "orig_" + c.path, "${c.gov}|${c.min}|${c.max}")
        val g = v.gpu
        if (g != null) Prefs.putStr(ctx, "orig_" + g.path, "${g.gov}|${g.min}|${g.max}")
        Prefs.putLng(ctx, "orig_boot", boot)
    }

    private fun original(ctx: Context, path: String): List<String>? {
        val s = Prefs.str(ctx, "orig_$path", "")
        return if (s.isEmpty()) null else s.split("|")
    }

    // ---- escrita -----------------------------------------------------------

    private fun esc(sb: StringBuilder, caminho: String, valor: Any) {
        sb.append("chmod 644 ").append(caminho).append(" 2>/dev/null; ")
            .append("{ echo ").append(valor).append(" > ").append(caminho).append("; } 2>/dev/null\n")
    }

    private fun escolher(disp: List<String>, vararg prefs: String): String? =
        prefs.firstOrNull { it in disp }

    private fun freq(c: Cpu, fracao: Double): Long {
        val alvo = (c.infoMax * fracao).toLong()
        val cand = c.freqs.filter { it in c.infoMin..c.infoMax }
        val f = cand.minByOrNull { abs(it - alvo) } ?: alvo
        return f.coerceIn(c.infoMin, c.infoMax)
    }

    private fun cpuLinhas(sb: StringBuilder, c: Cpu, gov: String?, min: Long, max: Long) {
        if (gov != null && gov != c.gov) esc(sb, c.path + "/scaling_governor", gov)
        esc(sb, c.path + "/scaling_min_freq", c.infoMin)   // abre espaço antes de mexer no teto
        esc(sb, c.path + "/scaling_max_freq", max)
        esc(sb, c.path + "/scaling_min_freq", min)
    }

    /** Aplica um perfil e devolve uma mensagem pronta para mostrar ao usuário. */
    fun aplicar(ctx: Context, id: String): String {
        val nome = perfis.firstOrNull { it.id == id }?.nome ?: id
        val antes = varrer() ?: return "Sem acesso root. Conceda no Magisk/KernelSU."
        if (antes.cpus.isEmpty()) return "Este aparelho não expõe controles de CPU em /sys."
        garantirOriginais(ctx, antes)

        val sb = StringBuilder()
        for (c in antes.cpus) {
            val o = original(ctx, c.path)
            when (id) {
                "eco" -> cpuLinhas(sb, c, escolher(c.govs, "schedutil", "interactive", "ondemand"), c.infoMin, freq(c, 0.65))
                "performance" -> cpuLinhas(sb, c, escolher(c.govs, "schedutil", "interactive", "ondemand"), freq(c, 0.40), c.infoMax)
                "gaming" -> cpuLinhas(sb, c, escolher(c.govs, "performance", "schedutil", "interactive"), freq(c, 0.60), c.infoMax)
                else -> {
                    val govOrig = o?.getOrNull(0)?.takeIf { it.isNotEmpty() }
                    val minOrig = (o?.getOrNull(1)?.toLongOrNull() ?: c.infoMin).coerceIn(c.infoMin, c.infoMax)
                    cpuLinhas(sb, c, govOrig, minOrig, c.infoMax)
                }
            }
        }

        val g = antes.gpu
        if (g != null) {
            val o = original(ctx, g.path)
            if (id == "gaming") {
                val topo = g.freqs.maxOrNull() ?: g.max
                val alvo = (topo * 0.6).toLong()
                var minAlvo = g.freqs.minByOrNull { abs(it - alvo) } ?: alvo
                if (g.max > 0 && minAlvo > g.max) minAlvo = g.max
                if ("performance" in g.govs && g.gov != "performance") esc(sb, g.path + "/governor", "performance")
                esc(sb, g.path + "/min_freq", minAlvo)
            } else if (o != null) {
                val govOrig = o.getOrNull(0) ?: ""
                val minOrig = o.getOrNull(1)?.toLongOrNull()
                if (govOrig.isNotEmpty() && govOrig != g.gov) esc(sb, g.path + "/governor", govOrig)
                if (minOrig != null) esc(sb, g.path + "/min_freq", minOrig)
            }
        }

        RootShell.run(sb.toString()) ?: return "Sem acesso root."
        Prefs.setAplicado(ctx, id)

        val depois = varrer()
        val govs = depois?.cpus?.map { it.gov }?.distinct()?.joinToString("/") ?: "?"
        val topoMhz = (depois?.cpus?.maxOfOrNull { it.max } ?: 0L) / 1000L
        return "$nome aplicado • CPU $govs, até $topoMhz MHz"
    }

    // ---- ferramentas -------------------------------------------------------

    fun limparRam(): String {
        val antes = Stats.ramLivreMb()
        RootShell.run("am kill-all 2>/dev/null; sync; { echo 3 > /proc/sys/vm/drop_caches; } 2>/dev/null; sleep 1")
            ?: return "Sem acesso root."
        val depois = Stats.ramLivreMb()
        return "RAM livre: $antes MB → $depois MB"
    }

    fun otimizarArmazenamento(): String {
        val saida = RootShell.run("fstrim -v /data 2>&1; fstrim -v /cache 2>&1") ?: return "Sem acesso root."
        return if (saida.contains("trimmed", ignoreCase = true)) "Armazenamento otimizado."
        else "O fstrim não respondeu: ${saida.take(80)}"
    }

    fun saturacao(valor: Float): String {
        val v = String.format(Locale.US, "%.2f", valor)
        RootShell.run("service call SurfaceFlinger 1022 f $v") ?: return "Sem acesso root."
        return "Saturação $v"
    }

    private val FOCO = Regex("""u\d+\s+([A-Za-z0-9_.]+)/""")

    /** Pacote do app em primeiro plano (null se não deu para descobrir). */
    fun primeiroPlano(): String? {
        // Tenta 3 fontes, da mais confiável para a menos (o formato muda entre versões do Android).
        val saida = RootShell.run(sh("""
o=§(dumpsys activity activities 2>/dev/null | grep -m1 'topResumedActivity')
[ -z "§o" ] && o=§(dumpsys activity activities 2>/dev/null | grep -m1 'ResumedActivity:')
[ -z "§o" ] && o=§(dumpsys window 2>/dev/null | grep -m1 'mCurrentFocus=Window')
echo "§o"
""")) ?: return null
        for (linha in saida.lines()) {
            val pkg = FOCO.find(linha)?.groupValues?.get(1)
            if (pkg != null) return pkg
        }
        return null
    }
}
