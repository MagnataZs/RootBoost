package br.com.rootboost

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Environment
import android.os.StatFs
import android.os.SystemClock
import android.provider.Settings
import java.util.Locale
import kotlin.math.abs

/**
 * Aplica perfis lendo e escrevendo no sysfs (CPU cpufreq e GPU devfreq/kgsl).
 * - Só mexe no que o aparelho expõe.
 * - Guarda os valores originais (por boot) e consegue restaurá-los.
 * - Não toca em proteção térmica.
 */
object Tuner {

    class Perfil(val id: String, val nome: String, val desc: String)

    val perfis = listOf(
        Perfil("eco", "Economia", "Limita o teto da CPU para gastar menos bateria."),
        Perfil("equilibrado", "Equilibrado", "Volta aos valores originais do aparelho."),
        Perfil("performance", "Performance", "Sobe a frequência mínima; o teto fica livre."),
        Perfil("gaming", "Gaming", "Resposta máxima. Esquenta mais e gasta mais bateria.")
    )

    class InfoCpu(val govs: List<String>, val gov: String, val minMhz: Int, val maxMhz: Int)

    private class Cpu(
        val path: String, val gov: String,
        val infoMin: Long, val infoMax: Long,
        val min: Long, val max: Long,
        val govs: List<String>, val freqs: List<Long>
    )

    private class Gpu(
        val path: String, val gov: String,
        val min: Long, val max: Long,
        val govs: List<String>, val freqs: List<Long>
    )

    private class Varredura(val cpus: List<Cpu>, val gpu: Gpu?)

    private val SCAN = sh("""
for d in /sys/devices/system/cpu/cpufreq/policy* /sys/devices/system/cpu/cpu[0-9]*/cpufreq; do
  [ -f "§d/scaling_governor" ] || continue
  r=§(readlink -f "§d")
  echo "CPU|§r|§(cat §d/scaling_governor)|§(cat §d/cpuinfo_min_freq)|§(cat §d/cpuinfo_max_freq)|§(cat §d/scaling_min_freq)|§(cat §d/scaling_max_freq)|§(cat §d/scaling_available_governors)|§(cat §d/scaling_available_frequencies 2>/dev/null)"
done
for d in /sys/class/kgsl/kgsl-3d0/devfreq /sys/class/devfreq/*kgsl* /sys/class/devfreq/*gpu* /sys/class/devfreq/*mali*; do
  [ -f "§d/governor" ] || continue
  r=§(readlink -f "§d")
  echo "GPU|§r|§(cat §d/governor)|§(cat §d/min_freq)|§(cat §d/max_freq)|§(cat §d/available_governors 2>/dev/null)|§(cat §d/available_frequencies 2>/dev/null)"
  break
done
""")

    private fun nums(s: String): List<Long> =
        s.trim().split(Regex("\\s+")).mapNotNull { it.toLongOrNull() }

    private fun palavras(s: String): List<String> =
        s.trim().split(Regex("\\s+")).filter { it.isNotEmpty() }

    private fun varrer(): Varredura? {
        val saida = RootShell.run(SCAN) ?: return null
        val cpus = ArrayList<Cpu>()
        var gpu: Gpu? = null
        for (linha in saida.lines()) {
            val p = linha.split("|")
            if (p[0] == "CPU" && p.size >= 9) {
                cpus.add(
                    Cpu(
                        p[1].trim(), p[2].trim(),
                        p[3].trim().toLongOrNull() ?: 0L, p[4].trim().toLongOrNull() ?: 0L,
                        p[5].trim().toLongOrNull() ?: 0L, p[6].trim().toLongOrNull() ?: 0L,
                        palavras(p[7]), nums(p[8])
                    )
                )
            } else if (p[0] == "GPU" && p.size >= 7) {
                gpu = Gpu(
                    p[1].trim(), p[2].trim(),
                    p[3].trim().toLongOrNull() ?: 0L, p[4].trim().toLongOrNull() ?: 0L,
                    palavras(p[5]), nums(p[6])
                )
            }
        }
        val validas = cpus.filter { it.infoMax > 0 }.distinctBy { it.path }
        return Varredura(validas, gpu)
    }

    fun infoCpu(): InfoCpu? {
        val v = varrer() ?: return null
        if (v.cpus.isEmpty()) return null
        val comuns = v.cpus.map { it.govs.toSet() }.reduce { a, b -> a intersect b }.toList()
        val grande = v.cpus.maxByOrNull { it.infoMax } ?: return null
        return InfoCpu(
            comuns, grande.gov,
            (v.cpus.minOf { it.infoMin } / 1000L).toInt(),
            (v.cpus.maxOf { it.infoMax } / 1000L).toInt()
        )
    }

    // ---- valores originais -------------------------------------------------

    /** Guarda os valores originais uma vez por boot (antes de qualquer escrita nossa). */
    private fun garantirOriginais(ctx: Context, v: Varredura) {
        val boot = System.currentTimeMillis() - SystemClock.elapsedRealtime()
        val salvo = Prefs.lng(ctx, "orig_boot", -1L)
        if (abs(boot - salvo) < 60_000L) return
        for (c in v.cpus) Prefs.putStr(ctx, "orig_" + c.path, "${c.gov}|${c.min}|${c.max}")
        val g = v.gpu
        if (g != null) Prefs.putStr(ctx, "orig_" + g.path, "${g.gov}|${g.min}|${g.max}")
        Prefs.putLng(ctx, "orig_boot", boot)
    }

    private fun original(ctx: Context, path: String): List<String>? {
        val s = Prefs.str(ctx, "orig_$path", "")
        return if (s.isEmpty()) null else s.split("|")
    }

    // ---- escrita -----------------------------------------------------------

    private fun esc(sb: StringBuilder, caminho: String, valor: Any) {
        sb.append("chmod 644 ").append(caminho).append(" 2>/dev/null; ")
            .append("{ echo ").append(valor).append(" > ").append(caminho).append("; } 2>/dev/null\n")
    }

    private fun escolher(disp: List<String>, vararg prefs: String): String? =
        prefs.firstOrNull { it in disp }

    private fun freq(c: Cpu, fracao: Double): Long {
        val alvo = (c.infoMax * fracao).toLong()
        val cand = c.freqs.filter { it in c.infoMin..c.infoMax }
        val f = cand.minByOrNull { abs(it - alvo) } ?: alvo
        return f.coerceIn(c.infoMin, c.infoMax)
    }

    private fun cpuLinhas(sb: StringBuilder, c: Cpu, gov: String?, min: Long, max: Long) {
        if (gov != null && gov != c.gov) esc(sb, c.path + "/scaling_governor", gov)
        esc(sb, c.path + "/scaling_min_freq", c.infoMin)   // abre espaço antes de mexer no teto
        esc(sb, c.path + "/scaling_max_freq", max)
        esc(sb, c.path + "/scaling_min_freq", min)
    }

    private fun resumo(): String {
        val depois = varrer()
        val govs = depois?.cpus?.map { it.gov }?.distinct()?.joinToString("/") ?: "?"
        val topoMhz = (depois?.cpus?.maxOfOrNull { it.max } ?: 0L) / 1000L
        return "CPU $govs, até $topoMhz MHz"
    }

    /** Aplica um perfil e devolve uma mensagem pronta para mostrar ao usuário. */
    fun aplicar(ctx: Context, id: String): String {
        val nome = perfis.firstOrNull { it.id == id }?.nome ?: id
        val antes = varrer() ?: return "Sem acesso root. Conceda no Magisk/KernelSU."
        if (antes.cpus.isEmpty()) return "Este aparelho não expõe controles de CPU em /sys."
        garantirOriginais(ctx, antes)

        val sb = StringBuilder()
        for (c in antes.cpus) {
            val o = original(ctx, c.path)
            when (id) {
                "eco" -> cpuLinhas(sb, c, escolher(c.govs, "schedutil", "interactive", "ondemand"), c.infoMin, freq(c, 0.65))
                "performance" -> cpuLinhas(sb, c, escolher(c.govs, "schedutil", "interactive", "ondemand"), freq(c, 0.40), c.infoMax)
                "gaming" -> cpuLinhas(sb, c, escolher(c.govs, "performance", "schedutil", "interactive"), freq(c, 0.60), c.infoMax)
                else -> {
                    val govOrig = o?.getOrNull(0)?.takeIf { it.isNotEmpty() }
                    val minOrig = (o?.getOrNull(1)?.toLongOrNull() ?: c.infoMin).coerceIn(c.infoMin, c.infoMax)
                    cpuLinhas(sb, c, govOrig, minOrig, c.infoMax)
                }
            }
        }

        val g = antes.gpu
        if (g != null) {
            val o = original(ctx, g.path)
            if (id == "gaming") {
                val topo = g.freqs.maxOrNull() ?: g.max
                val alvo = (topo * 0.6).toLong()
                var minAlvo = g.freqs.minByOrNull { abs(it - alvo) } ?: alvo
                if (g.max > 0 && minAlvo > g.max) minAlvo = g.max
                if ("performance" in g.govs && g.gov != "performance") esc(sb, g.path + "/governor", "performance")
                esc(sb, g.path + "/min_freq", minAlvo)
            } else if (o != null) {
                val govOrig = o.getOrNull(0) ?: ""
                val minOrig = o.getOrNull(1)?.toLongOrNull()
                val maxOrig = o.getOrNull(2)?.toLongOrNull()
                if (govOrig.isNotEmpty() && govOrig != g.gov) esc(sb, g.path + "/governor", govOrig)
                val menor = g.freqs.minOrNull()
                if (menor != null) esc(sb, g.path + "/min_freq", menor)   // abre espaço antes do teto
                if (maxOrig != null) esc(sb, g.path + "/max_freq", maxOrig)
                if (minOrig != null) esc(sb, g.path + "/min_freq", minOrig)
            }
        }

        RootShell.run(sb.toString()) ?: return "Sem acesso root."
        Prefs.setAplicado(ctx, id)
        if (Prefs.bool(ctx, "gpu_manual", false)) gpuManualSalvo(ctx)
        return "$nome aplicado • " + resumo()
    }

    // ---- GPU Adreno --------------------------------------------------------

    class InfoGpu(
        val modelo: String, val gov: String, val govs: List<String>,
        val freqsHz: List<Long>, val minHz: Long, val maxHz: Long,
        val boost: Int,      // -1 se o kernel não expõe o Adreno Boost
        val idleMs: Int      // -1 se não expõe
    )

    fun infoGpu(): InfoGpu? {
        val v = varrer() ?: return null
        val g = v.gpu ?: return null
        val extra = RootShell.run(sh("""
echo "MODEL|§(cat /sys/class/kgsl/kgsl-3d0/gpu_model 2>/dev/null)"
echo "BOOST|§(cat /sys/class/kgsl/kgsl-3d0/devfreq/adrenoboost 2>/dev/null)"
echo "IDLE|§(cat /sys/class/kgsl/kgsl-3d0/idle_timer 2>/dev/null)"
""")) ?: ""
        var modelo = "GPU"
        var boost = -1
        var idle = -1
        for (l in extra.lines()) {
            val p = l.split("|")
            if (p.size < 2) continue
            when (p[0]) {
                "MODEL" -> if (p[1].isNotBlank()) modelo = p[1].trim()
                "BOOST" -> boost = p[1].trim().toIntOrNull() ?: -1
                "IDLE" -> idle = p[1].trim().toIntOrNull() ?: -1
            }
        }
        val freqs = g.freqs.sorted().ifEmpty { listOf(g.min, g.max).filter { it > 0L }.distinct() }
        return InfoGpu(modelo, g.gov, g.govs, freqs, g.min, g.max, boost, idle)
    }

    /** Governor e limites de frequência da GPU (valores em Hz, como o kernel expõe). */
    fun gpuManual(ctx: Context, gov: String?, minHz: Long, maxHz: Long): String {
        val v = varrer() ?: return "Sem acesso root."
        val g = v.gpu ?: return "Este aparelho não expõe controles da GPU."
        garantirOriginais(ctx, v)
        val menor = g.freqs.minOrNull() ?: minHz
        val sb = StringBuilder()
        if (gov != null && gov in g.govs && gov != g.gov) esc(sb, g.path + "/governor", gov)
        esc(sb, g.path + "/min_freq", menor)      // abre espaço antes de mexer no teto
        esc(sb, g.path + "/max_freq", maxOf(maxHz, minHz))
        esc(sb, g.path + "/min_freq", minOf(minHz, maxHz))
        RootShell.run(sb.toString()) ?: return "Sem acesso root."
        Prefs.putBool(ctx, "gpu_manual", true)
        Prefs.putLng(ctx, "gpu_min_hz", minHz)
        Prefs.putLng(ctx, "gpu_max_hz", maxHz)
        Prefs.putStr(ctx, "gpu_gov", gov ?: g.gov)
        return "GPU: " + (minOf(minHz, maxHz) / 1_000_000L) + "–" + (maxOf(maxHz, minHz) / 1_000_000L) + " MHz"
    }

    private fun gpuManualSalvo(ctx: Context) {
        val mn = Prefs.lng(ctx, "gpu_min_hz", 0L)
        val mx = Prefs.lng(ctx, "gpu_max_hz", 0L)
        if (mn <= 0L || mx <= 0L) return
        gpuManual(ctx, Prefs.str(ctx, "gpu_gov", "").ifEmpty { null }, mn, mx)
    }

    /** Devolve a GPU ao que o aparelho tinha antes de qualquer ajuste manual. */
    fun gpuRestaurar(ctx: Context): String {
        Prefs.putBool(ctx, "gpu_manual", false)
        Prefs.putLng(ctx, "gpu_min_hz", 0L)
        Prefs.putLng(ctx, "gpu_max_hz", 0L)
        return aplicar(ctx, Prefs.base(ctx))
    }

    private const val ADRENO = "/sys/class/kgsl/kgsl-3d0"

    /** Adreno Boost (0 a 3): faz o governor da GPU subir o clock mais cedo. Só existe em alguns kernels. */
    fun adrenoBoost(nivel: Int): String {
        val n = nivel.coerceIn(0, 3)
        val s = RootShell.run(
            "[ -f $ADRENO/devfreq/adrenoboost ] && { echo $n > $ADRENO/devfreq/adrenoboost; } 2>/dev/null; " +
                "cat $ADRENO/devfreq/adrenoboost 2>/dev/null"
        ) ?: return "Sem acesso root."
        return if (s.trim().toIntOrNull() == n) "Adreno Boost $n" else "Este kernel não expõe o Adreno Boost."
    }

    // ---- chamadas e janela flutuante ---------------------------------------

    private val PKG_OK = Regex("[A-Za-z0-9_.]+")
    private val COMPONENTE = Regex("[A-Za-z0-9_.$/]+")

    /**
     * Mantém os apps de chamada vivos enquanto o jogo roda: baixa o oom_score_adj dos processos deles
     * (o sistema mata por último) e desliga o "phantom process killer" do Android 12+.
     * Não mexe no jogo nem em nenhum arquivo dele.
     */
    fun protegerChamadas(ctx: Context) {
        val sb = StringBuilder()
        if (!Prefs.bool(ctx, "fantasma_ok", false)) {
            sb.append("device_config put activity_manager max_phantom_processes 2147483647 2>/dev/null\n")
            sb.append("settings put global settings_enable_monitor_phantom_procs false 2>/dev/null\n")
        }
        for (p in Prefs.chamadasAtivas(ctx)) {
            if (!PKG_OK.matches(p)) continue
            sb.append("for pid in §(pidof ").append(p).append(" 2>/dev/null); do ")
                .append("{ echo -250 > /proc/§pid/oom_score_adj; } 2>/dev/null; done\n")
        }
        RootShell.run(sh(sb.toString())) ?: return
        Prefs.putBool(ctx, "fantasma_ok", true)
    }

    fun soltarChamadas(ctx: Context) {
        RootShell.run(
            "device_config delete activity_manager max_phantom_processes 2>/dev/null\n" +
                "settings delete global settings_enable_monitor_phantom_procs 2>/dev/null"
        )
        Prefs.putBool(ctx, "fantasma_ok", false)
    }

    /**
     * Abre um app em janela flutuante por cima do jogo (precisa de ROM com janelas livres).
     * Depois de abrir, redimensiona a janela para um tamanho que o app consiga se ajustar
     * (a janela padrão da ROM costuma ser pequena demais e o app fica espremido).
     */
    fun abrirFlutuante(ctx: Context, pkg: String): String {
        if (!PKG_OK.matches(pkg)) return "App inválido."
        val comp = ctx.packageManager.getLaunchIntentForPackage(pkg)?.component?.flattenToShortString()
            ?: return "Não achei como abrir esse app."
        if (!COMPONENTE.matches(comp)) return "Nome de atividade inesperado."
        val saida = RootShell.run(
            "settings put global enable_freeform_support 1 2>/dev/null\n" +
                "settings put global force_resizable_activities 1 2>/dev/null\n" +
                "am start -n " + comp + " --windowingMode 5 2>&1"
        ) ?: return "Sem acesso root."
        val falhou = saida.contains("Error", true) || saida.contains("Exception", true) ||
            saida.contains("Unknown option", true)
        if (falhou) {
            RootShell.run("am start -n " + comp + " 2>&1") ?: return "Sem acesso root."
            return "Sua ROM não abriu em janela flutuante. Abri em tela cheia."
        }

        val dm = ctx.resources.displayMetrics
        val larg = dm.widthPixels
        val alt = dm.heightPixels
        val tam = Prefs.janelaTam(ctx).coerceIn(0, 2)
        val paisagem = larg > alt
        val fw = if (paisagem) floatArrayOf(0.30f, 0.38f, 0.46f)[tam] else floatArrayOf(0.80f, 0.90f, 0.98f)[tam]
        val fh = if (paisagem) floatArrayOf(0.78f, 0.88f, 0.96f)[tam] else floatArrayOf(0.40f, 0.52f, 0.64f)[tam]
        val w = (larg * fw).toInt()
        val h = (alt * fh).toInt()
        val esq = (larg - w) / 2
        val topo = (alt - h) / 2
        val dir = esq + w
        val base = topo + h
        val script = sh(
            """
tid=""
i=0
while [ §i -lt 8 ] && [ -z "§tid" ]; do
  sleep 0.4
  tid=§(dumpsys activity activities 2>/dev/null | grep -E "Task\{[^}]*[:=]@PKG[ }]" | head -n 1 | grep -oE "#[0-9]+" | head -n 1 | tr -d '#')
  i=§((i+1))
done
if [ -n "§tid" ]; then
  o=§(am task resize §tid @A 2>&1)
  case "§o" in
    *xception*|*rror*) am task resize §tid @B 2>&1 ;;
  esac
  echo "TID|§tid"
fi
"""
        ).replace("@PKG", pkg)
            .replace("@A", "$esq $topo $dir $base")
            .replace("@B", "$esq,$topo,$dir,$base")
        val r = RootShell.run(script) ?: return "Aberto em janela flutuante."
        return if (r.contains("TID|")) "Aberto em janela flutuante (tamanho ajustado)." else "Aberto em janela flutuante."
    }

    /** Ajuste manual: governor (opcional) e limites de frequência em % do máximo de cada cluster. */
    fun cpuManual(ctx: Context, gov: String?, minPct: Int, maxPct: Int): String {
        val antes = varrer() ?: return "Sem acesso root."
        if (antes.cpus.isEmpty()) return "Este aparelho não expõe controles de CPU em /sys."
        garantirOriginais(ctx, antes)
        val sb = StringBuilder()
        for (c in antes.cpus) {
            val alvoGov = if (gov != null && gov in c.govs) gov else null
            val mx = freq(c, maxPct / 100.0)
            var mn = freq(c, minPct / 100.0)
            if (mn > mx) mn = mx
            cpuLinhas(sb, c, alvoGov, mn, mx)
        }
        RootShell.run(sb.toString()) ?: return "Sem acesso root."
        Prefs.setAplicado(ctx, "custom")
        return "Ajuste manual aplicado • " + resumo()
    }

    // ---- ferramentas -------------------------------------------------------

    /**
     * Libera RAM sem derrubar chamadas: usa `am kill` só nos apps que o sistema considera seguros de fechar
     * e pula os de chamada e os protegidos. [cache] = true também descarta o cache de arquivos
     * (só quando o usuário pede; ao abrir um jogo isso faria o carregamento ficar mais lento).
     */
    fun limparRam(ctx: Context? = null, cache: Boolean = false): String {
        val antes = Stats.ramLivreMb()
        val prot = HashSet<String>(if (ctx != null) Prefs.chamadasAtivas(ctx) else Prefs.CHAMADAS)
        if (ctx != null) prot.add(ctx.packageName)
        val lista = RootShell.run("pm list packages -3 2>/dev/null") ?: return "Sem acesso root."
        val sb = StringBuilder()
        for (l in lista.lines()) {
            val p = l.trim().removePrefix("package:")
            if (p.isNotEmpty() && NOME_PKG.matches(p) && p !in prot) sb.append("am kill ").append(p).append(" 2>/dev/null\n")
        }
        sb.append("sync\n")
        if (cache) sb.append("{ echo 3 > /proc/sys/vm/drop_caches; } 2>/dev/null\n")
        sb.append("{ echo 1 > /proc/sys/vm/compact_memory; } 2>/dev/null\nsleep 1")
        RootShell.run(sb.toString()) ?: return "Sem acesso root."
        val depois = Stats.ramLivreMb()
        return "RAM livre: $antes MB → $depois MB"
    }

    private val NOME_PKG = Regex("[A-Za-z0-9_.]+")

    /** Encerra apps de terceiros, menos os protegidos, o launcher, o teclado e o jogo atual. */
    fun limpezaProfunda(ctx: Context, jogo: String?): String {
        val lista = RootShell.run("pm list packages -3 2>/dev/null") ?: return "Sem acesso root."
        val protegidos = HashSet<String>(Prefs.chamadasAtivas(ctx))
        protegidos.add(ctx.packageName)
        if (jogo != null) protegidos.add(jogo)
        val home = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME)
        ctx.packageManager.resolveActivity(home, PackageManager.MATCH_DEFAULT_ONLY)
            ?.activityInfo?.packageName?.let { protegidos.add(it) }
        Settings.Secure.getString(ctx.contentResolver, "default_input_method")
            ?.substringBefore('/')?.let { protegidos.add(it) }
        val alvos = lista.lines()
            .map { it.trim().removePrefix("package:") }
            .filter { NOME_PKG.matches(it) && it !in protegidos }
        if (alvos.isEmpty()) return "Nada para encerrar."
        val sb = StringBuilder()
        for (p in alvos) sb.append("am force-stop ").append(p).append(" 2>/dev/null\n")
        RootShell.run(sb.toString()) ?: return "Sem acesso root."
        return "${alvos.size} apps encerrados."
    }

    fun otimizarArmazenamento(): String {
        val saida = RootShell.run("fstrim -v /data 2>&1; fstrim -v /cache 2>&1") ?: return "Sem acesso root."
        return if (saida.contains("trimmed", ignoreCase = true)) "Armazenamento otimizado."
        else "O fstrim não respondeu: ${saida.take(80)}"
    }

    fun saturacao(valor: Float): String {
        val v = String.format(Locale.US, "%.2f", valor)
        RootShell.run("service call SurfaceFlinger 1022 f $v") ?: return "Sem acesso root."
        return "Saturação $v"
    }

    /** hz = 0 volta ao automático. */
    fun taxaTela(hz: Int): String {
        val cmd = if (hz == 0) "settings delete system min_refresh_rate; settings delete system peak_refresh_rate"
        else "settings put system min_refresh_rate $hz.0; settings put system peak_refresh_rate $hz.0"
        RootShell.run(cmd) ?: return "Sem acesso root."
        return if (hz == 0) "Taxa de atualização automática." else "Taxa de atualização em $hz Hz."
    }

    // ---- resolução, gráficos e sistema -----------------------------------------

    /** valor <= 0 volta à densidade original. */
    fun dpi(valor: Int): String {
        val cmd = if (valor <= 0) "wm density reset" else "wm density $valor"
        RootShell.run(cmd) ?: return "Sem acesso root."
        return if (valor <= 0) "Resolução restaurada." else "Densidade em $valor dpi."
    }

    /** 0 = padrão do sistema, 1 = Skia GL, 2 = Skia Vulkan (vale para apps abertos depois). */
    fun renderizador(modo: Int): String {
        val v = when (modo) {
            1 -> "skiagl"
            2 -> "skiavk"
            else -> ""
        }
        RootShell.run("setprop debug.hwui.renderer \"$v\"") ?: return "Sem acesso root."
        return when (modo) {
            1 -> "Renderizador Skia GL. Abra os apps de novo."
            2 -> "Renderizador Skia Vulkan. Abra os apps de novo."
            else -> "Renderizador padrão do sistema."
        }
    }

    /** 0 = padrão, 1 = Game Driver, 2 = ANGLE (vale para apps abertos depois). */
    fun driver(modo: Int): String {
        val cmd = when (modo) {
            1 -> "settings put global game_driver_all_apps 1; settings put global updatable_driver_all_apps 1; settings delete global angle_gl_driver_all_angle"
            2 -> "settings delete global game_driver_all_apps; settings delete global updatable_driver_all_apps; settings put global angle_gl_driver_all_angle 1"
            else -> "settings delete global game_driver_all_apps; settings delete global updatable_driver_all_apps; settings delete global angle_gl_driver_all_angle"
        }
        RootShell.run(cmd) ?: return "Sem acesso root."
        return when (modo) {
            1 -> "Game Driver ligado. Abra o jogo de novo."
            2 -> "ANGLE ligado. Abra o jogo de novo."
            else -> "Driver gráfico padrão."
        }
    }

    /**
     * Modo jogo do Android 12+ para um jogo: 0 padrão, 1 desempenho, 2 bateria; escalaPct 100 = sem reduzir;
     * fps 0 = padrão. Fica salvo no sistema e vale na próxima vez que o jogo abrir.
     */
    fun modoJogo(pkg: String, modo: Int, escalaPct: Int, fps: Int): String {
        if (!PKG_OK.matches(pkg)) return "App inválido."
        val mexe = escalaPct < 100 || fps > 0
        val efetivo = if (modo == 0 && mexe) 1 else modo
        val nome = when (efetivo) {
            1 -> "performance"
            2 -> "battery"
            else -> "standard"
        }
        val sb = StringBuilder("cmd game set --mode ").append(nome)
        if (escalaPct in 40..99) sb.append(" --downscale ").append(String.format(Locale.US, "%.2f", escalaPct / 100f))
        if (fps > 0) sb.append(" --fps ").append(fps)
        sb.append(' ').append(pkg).append(" 2>&1\ncmd game mode ").append(nome).append(' ').append(pkg).append(" 2>&1")
        val saida = RootShell.run(sb.toString()) ?: return "Sem acesso root."
        if (saida.contains("Can't find service", true) || saida.contains("not found", true))
            return "Este Android não tem o modo jogo (precisa do Android 12 ou mais novo)."
        if (saida.contains("Exception", true) || saida.contains("Error", true) || saida.contains("Unknown", true))
            return "A sua ROM recusou o ajuste: " + saida.lines().firstOrNull { it.isNotBlank() }.orEmpty().take(60)
        return "Salvo. Vale na próxima vez que abrir o jogo."
    }

    /** Volta o jogo ao comportamento padrão do sistema. */
    fun modoJogoRestaurar(pkg: String): String {
        if (!PKG_OK.matches(pkg)) return "App inválido."
        RootShell.run("cmd game reset " + pkg + " 2>&1\ncmd game mode standard " + pkg + " 2>&1") ?: return "Sem acesso root."
        return "Jogo voltou ao padrão do sistema."
    }

    /** Reescreve as listas de driver por jogo (0 padrão, 1 Game Driver, 2 ANGLE) a partir da escolha de cada jogo. */
    fun aplicarDriversPorJogo(ctx: Context): String {
        val angle = ArrayList<String>()
        val gd = ArrayList<String>()
        for (pkg in Prefs.jogos(ctx)) {
            if (!PKG_OK.matches(pkg) || Prefs.modoSeguro(ctx, pkg)) continue
            when (Prefs.driverJogo(ctx, pkg)) {
                1 -> gd.add(pkg)
                2 -> angle.add(pkg)
            }
        }
        val sb = StringBuilder()
        if (angle.isEmpty()) {
            sb.append("settings delete global angle_gl_driver_selection_pkgs\nsettings delete global angle_gl_driver_selection_values\n")
        } else {
            sb.append("settings put global angle_gl_driver_selection_pkgs ").append(angle.joinToString(",")).append('\n')
            sb.append("settings put global angle_gl_driver_selection_values ").append(angle.joinToString(",") { "angle" }).append('\n')
        }
        if (gd.isEmpty()) {
            sb.append("settings delete global game_driver_opt_in_apps\nsettings delete global updatable_driver_production_opt_in_apps\n")
        } else {
            sb.append("settings put global game_driver_opt_in_apps ").append(gd.joinToString(",")).append('\n')
            sb.append("settings put global updatable_driver_production_opt_in_apps ").append(gd.joinToString(",")).append('\n')
        }
        RootShell.run(sb.toString()) ?: return "Sem acesso root."
        return "Driver gráfico por jogo salvo. Abra o jogo de novo."
    }

    fun limparCache(): String {
        val pasta = Environment.getDataDirectory().path
        val antes = StatFs(pasta).availableBytes
        RootShell.run("pm trim-caches 999G 2>/dev/null; sync") ?: return "Sem acesso root."
        val depois = StatFs(pasta).availableBytes
        val mb = (depois - antes) / (1024L * 1024L)
        return if (mb > 0L) "Cache limpo: $mb MB liberados." else "Cache limpo."
    }

    /** Executa um comando como root (com limite de 10 s para não travar o shell). */
    fun terminal(cmd: String): String {
        val seguro = "'" + cmd.replace("'", "'\\''") + "'"
        val saida = RootShell.run("timeout 10 sh -c $seguro 2>&1") ?: return "Sem acesso root."
        return if (saida.isEmpty()) "(sem saída)" else saida.take(6000)
    }

    /** Anti-queda de FPS: sobe a frequência mínima por alguns segundos e depois volta ao perfil. */
    fun impulso(ctx: Context) {
        val t = Stats.ler()?.temp
        if (t != null && t >= 46f) return     // não força o aparelho quente
        val v = varrer() ?: return
        val sb = StringBuilder()
        for (c in v.cpus) esc(sb, c.path + "/scaling_min_freq", freq(c, 0.9))
        val g = v.gpu
        if (g != null && g.freqs.isNotEmpty() && g.max > 0L) {
            val topo = g.freqs.maxOrNull() ?: g.max
            val alvo = g.freqs.minByOrNull { abs(it - (topo * 0.85).toLong()) } ?: topo
            esc(sb, g.path + "/min_freq", minOf(alvo, g.max))
        }
        RootShell.run(sb.toString()) ?: return
        try {
            Thread.sleep(3500)
        } catch (e: InterruptedException) {
            return
        }
        val atual = Prefs.aplicado(ctx)
        if (atual == "custom") {
            cpuManual(ctx, null, Prefs.lng(ctx, "cpu_min", 0L).toInt(), Prefs.lng(ctx, "cpu_max", 100L).toInt())
        } else {
            aplicar(ctx, atual)
        }
    }

    // ---- jogo em primeiro plano --------------------------------------------

    private val FOCO = Regex("""(?:u\d+\s+|ACTIVITY\s+)([A-Za-z0-9_.]+)/""")

    /** Pacote do app em primeiro plano (null se não deu para descobrir). Tenta 4 fontes. */
    fun primeiroPlano(): String? {
        val saida = RootShell.run(sh("""
o=§(dumpsys activity activities 2>/dev/null | grep -m1 'topResumedActivity')
[ -z "§o" ] && o=§(dumpsys activity top 2>/dev/null | grep -m1 'ACTIVITY ')
[ -z "§o" ] && o=§(dumpsys window 2>/dev/null | grep -m1 'mCurrentFocus=Window')
[ -z "§o" ] && o=§(dumpsys activity activities 2>/dev/null | grep -m1 'ResumedActivity:')
echo "§o"
""")) ?: return null
        for (linha in saida.lines()) {
            val pkg = FOCO.find(linha)?.groupValues?.get(1)
            if (pkg != null) return pkg
        }
        return null
    }

    // ---- diagnóstico -------------------------------------------------------

    fun diagnostico(ctx: Context): String {
        val sb = StringBuilder()
        val versao = try {
            ctx.packageManager.getPackageInfo(ctx.packageName, 0).versionName
        } catch (e: Exception) {
            "?"
        }
        sb.append("RootBoost ").append(versao).append('\n')
        sb.append("Aparelho: ").append(Build.MANUFACTURER).append(' ').append(Build.MODEL).append('\n')
        sb.append("Android ").append(Build.VERSION.RELEASE).append(" (API ").append(Build.VERSION.SDK_INT).append(")\n")
        val saida = RootShell.run(sh("""
echo "Kernel: §(uname -r)"
echo "su: §(su -v 2>/dev/null)"
echo "SELinux: §(getenforce 2>/dev/null)"
echo "[1] §(dumpsys activity activities 2>/dev/null | grep -m1 'topResumedActivity')"
echo "[2] §(dumpsys activity top 2>/dev/null | grep -m1 'ACTIVITY ')"
echo "[3] §(dumpsys window 2>/dev/null | grep -m1 'mCurrentFocus=Window')"
echo "[4] §(dumpsys activity activities 2>/dev/null | grep -m1 'ResumedActivity:')"
"""))
        if (saida == null) {
            sb.append("Root: indisponível\n")
            return sb.toString()
        }
        sb.append(saida).append('\n')
        sb.append("Detectado agora: ").append(primeiroPlano() ?: "nada").append('\n')
        val v = varrer()
        if (v != null) {
            for (c in v.cpus) {
                sb.append("CPU ").append(c.path.substringAfterLast('/')).append(": ").append(c.gov).append(' ')
                    .append(c.min / 1000L).append('-').append(c.max / 1000L).append(" MHz (de ")
                    .append(c.infoMin / 1000L).append('-').append(c.infoMax / 1000L).append(") govs=")
                    .append(c.govs.joinToString(",")).append('\n')
            }
            val g = v.gpu
            if (g != null) {
                sb.append("GPU ").append(g.path.substringAfterLast('/')).append(": ").append(g.gov).append(' ')
                    .append(g.min / 1000000L).append('-').append(g.max / 1000000L).append(" MHz govs=")
                    .append(g.govs.joinToString(",")).append('\n')
            } else {
                sb.append("GPU: não encontrada\n")
            }
        }
        val busy = RootShell.run(sh("echo \"§(cat /sys/class/kgsl/kgsl-3d0/gpu_busy_percentage 2>/dev/null) | §(cat /sys/class/kgsl/kgsl-3d0/gpubusy 2>/dev/null)\""))
        sb.append("GPU busy: ").append(busy ?: "?").append('\n')
        sb.append(Fps.diagnostico(primeiroPlano()))
        sb.append("Jogos: ").append(Prefs.jogos(ctx).joinToString(", ")).append('\n')
        return sb.toString()
    }
}
