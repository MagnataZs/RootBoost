package br.com.rootboost

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder

/** Vigia o app em primeiro plano: abre jogo da lista → Gaming; sai do jogo → volta ao perfil escolhido. */
class GameService : Service() {

    @Volatile private var ativo = false
    private var fio: Thread? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        criarCanal()
        val abrir = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        val notificacao = Notification.Builder(this, CANAL)
            .setSmallIcon(R.drawable.ic_stat)
            .setContentTitle("Game Turbo ativo")
            .setContentText("Vigiando a sua lista de jogos")
            .setOngoing(true)
            .setContentIntent(abrir)
            .build()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(1, notificacao, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(1, notificacao)
        }
        if (!ativo) {
            ativo = true
            fio = Thread { laco() }.also { it.start() }
        }
        return START_STICKY
    }

    private fun laco() {
        var emJogo = false
        var fora = 0
        try {
            while (ativo) {
                val pkg = Tuner.primeiroPlano()
                Prefs.putStr(this, "fg", pkg ?: "?")
                Prefs.putLng(this, "beat", System.currentTimeMillis())
                // A barra de notificações não conta como "saiu do jogo".
                if (pkg != null && pkg != "com.android.systemui") {
                    if (Prefs.jogos(this).contains(pkg)) {
                        fora = 0
                        if (!emJogo) {
                            emJogo = true
                            Tuner.aplicar(this, "gaming")
                            if (Prefs.limparAoJogar(this)) Tuner.limparRam()
                        }
                    } else if (emJogo) {
                        fora++
                        if (fora >= 2) {
                            emJogo = false
                            fora = 0
                            Tuner.aplicar(this, Prefs.base(this))
                        }
                    }
                }
                Thread.sleep(3000)
            }
        } catch (e: InterruptedException) {
            // serviço sendo parado
        } finally {
            if (emJogo) Tuner.aplicar(this, Prefs.base(this))
        }
    }

    private fun criarCanal() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CANAL, "Game Turbo", NotificationManager.IMPORTANCE_LOW))
    }

    override fun onDestroy() {
        ativo = false
        fio?.interrupt()
        super.onDestroy()
    }

    companion object {
        private const val CANAL = "gameturbo"
    }
}
