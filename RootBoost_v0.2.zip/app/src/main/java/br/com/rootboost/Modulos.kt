package br.com.rootboost

import android.content.Context
import android.os.SystemClock
import kotlin.math.abs

/** Cada módulo liga e desliga um ajuste do sistema, guardando o valor original para restaurar. */
object Modulos {

    class Modulo(
        val id: String,
        val nome: String,
        val desc: String,
        val icone: String,
        val info: String,
        val reversivel: Boolean = true,
        /** "adreno" ou "mali" quando o módulo só serve para um tipo de GPU; vazio serve para todos. */
        val gpu: String = ""
    )

    class Res(val ok: Boolean, val msg: String)

    val lista = listOf(
        Modulo(
            "animacoes", "Animações rápidas", "Encurta as animações do sistema durante o jogo.", "raio",
            "Reduz a escala das animações do Android (janelas, transições) para 0,5x enquanto você joga. Ao sair do jogo, os valores originais voltam."
        ),
        Modulo(
            "ram", "Gerenciamento de memória", "Libera e compacta a RAM ao abrir o jogo.", "memoria",
            "Encerra processos em cache, descarrega caches do sistema e compacta a memória. Roda uma vez, quando o jogo abre.", false
        ),
        Modulo(
            "cpuboost", "Prioridade da CPU", "Dá mais prioridade ao app em primeiro plano.", "cpu",
            "Sobe o piso de prioridade do grupo top-app (uclamp ou schedtune, o que o aparelho tiver). Alguns aparelhos não têm esse controle."
        ),
        Modulo(
            "taxa", "Taxa de atualização máxima", "Fixa a maior taxa de quadros da tela.", "atualizar",
            "Descobre a maior taxa que a tela suporta e a fixa durante o jogo. Libera a taxa da tela, não aumenta o FPS do jogo."
        ),
        Modulo(
            "io", "Disco em modo direto", "Troca o escalonador de I/O pelo mais leve.", "modulos",
            "Usa o escalonador de disco mais simples disponível (none, noop ou mq-deadline), o que pode acelerar o carregamento."
        ),
        Modulo(
            "antiqueda", "Anti-queda de FPS", "Se o FPS cai de repente, sobe a CPU por alguns segundos.", "fps",
            "Vigia o FPS do jogo. Quando ele despenca em relação à média recente, sobe a frequência mínima da CPU por 3 segundos e depois volta ao perfil. Não age se o aparelho estiver quente (46 °C ou mais)."
        ),
        Modulo(
            "cor", "Cores e shader no jogo", "Aplica o seu perfil de cor só durante o jogo.", "cor",
            "Aplica o shader escolhido na aba Gráficos (saturação, contraste, brilho e cores) quando o jogo abre e volta ao normal quando fecha."
        ),
        Modulo(
            "toque", "Lightning Touch", "Melhora a resposta da tela ao toque.", "toque",
            "Reduz o tempo do toque longo e liga o modo jogo do touch, nos aparelhos que têm esse recurso."
        ),
        Modulo(
            "dnd", "Não perturbe", "Silencia chamadas e notificações enquanto joga.", "sino",
            "Liga o modo Não perturbe (somente prioridade) durante o jogo e devolve o estado anterior ao sair."
        ),
        Modulo(
            "wifi", "Baixa latência do Wi‑Fi", "Prioriza a latência da conexão Wi‑Fi.", "wifi",
            "Liga o modo de baixa latência do Wi‑Fi do Android, quando a versão do sistema suporta."
        ),
        Modulo(
            "chamadas", "Proteger chamadas", "Mantém Discord, WhatsApp e afins vivos durante o jogo.", "sino",
            "Faz o sistema fechar os apps de chamada por último quando falta memória (oom_score_adj) e desliga o limite de processos em segundo plano do Android 12+. Também faz o Smart App Killer e a limpeza de RAM pularem esses apps. Nada disso toca no jogo."
        ),
        Modulo(
            "gpu", "Adreno Boost", "Faz a GPU Adreno subir o clock mais cedo.", "cpu",
            "Liga o Adreno Boost (nível 2) e aumenta o tempo de espera antes da GPU relaxar (idle timer). Ajuda em jogos que oscilam, como Honor of Kings. Só funciona em chips Qualcomm (Adreno) e se o kernel expõe esses controles. Ao sair do jogo, os valores originais voltam.",
            true, "adreno"
        ),
        Modulo(
            "readahead", "Leitura antecipada do disco", "Carrega texturas e mapas mais rápido.", "modulos",
            "Aumenta o read-ahead do armazenamento para 1024 KB, o que reduz a espera em telas de carregamento. Volta ao valor original ao sair do jogo."
        ),
        Modulo(
            "headsup", "Sem avisos na tela", "Esconde os avisos que caem por cima do jogo.", "sino",
            "Desliga as notificações em pop-up (heads-up) durante o jogo, para nada atravessar a tela no meio da partida. As notificações continuam chegando na barra."
        ),
        Modulo(
            "brilho", "Brilho fixo", "Impede o brilho automático de mudar no meio do jogo.", "tela",
            "Desliga o brilho automático durante o jogo, para a tela não escurecer ou clarear sozinha. O modo anterior volta ao sair."
        ),
        Modulo(
            "profunda", "Smart App Killer", "Encerra apps em segundo plano que não estão em uso.", "limpar",
            "Fecha apps de terceiros abertos em segundo plano, menos os protegidos, o launcher, o teclado e o próprio jogo. Roda uma vez, quando o jogo abre.", false
        ),
        Modulo(
            "mali", "Boost da GPU Mali / MediaTek", "Sobe o clock mínimo da GPU para ela não demorar a acordar.", "cpu",
            "Para chips Mali e MediaTek: liga o modo jogo do driver da GPU (quando o kernel tem) e sobe o clock mínimo da GPU para uma faixa alta, assim ela responde logo quando a cena pesa. Só age nos controles que o seu kernel expõe; se não houver nenhum, o app avisa. Ao sair do jogo, os valores originais voltam.",
            true, "mali"
        ),
        Modulo(
            "sustentado", "Desempenho sustentado", "Segura o desempenho em partidas longas.", "raio",
            "Liga o modo de desempenho fixo do Android (e o modo desempenho do CPU em chips MediaTek, quando existe). Evita que o sistema reduza o desempenho de forma agressiva em sessões longas. O aparelho pode esquentar mais."
        ),
        Modulo(
            "dados", "Dados em segundo plano", "Pausa apps que usam a internet escondidos.", "wifi",
            "Liga a Economia de dados do Android durante o jogo: apps em segundo plano ficam sem rede, sobra banda e há menos picos de ping. Apps com chamada em andamento costumam continuar funcionando; se algum ficar sem rede, desligue. Volta ao normal ao sair."
        ),
        Modulo(
            "scan", "Sem buscas de Wi‑Fi e Bluetooth", "Evita picos de lag causados por buscas de rede.", "wifi",
            "Desliga a busca constante de redes Wi‑Fi e de aparelhos Bluetooth em segundo plano. Essas buscas costumam causar pequenos travamentos de ping. Volta ao normal ao sair."
        ),
        Modulo(
            "poupanca", "Sem economia de bateria", "Desliga a economia que limita o desempenho.", "bateria",
            "Desliga a Economia de bateria e a bateria adaptável durante o jogo, porque as duas reduzem o desempenho para poupar energia. Volta ao normal ao sair."
        )
    )

    private val SEGURO = Regex("[A-Za-z0-9_.,:-]+")
    private val SEGURO_IO = Regex("[A-Za-z0-9_-]+")
    private val CAMINHO = Regex("/sys/block/[A-Za-z0-9_]+/queue")
    private val KNOBS = setOf("/dev/cpuctl/top-app/cpu.uclamp.min", "/dev/stune/top-app/schedtune.boost")
    private val VALOR_KNOB = Regex("[A-Za-z0-9.]+")

    private fun semRoot() = Res(false, "Sem acesso root.")

    private val NO_OK = Regex("/(sys|proc)/[A-Za-z0-9_./:@-]+")
    private val VAL_OK = Regex("[A-Za-z0-9_.-]+")

    private class Escrita(val guardados: List<String>)

    /**
     * Escreve em nós do kernel e confere lendo de volta. Devolve "caminho=valor original" só dos que
     * realmente pegaram (o kernel pode recusar sem avisar). Nulo se não houver root.
     */
    private fun escreverNos(pares: List<Pair<String, String>>): Escrita? {
        val sb = StringBuilder()
        val validos = ArrayList<Pair<String, String>>()
        for ((c, v) in pares) {
            if (!NO_OK.matches(c) || !VAL_OK.matches(v)) continue
            validos.add(Pair(c, v))
            sb.append("echo \"N|").append(c).append("|\$(cat ").append(c).append(" 2>/dev/null)\"\n")
            sb.append("{ echo ").append(v).append(" > ").append(c).append("; } 2>/dev/null\n")
            sb.append("echo \"V|").append(c).append("|\$(cat ").append(c).append(" 2>/dev/null)\"\n")
        }
        if (validos.isEmpty()) return Escrita(emptyList())
        val s = RootShell.run(sb.toString()) ?: return null
        val antes = HashMap<String, String>()
        val depois = HashMap<String, String>()
        for (l in s.lines()) {
            val p = l.split("|", limit = 3)
            if (p.size < 3) continue
            if (p[0] == "N") antes[p[1]] = p[2].trim()
            if (p[0] == "V") depois[p[1]] = p[2].trim()
        }
        val ok = ArrayList<String>()
        for ((c, v) in validos) {
            val agora = depois[c] ?: continue
            val bate = agora == v || agora.split(Regex("\\s+")).contains(v)
            if (!bate) continue
            val o = antes[c].orEmpty()
            ok.add(c + "=" + (if (VAL_OK.matches(o)) o else ""))
        }
        return Escrita(ok)
    }

    /** Comandos para devolver os nós ao valor guardado por [escreverNos]. */
    private fun restaurarNos(itens: List<String>): String {
        val sb = StringBuilder()
        for (par in itens) {
            val i = par.indexOf('=')
            if (i <= 0) continue
            val c = par.substring(0, i)
            val v = par.substring(i + 1)
            if (NO_OK.matches(c) && VAL_OK.matches(v))
                sb.append("{ echo ").append(v).append(" > ").append(c).append("; } 2>/dev/null\n")
        }
        return sb.toString()
    }

    /** O que o aparelho realmente suporta, testado uma vez por boot. */
    private val SONDA = sh("""
t=outro
[ -d /sys/class/kgsl/kgsl-3d0 ] && t=adreno
if [ "§t" = "outro" ]; then
  for d in /sys/class/devfreq/*mali* /sys/devices/platform/*mali* /sys/module/ged /sys/kernel/ged /proc/gpufreq /proc/mali /sys/class/misc/mali0; do
    if [ -e "§d" ]; then t=mali; break; fi
  done
fi
echo "T|§t"
echo "H|§(getprop ro.board.platform)|§(getprop ro.hardware)|§(getprop ro.soc.manufacturer)|§(getprop ro.soc.model)"
if [ -f /dev/cpuctl/top-app/cpu.uclamp.min ] || [ -f /dev/stune/top-app/schedtune.boost ]; then echo "S|cpuboost|1"; else echo "S|cpuboost|0|Este kernel não tem controle de prioridade (uclamp ou schedtune)."; fi
n=0
for q in /sys/block/sd[a-z]/queue /sys/block/mmcblk[0-9]/queue /sys/block/nvme[0-9]n[0-9]/queue; do [ -f "§q/scheduler" ] && n=§((n+1)); done
if [ §n -gt 0 ]; then echo "S|io|1"; else echo "S|io|0|O aparelho não expõe o escalonador de disco."; fi
n=0
for q in /sys/block/sd[a-z]/queue /sys/block/mmcblk[0-9]/queue /sys/block/nvme[0-9]n[0-9]/queue; do [ -f "§q/read_ahead_kb" ] && n=§((n+1)); done
if [ §n -gt 0 ]; then echo "S|readahead|1"; else echo "S|readahead|0|O aparelho não expõe a leitura antecipada do disco."; fi
if [ -f /sys/class/kgsl/kgsl-3d0/devfreq/adrenoboost ] || [ -f /sys/class/kgsl/kgsl-3d0/idle_timer ]; then echo "S|gpu|1"; else echo "S|gpu|0|Este aparelho não tem Adreno Boost."; fi
m=0
for d in /sys/class/devfreq/*mali* /sys/class/devfreq/*gpu* /sys/class/devfreq/*mfg*; do [ -f "§d/min_freq" ] && m=1; done
for f in /sys/module/ged/parameters/gx_game_mode /sys/module/ged/parameters/boost_gpu_enable /sys/module/ged/parameters/ged_boost_enable; do [ -f "§f" ] && m=1; done
if [ §m -eq 1 ]; then echo "S|mali|1"; else echo "S|mali|0|Este kernel não expõe controles da GPU Mali ou MediaTek."; fi
c=§(dumpsys display 2>/dev/null | grep -o 'fps=[0-9.]*' | sort -u | wc -l)
if [ "§c" -ge 2 ] 2>/dev/null; then echo "S|taxa|1"; else echo "S|taxa|0|A tela só tem uma taxa de atualização."; fi
if cmd wifi help 2>&1 | grep -q "force-low-latency-mode"; then echo "S|wifi|1"; else echo "S|wifi|0|Este Android não tem o modo de baixa latência do Wi‑Fi."; fi
if cmd netpolicy help 2>&1 | grep -q "restrict-background"; then echo "S|dados|1"; else echo "S|dados|0|Este Android não permite ligar a Economia de dados por comando."; fi
if cmd power help 2>&1 | grep -q "fixed-performance" || [ -f /proc/cpufreq/cpufreq_power_mode ]; then echo "S|sustentado|1"; else echo "S|sustentado|0|A ROM não tem o modo de desempenho fixo."; fi
""")

    /** Testa uma vez por boot o que o aparelho suporta. Devolve true se algo mudou (a tela precisa se redesenhar). */
    fun sondar(ctx: Context): Boolean {
        val boot = System.currentTimeMillis() - SystemClock.elapsedRealtime()
        if (abs(boot - Prefs.lng(ctx, "sondado_boot", -1L)) < 60_000L) return false
        val s = RootShell.run(SONDA) ?: return false
        var mudou = false
        for (l in s.lines()) {
            val p = l.split("|")
            if (p.size < 2) continue
            if (p[0] == "T") {
                if (Prefs.str(ctx, "gpu_tipo", "") != p[1].trim()) {
                    Prefs.putStr(ctx, "gpu_tipo", p[1].trim())
                    mudou = true
                }
            } else if (p[0] == "H") {
                Prefs.putStr(ctx, "hw_info", l.removePrefix("H|"))
            } else if (p[0] == "S" && p.size >= 3) {
                val novo = if (p[2].trim() == "1") "1" else "0|" + p.getOrElse(3) { "Indisponível neste aparelho." }
                if (Prefs.str(ctx, "sup_" + p[1], "") != novo) {
                    Prefs.putStr(ctx, "sup_" + p[1], novo)
                    mudou = true
                }
            }
        }
        Prefs.putLng(ctx, "sondado_boot", boot)
        return mudou
    }

    /** Motivo pelo qual a função não existe neste aparelho, ou nulo se ela pode ser usada. */
    fun indisponivel(ctx: Context, id: String): String? {
        val v = Prefs.str(ctx, "sup_$id", "")
        return if (v.startsWith("0|")) v.removePrefix("0|") else null
    }

    /** Funções que fazem sentido para o chip deste aparelho (Adreno ou Mali/MediaTek). */
    fun visiveis(ctx: Context): List<Modulo> {
        val tipo = Prefs.str(ctx, "gpu_tipo", "")
        return lista.filter { it.gpu.isEmpty() || tipo.isEmpty() || it.gpu == tipo }
    }

    private fun restaurar(tabela: String, chave: String, valor: String, padrao: String?): String {
        val v = valor.trim()
        return if (v.isNotEmpty() && v != "null" && SEGURO.matches(v)) "settings put $tabela $chave $v"
        else if (padrao != null) "settings put $tabela $chave $padrao"
        else "settings delete $tabela $chave"
    }

    private fun linhaOrig(saida: String): String? =
        saida.lines().firstOrNull { it.startsWith("ORIG|") }?.removePrefix("ORIG|")

    private fun guardar(ctx: Context, id: String, orig: String) {
        Prefs.putStr(ctx, "mo_orig_$id", orig)
        Prefs.setModAtivo(ctx, id, true)
    }

    /** O escalonador de disco volta ao padrão no boot; o flag de "ligado" também precisa voltar. */
    fun reconciliar(ctx: Context) {
        val boot = System.currentTimeMillis() - SystemClock.elapsedRealtime()
        if (abs(boot - Prefs.lng(ctx, "mod_boot", -1L)) < 60_000L) return
        Prefs.putLng(ctx, "mod_boot", boot)
        Prefs.setModAtivo(ctx, "io", false)
        Prefs.setModAtivo(ctx, "cpuboost", false)
        Prefs.setModAtivo(ctx, "gpu", false)
        Prefs.setModAtivo(ctx, "readahead", false)
        Prefs.setModAtivo(ctx, "chamadas", false)
        Prefs.setModAtivo(ctx, "mali", false)
        Prefs.setModAtivo(ctx, "sustentado", false)
    }

    fun ligar(ctx: Context, id: String, jogo: String?): Res {
        reconciliar(ctx)
        val m = lista.firstOrNull { it.id == id } ?: return Res(false, "Módulo desconhecido.")
        if (m.reversivel && Prefs.modAtivo(ctx, id)) return Res(true, "Já está ligado.")
        return when (id) {
            "animacoes" -> {
                val s = RootShell.run(sh("""
echo "ORIG|§(settings get global window_animation_scale)|§(settings get global transition_animation_scale)|§(settings get global animator_duration_scale)"
settings put global window_animation_scale 0.5
settings put global transition_animation_scale 0.5
settings put global animator_duration_scale 0.5
""")) ?: return semRoot()
                guardar(ctx, id, linhaOrig(s) ?: "||")
                Res(true, "Animações rápidas ligadas.")
            }
            "cpuboost" -> {
                val s = RootShell.run(sh("""
for f in /dev/cpuctl/top-app/cpu.uclamp.min /dev/stune/top-app/schedtune.boost; do
  [ -f "§f" ] && echo "KNOB|§f"
done
""")) ?: return semRoot()
                val pares = ArrayList<Pair<String, String>>()
                for (l in s.lines()) {
                    val p = l.split("|")
                    if (p[0] != "KNOB" || p.size < 2 || p[1].trim() !in KNOBS) continue
                    pares.add(Pair(p[1].trim(), if (p[1].trim().endsWith("uclamp.min")) "25.00" else "10"))
                }
                if (pares.isEmpty()) return Res(false, "Este aparelho não tem controle de prioridade para o app em primeiro plano.")
                val e = escreverNos(pares) ?: return semRoot()
                if (e.guardados.isEmpty()) return Res(false, "O kernel recusou o ajuste de prioridade (somente leitura).")
                guardar(ctx, id, e.guardados.joinToString(";"))
                Res(true, "Prioridade da CPU ligada.")
            }
            "toque" -> {
                val s = RootShell.run(sh("""
echo "ORIG|§(settings get secure long_press_timeout)|§(cat /proc/touchpanel/game_switch_enable 2>/dev/null)"
settings put secure long_press_timeout 200
[ -f /proc/touchpanel/game_switch_enable ] && echo 1 > /proc/touchpanel/game_switch_enable
""")) ?: return semRoot()
                guardar(ctx, id, linhaOrig(s) ?: "|")
                Res(true, "Resposta ao toque ligada.")
            }
            "dnd" -> {
                val s = RootShell.run(sh("""
echo "ORIG|§(settings get global zen_mode)"
settings put global zen_mode 1
""")) ?: return semRoot()
                guardar(ctx, id, linhaOrig(s) ?: "0")
                Res(true, "Não perturbe ligado.")
            }
            "taxa" -> {
                val s = RootShell.run(sh("""
echo "ORIG|§(settings get system min_refresh_rate)|§(settings get system peak_refresh_rate)|§(settings get system miui_refresh_rate)|§(settings get system user_refresh_rate)"
dumpsys display 2>/dev/null | grep -o 'fps=[0-9.]*' | sort -u | sed 's/^/FPS|/'
""")) ?: return semRoot()
                val maximo = s.lines()
                    .filter { it.startsWith("FPS|") }
                    .mapNotNull { it.removePrefix("FPS|fps=").toFloatOrNull() }
                    .filter { it <= 240f }
                    .maxOrNull()
                    ?: return Res(false, "Não consegui descobrir as taxas da tela.")
                val hz = Math.round(maximo)
                val o = linhaOrig(s) ?: "|||"
                val p = o.split("|")
                val cmd = StringBuilder("settings put system min_refresh_rate $hz.0; settings put system peak_refresh_rate $hz.0")
                // algumas ROMs (Xiaomi e outras) guardam a taxa em chaves próprias; só mexo se a chave já existe
                if (p.getOrElse(2) { "" }.isNotBlank() && p.getOrElse(2) { "" }.trim() != "null")
                    cmd.append("; settings put system miui_refresh_rate $hz")
                if (p.getOrElse(3) { "" }.isNotBlank() && p.getOrElse(3) { "" }.trim() != "null")
                    cmd.append("; settings put system user_refresh_rate $hz")
                RootShell.run(cmd.toString()) ?: return semRoot()
                val lido = RootShell.run("settings get system peak_refresh_rate") ?: return semRoot()
                if (lido.trim().toFloatOrNull()?.let { Math.round(it) } != hz)
                    return Res(false, "A ROM não aceitou fixar a taxa da tela. Fixe nas configurações de tela do aparelho.")
                guardar(ctx, id, o)
                Res(true, "Tela em $hz Hz (se a ROM respeitar).")
            }
            "cor" -> {
                Cor.aplicar(Cor.salvo(ctx))
                guardar(ctx, id, "")
                Res(true, "Perfil de cor aplicado.")
            }
            "io" -> {
                val s = RootShell.run(sh("""
for q in /sys/block/sd[a-z]/queue /sys/block/mmcblk[0-9]/queue /sys/block/nvme[0-9]n[0-9]/queue; do
  [ -f "§q/scheduler" ] || continue
  echo "IO|§q|§(cat §q/scheduler)"
done
""")) ?: return semRoot()
                val sb = StringBuilder()
                val orig = ArrayList<String>()
                val alvos = ArrayList<Pair<String, String>>()
                var vistos = 0
                for (l in s.lines()) {
                    val p = l.split("|")
                    if (p[0] != "IO" || p.size < 3 || !CAMINHO.matches(p[1])) continue
                    val conteudo = p[2]
                    val atual = Regex("\\[([^\\]]+)\\]").find(conteudo)?.groupValues?.get(1) ?: continue
                    vistos++
                    val disp = conteudo.replace("[", "").replace("]", "").trim().split(Regex("\\s+"))
                    val alvo = listOf("none", "noop", "mq-deadline", "deadline").firstOrNull { it in disp } ?: continue
                    if (alvo == atual) continue
                    sb.append("echo ").append(alvo).append(" > ").append(p[1]).append("/scheduler 2>/dev/null\n")
                    orig.add(p[1] + "=" + atual)
                    alvos.add(Pair(p[1], alvo))
                }
                if (vistos == 0) return Res(false, "O aparelho não expõe o escalonador de disco.")
                if (sb.isEmpty()) {
                    // já está no mais leve: não é falha, só não há o que trocar
                    guardar(ctx, id, "")
                    return Res(true, "O disco já usa o escalonador mais leve.")
                }
                RootShell.run(sb.toString()) ?: return semRoot()
                val conf = RootShell.run(
                    alvos.joinToString("\n") { "echo \"C|" + it.first + "|\$(cat " + it.first + "/scheduler)\"" }
                ) ?: ""
                var pegou = 0
                for (l in conf.lines()) {
                    val p = l.split("|")
                    if (p[0] != "C" || p.size < 3) continue
                    val alvo = alvos.firstOrNull { it.first == p[1] }?.second ?: continue
                    if (p[2].contains("[" + alvo + "]")) pegou++
                }
                if (pegou == 0) return Res(false, "O kernel recusou trocar o escalonador do disco.")
                guardar(ctx, id, orig.joinToString(";"))
                Res(true, "Disco em modo direto.")
            }
            "wifi" -> {
                val s = RootShell.run("cmd wifi force-low-latency-mode enabled 2>&1") ?: return semRoot()
                val ruim = s.contains("Unknown", true) || s.contains("Error", true) ||
                    s.contains("not found", true) || s.contains("Exception", true)
                if (ruim) return Res(false, "Este Android não suporta o modo de baixa latência do Wi‑Fi.")
                guardar(ctx, id, "")
                Res(true, "Wi‑Fi em baixa latência.")
            }
            "antiqueda" -> {
                guardar(ctx, id, "")
                Res(true, "Anti-queda de FPS ligado.")
            }
            "chamadas" -> {
                Tuner.protegerChamadas(ctx)
                guardar(ctx, id, "")
                Res(true, "Chamadas protegidas.")
            }
            "gpu" -> {
                val s = RootShell.run(sh("""
echo "ORIG|§(cat /sys/class/kgsl/kgsl-3d0/devfreq/adrenoboost 2>/dev/null)|§(cat /sys/class/kgsl/kgsl-3d0/idle_timer 2>/dev/null)"
[ -f /sys/class/kgsl/kgsl-3d0/devfreq/adrenoboost ] && { echo 2 > /sys/class/kgsl/kgsl-3d0/devfreq/adrenoboost; } 2>/dev/null
[ -f /sys/class/kgsl/kgsl-3d0/idle_timer ] && { echo 150 > /sys/class/kgsl/kgsl-3d0/idle_timer; } 2>/dev/null
echo "NOW|§(cat /sys/class/kgsl/kgsl-3d0/devfreq/adrenoboost 2>/dev/null)|§(cat /sys/class/kgsl/kgsl-3d0/idle_timer 2>/dev/null)"
""")) ?: return semRoot()
                val o = linhaOrig(s) ?: "|"
                val p = o.split("|")
                if (p.getOrElse(0) { "" }.isBlank() && p.getOrElse(1) { "" }.isBlank())
                    return Res(false, "Este aparelho não tem GPU Adreno com Adreno Boost. Se o chip é Mali ou MediaTek, use o Boost da GPU Mali / MediaTek.")
                val agora = s.lines().firstOrNull { it.startsWith("NOW|") }?.split("|") ?: emptyList()
                val pegou = agora.getOrElse(1) { "" }.trim() == "2" || agora.getOrElse(2) { "" }.trim() == "150"
                if (!pegou) return Res(false, "O kernel recusou o ajuste da GPU (somente leitura).")
                guardar(ctx, id, o)
                Res(true, "Adreno Boost ligado.")
            }
            "readahead" -> {
                val s = RootShell.run(sh("""
for q in /sys/block/sd[a-z]/queue /sys/block/mmcblk[0-9]/queue /sys/block/nvme[0-9]n[0-9]/queue; do
  [ -f "§q/read_ahead_kb" ] || continue
  echo "RA|§q|§(cat §q/read_ahead_kb)"
done
""")) ?: return semRoot()
                val pares = ArrayList<Pair<String, String>>()
                var vistos = 0
                for (l in s.lines()) {
                    val p = l.split("|")
                    if (p[0] != "RA" || p.size < 3 || !CAMINHO.matches(p[1])) continue
                    val atual = p[2].trim().toIntOrNull() ?: continue
                    vistos++
                    if (atual >= 1024) continue
                    pares.add(Pair(p[1] + "/read_ahead_kb", "1024"))
                }
                if (vistos == 0) return Res(false, "O aparelho não expõe a leitura antecipada do disco.")
                if (pares.isEmpty()) {
                    guardar(ctx, id, "")
                    return Res(true, "A leitura antecipada já está em 1024 KB ou mais.")
                }
                val e = escreverNos(pares) ?: return semRoot()
                if (e.guardados.isEmpty()) return Res(false, "O kernel recusou ajustar a leitura antecipada.")
                guardar(ctx, id, e.guardados.joinToString(";"))
                Res(true, "Leitura antecipada ligada.")
            }
            "headsup" -> {
                val s = RootShell.run(sh("""
echo "ORIG|§(settings get global heads_up_notifications_enabled)"
settings put global heads_up_notifications_enabled 0
""")) ?: return semRoot()
                guardar(ctx, id, linhaOrig(s) ?: "1")
                Res(true, "Avisos na tela desligados.")
            }
            "brilho" -> {
                val s = RootShell.run(sh("""
echo "ORIG|§(settings get system screen_brightness_mode)"
settings put system screen_brightness_mode 0
""")) ?: return semRoot()
                guardar(ctx, id, linhaOrig(s) ?: "1")
                Res(true, "Brilho fixo.")
            }
            "mali" -> {
                val s = RootShell.run(sh("""
for d in /sys/class/devfreq/*mali* /sys/class/devfreq/*gpu* /sys/class/devfreq/*mfg*; do
  [ -f "§d/min_freq" ] || continue
  r=§(readlink -f "§d")
  echo "DEV|§r|§(cat §d/available_frequencies 2>/dev/null)"
  break
done
for f in /sys/module/ged/parameters/gx_game_mode /sys/module/ged/parameters/boost_gpu_enable /sys/module/ged/parameters/ged_boost_enable; do
  [ -f "§f" ] && echo "GED|§f"
done
""")) ?: return semRoot()
                val pares = ArrayList<Pair<String, String>>()
                for (l in s.lines()) {
                    val p = l.split("|")
                    if (p[0] == "DEV" && p.size >= 3 && NO_OK.matches(p[1])) {
                        val freqs = p[2].trim().split(Regex("\\s+")).mapNotNull { it.toLongOrNull() }.sorted()
                        if (freqs.size >= 3) {
                            val alvo = freqs[(freqs.size * 0.6).toInt().coerceAtMost(freqs.size - 1)]
                            pares.add(Pair(p[1] + "/min_freq", alvo.toString()))
                        }
                    }
                    if (p[0] == "GED" && p.size >= 2) pares.add(Pair(p[1].trim(), "1"))
                }
                if (pares.isEmpty())
                    return Res(false, "Este kernel não expõe controles da GPU Mali / MediaTek. O perfil Gaming ainda ajusta a CPU.")
                val e = escreverNos(pares) ?: return semRoot()
                if (e.guardados.isEmpty()) return Res(false, "O kernel recusou os ajustes da GPU (somente leitura).")
                guardar(ctx, id, e.guardados.joinToString(";"))
                Res(true, "GPU Mali / MediaTek: " + e.guardados.size + " ajuste(s) ligado(s).")
            }
            "sustentado" -> {
                val s = RootShell.run(sh("""
r=§(cmd power set-fixed-performance-mode-enabled true 2>&1)
echo "CMD|§r"
echo "MTK|§(cat /proc/cpufreq/cpufreq_power_mode 2>/dev/null)"
""")) ?: return semRoot()
                val cmdTxt = s.lines().firstOrNull { it.startsWith("CMD|") }.orEmpty()
                val cmdOk = !(cmdTxt.contains("Unknown", true) || cmdTxt.contains("Exception", true) ||
                    cmdTxt.contains("Error", true) || cmdTxt.contains("not found", true))
                val mtk = s.lines().firstOrNull { it.startsWith("MTK|") }?.removePrefix("MTK|")?.trim().orEmpty()
                var mtkOrig = ""
                var mtkOk = false
                if (mtk.toIntOrNull() != null) {
                    val e = escreverNos(listOf(Pair("/proc/cpufreq/cpufreq_power_mode", "3"))) ?: return semRoot()
                    if (e.guardados.isNotEmpty()) {
                        mtkOk = true
                        mtkOrig = mtk
                    }
                }
                if (!cmdOk && !mtkOk) return Res(false, "A ROM deste aparelho não tem o modo de desempenho fixo.")
                guardar(ctx, id, (if (cmdOk) "1" else "0") + "|" + mtkOrig)
                Res(true, "Desempenho sustentado ligado.")
            }
            "dados" -> {
                val antes = RootShell.run("cmd netpolicy get restrict-background 2>&1") ?: return semRoot()
                val estavaLigado = antes.contains("enabled", true) && !antes.contains("disabled", true)
                val r = RootShell.run("cmd netpolicy set restrict-background true 2>&1") ?: return semRoot()
                if (r.contains("Unknown", true) || r.contains("Exception", true) || r.contains("Error", true))
                    return Res(false, "Este Android não deixa ligar a Economia de dados por comando.")
                guardar(ctx, id, if (estavaLigado) "1" else "0")
                Res(true, "Dados em segundo plano pausados.")
            }
            "scan" -> {
                val s = RootShell.run(sh("""
echo "ORIG|§(settings get global wifi_scan_always_enabled)|§(settings get global ble_scan_always_enabled)"
settings put global wifi_scan_always_enabled 0
settings put global ble_scan_always_enabled 0
echo "NOW|§(settings get global wifi_scan_always_enabled)|§(settings get global ble_scan_always_enabled)"
""")) ?: return semRoot()
                val agora = s.lines().firstOrNull { it.startsWith("NOW|") }?.split("|") ?: emptyList()
                if (agora.getOrElse(1) { "" }.trim() != "0") return Res(false, "A ROM não deixou desligar as buscas de rede.")
                guardar(ctx, id, linhaOrig(s) ?: "||")
                Res(true, "Buscas de Wi‑Fi e Bluetooth desligadas.")
            }
            "poupanca" -> {
                val s = RootShell.run(sh("""
echo "ORIG|§(settings get global low_power)|§(settings get global adaptive_battery_management_enabled)"
settings put global low_power 0
settings put global adaptive_battery_management_enabled 0
echo "NOW|§(settings get global low_power)|§(settings get global adaptive_battery_management_enabled)"
""")) ?: return semRoot()
                val agora = s.lines().firstOrNull { it.startsWith("NOW|") }?.split("|") ?: emptyList()
                if (agora.getOrElse(1) { "" }.trim() != "0") return Res(false, "A ROM não deixou desligar a economia de bateria.")
                guardar(ctx, id, linhaOrig(s) ?: "||")
                Res(true, "Economia de bateria desligada durante o jogo.")
            }
            "ram" -> Res(true, Tuner.limparRam(ctx))
            "profunda" -> Res(true, Tuner.limpezaProfunda(ctx, jogo))
            else -> Res(false, "Módulo desconhecido.")
        }
    }

    fun desligar(ctx: Context, id: String): Res {
        val m = lista.firstOrNull { it.id == id } ?: return Res(false, "Módulo desconhecido.")
        if (!m.reversivel) return Res(true, "")
        if (!Prefs.modAtivo(ctx, id)) return Res(true, "Já está desligado.")
        val o = Prefs.str(ctx, "mo_orig_$id", "").split("|")
        val cmd = when (id) {
            "animacoes" ->
                restaurar("global", "window_animation_scale", o.getOrElse(0) { "" }, "1.0") + "\n" +
                    restaurar("global", "transition_animation_scale", o.getOrElse(1) { "" }, "1.0") + "\n" +
                    restaurar("global", "animator_duration_scale", o.getOrElse(2) { "" }, "1.0")
            "cpuboost" -> {
                val sb = StringBuilder()
                for (par in o[0].split(";")) {
                    val p = par.split("=")
                    if (p.size == 2 && p[0] in KNOBS && VALOR_KNOB.matches(p[1]))
                        sb.append("{ echo ").append(p[1]).append(" > ").append(p[0]).append("; } 2>/dev/null\n")
                }
                sb.toString()
            }
            "toque" -> {
                val tp = o.getOrElse(1) { "" }.trim()
                restaurar("secure", "long_press_timeout", o.getOrElse(0) { "" }, null) + "\n" +
                    (if (tp == "0" || tp == "1") "[ -f /proc/touchpanel/game_switch_enable ] && echo $tp > /proc/touchpanel/game_switch_enable" else "")
            }
            "dnd" -> restaurar("global", "zen_mode", o.getOrElse(0) { "" }, "0")
            "taxa" -> {
                var c = restaurar("system", "min_refresh_rate", o.getOrElse(0) { "" }, null) + "\n" +
                    restaurar("system", "peak_refresh_rate", o.getOrElse(1) { "" }, null)
                val miui = o.getOrElse(2) { "" }.trim()
                if (miui.isNotEmpty() && miui != "null") c += "\n" + restaurar("system", "miui_refresh_rate", miui, null)
                val usr = o.getOrElse(3) { "" }.trim()
                if (usr.isNotEmpty() && usr != "null") c += "\n" + restaurar("system", "user_refresh_rate", usr, null)
                c
            }
            "cor" -> {
                Cor.aplicar(Cor.ORIGINAL)
                ""
            }
            "io" -> {
                val sb = StringBuilder()
                for (par in o[0].split(";")) {
                    val p = par.split("=")
                    if (p.size == 2 && CAMINHO.matches(p[0]) && SEGURO_IO.matches(p[1]))
                        sb.append("echo ").append(p[1]).append(" > ").append(p[0]).append("/scheduler 2>/dev/null\n")
                }
                sb.toString()
            }
            "wifi" -> "cmd wifi force-low-latency-mode disabled 2>/dev/null"
            "chamadas" -> {
                Tuner.soltarChamadas(ctx)
                ""
            }
            "gpu" -> {
                val sb = StringBuilder()
                val b = o.getOrElse(0) { "" }.trim()
                val i = o.getOrElse(1) { "" }.trim()
                if (b.toIntOrNull() != null)
                    sb.append("{ echo ").append(b).append(" > /sys/class/kgsl/kgsl-3d0/devfreq/adrenoboost; } 2>/dev/null\n")
                if (i.toIntOrNull() != null)
                    sb.append("{ echo ").append(i).append(" > /sys/class/kgsl/kgsl-3d0/idle_timer; } 2>/dev/null\n")
                sb.toString()
            }
            "readahead" -> restaurarNos(o[0].split(";"))
            "mali" -> restaurarNos(o[0].split(";"))
            "sustentado" -> {
                val sb = StringBuilder()
                if (o.getOrElse(0) { "" }.trim() == "1") sb.append("cmd power set-fixed-performance-mode-enabled false 2>/dev/null\n")
                val m = o.getOrElse(1) { "" }.trim()
                if (m.toIntOrNull() != null) sb.append("{ echo ").append(m).append(" > /proc/cpufreq/cpufreq_power_mode; } 2>/dev/null\n")
                sb.toString()
            }
            "dados" -> if (o.getOrElse(0) { "" }.trim() == "1") "" else "cmd netpolicy set restrict-background false 2>/dev/null"
            "scan" -> restaurar("global", "wifi_scan_always_enabled", o.getOrElse(0) { "" }, null) + "\n" +
                restaurar("global", "ble_scan_always_enabled", o.getOrElse(1) { "" }, null)
            "poupanca" -> restaurar("global", "low_power", o.getOrElse(0) { "" }, "0") + "\n" +
                restaurar("global", "adaptive_battery_management_enabled", o.getOrElse(1) { "" }, "1")
            "headsup" -> restaurar("global", "heads_up_notifications_enabled", o.getOrElse(0) { "" }, "1")
            "brilho" -> restaurar("system", "screen_brightness_mode", o.getOrElse(0) { "" }, "1")
            else -> ""
        }
        if (cmd.isNotBlank()) RootShell.run(cmd) ?: return semRoot()
        Prefs.setModAtivo(ctx, id, false)
        return Res(true, m.nome + " desligado.")
    }
}
