package br.com.rootboost

import android.content.Context
import android.os.SystemClock
import kotlin.math.abs

/** Cada módulo liga e desliga um ajuste do sistema, guardando o valor original para restaurar. */
object Modulos {

    class Modulo(
        val id: String,
        val nome: String,
        val desc: String,
        val icone: String,
        val info: String,
        val reversivel: Boolean = true
    )

    class Res(val ok: Boolean, val msg: String)

    val lista = listOf(
        Modulo(
            "animacoes", "Animações rápidas", "Encurta as animações do sistema durante o jogo.", "raio",
            "Reduz a escala das animações do Android (janelas, transições) para 0,5x enquanto você joga. Ao sair do jogo, os valores originais voltam."
        ),
        Modulo(
            "ram", "Gerenciamento de memória", "Libera e compacta a RAM ao abrir o jogo.", "memoria",
            "Encerra processos em cache, descarrega caches do sistema e compacta a memória. Roda uma vez, quando o jogo abre.", false
        ),
        Modulo(
            "cpuboost", "Prioridade da CPU", "Dá mais prioridade ao app em primeiro plano.", "cpu",
            "Sobe o piso de prioridade do grupo top-app (uclamp ou schedtune, o que o aparelho tiver). Alguns aparelhos não têm esse controle."
        ),
        Modulo(
            "taxa", "Taxa de atualização máxima", "Fixa a maior taxa de quadros da tela.", "atualizar",
            "Descobre a maior taxa que a tela suporta e a fixa durante o jogo. Libera a taxa da tela, não aumenta o FPS do jogo."
        ),
        Modulo(
            "io", "Disco em modo direto", "Troca o escalonador de I/O pelo mais leve.", "modulos",
            "Usa o escalonador de disco mais simples disponível (none, noop ou mq-deadline), o que pode acelerar o carregamento."
        ),
        Modulo(
            "antiqueda", "Anti-queda de FPS", "Se o FPS cai de repente, sobe a CPU por alguns segundos.", "fps",
            "Vigia o FPS do jogo. Quando ele despenca em relação à média recente, sobe a frequência mínima da CPU por 3 segundos e depois volta ao perfil. Não age se o aparelho estiver quente (46 °C ou mais)."
        ),
        Modulo(
            "cor", "Cores e shader no jogo", "Aplica o seu perfil de cor só durante o jogo.", "cor",
            "Aplica o shader escolhido na aba Gráficos (saturação, contraste, brilho e cores) quando o jogo abre e volta ao normal quando fecha."
        ),
        Modulo(
            "toque", "Lightning Touch", "Melhora a resposta da tela ao toque.", "toque",
            "Reduz o tempo do toque longo e liga o modo jogo do touch, nos aparelhos que têm esse recurso."
        ),
        Modulo(
            "dnd", "Não perturbe", "Silencia chamadas e notificações enquanto joga.", "sino",
            "Liga o modo Não perturbe (somente prioridade) durante o jogo e devolve o estado anterior ao sair."
        ),
        Modulo(
            "wifi", "Baixa latência do Wi‑Fi", "Prioriza a latência da conexão Wi‑Fi.", "wifi",
            "Liga o modo de baixa latência do Wi‑Fi do Android, quando a versão do sistema suporta."
        ),
        Modulo(
            "chamadas", "Proteger chamadas", "Mantém Discord, WhatsApp e afins vivos durante o jogo.", "sino",
            "Faz o sistema fechar os apps de chamada por último quando falta memória (oom_score_adj) e desliga o limite de processos em segundo plano do Android 12+. Também faz o Smart App Killer e a limpeza de RAM pularem esses apps. Nada disso toca no jogo."
        ),
        Modulo(
            "gpu", "Adreno Boost", "Faz a GPU Adreno subir o clock mais cedo.", "cpu",
            "Liga o Adreno Boost (nível 2) e aumenta o tempo de espera antes da GPU relaxar (idle timer). Ajuda em jogos que oscilam, como Honor of Kings. Só funciona se o kernel expõe esses controles. Ao sair do jogo, os valores originais voltam."
        ),
        Modulo(
            "readahead", "Leitura antecipada do disco", "Carrega texturas e mapas mais rápido.", "modulos",
            "Aumenta o read-ahead do armazenamento para 1024 KB, o que reduz a espera em telas de carregamento. Volta ao valor original ao sair do jogo."
        ),
        Modulo(
            "headsup", "Sem avisos na tela", "Esconde os avisos que caem por cima do jogo.", "sino",
            "Desliga as notificações em pop-up (heads-up) durante o jogo, para nada atravessar a tela no meio da partida. As notificações continuam chegando na barra."
        ),
        Modulo(
            "brilho", "Brilho fixo", "Impede o brilho automático de mudar no meio do jogo.", "tela",
            "Desliga o brilho automático durante o jogo, para a tela não escurecer ou clarear sozinha. O modo anterior volta ao sair."
        ),
        Modulo(
            "profunda", "Smart App Killer", "Encerra apps em segundo plano que não estão em uso.", "limpar",
            "Fecha apps de terceiros abertos em segundo plano, menos os protegidos, o launcher, o teclado e o próprio jogo. Roda uma vez, quando o jogo abre.", false
        )
    )

    private val SEGURO = Regex("[A-Za-z0-9_.,:-]+")
    private val SEGURO_IO = Regex("[A-Za-z0-9_-]+")
    private val CAMINHO = Regex("/sys/block/[A-Za-z0-9_]+/queue")
    private val KNOBS = setOf("/dev/cpuctl/top-app/cpu.uclamp.min", "/dev/stune/top-app/schedtune.boost")
    private val VALOR_KNOB = Regex("[A-Za-z0-9.]+")

    private fun semRoot() = Res(false, "Sem acesso root.")

    private fun restaurar(tabela: String, chave: String, valor: String, padrao: String?): String {
        val v = valor.trim()
        return if (v.isNotEmpty() && v != "null" && SEGURO.matches(v)) "settings put $tabela $chave $v"
        else if (padrao != null) "settings put $tabela $chave $padrao"
        else "settings delete $tabela $chave"
    }

    private fun linhaOrig(saida: String): String? =
        saida.lines().firstOrNull { it.startsWith("ORIG|") }?.removePrefix("ORIG|")

    private fun guardar(ctx: Context, id: String, orig: String) {
        Prefs.putStr(ctx, "mo_orig_$id", orig)
        Prefs.setModAtivo(ctx, id, true)
    }

    /** O escalonador de disco volta ao padrão no boot; o flag de "ligado" também precisa voltar. */
    fun reconciliar(ctx: Context) {
        val boot = System.currentTimeMillis() - SystemClock.elapsedRealtime()
        if (abs(boot - Prefs.lng(ctx, "mod_boot", -1L)) < 60_000L) return
        Prefs.putLng(ctx, "mod_boot", boot)
        Prefs.setModAtivo(ctx, "io", false)
        Prefs.setModAtivo(ctx, "cpuboost", false)
        Prefs.setModAtivo(ctx, "gpu", false)
        Prefs.setModAtivo(ctx, "readahead", false)
        Prefs.setModAtivo(ctx, "chamadas", false)
    }

    fun ligar(ctx: Context, id: String, jogo: String?): Res {
        reconciliar(ctx)
        val m = lista.firstOrNull { it.id == id } ?: return Res(false, "Módulo desconhecido.")
        if (m.reversivel && Prefs.modAtivo(ctx, id)) return Res(true, "Já está ligado.")
        return when (id) {
            "animacoes" -> {
                val s = RootShell.run(sh("""
echo "ORIG|§(settings get global window_animation_scale)|§(settings get global transition_animation_scale)|§(settings get global animator_duration_scale)"
settings put global window_animation_scale 0.5
settings put global transition_animation_scale 0.5
settings put global animator_duration_scale 0.5
""")) ?: return semRoot()
                guardar(ctx, id, linhaOrig(s) ?: "||")
                Res(true, "Animações rápidas ligadas.")
            }
            "cpuboost" -> {
                val s = RootShell.run(sh("""
for f in /dev/cpuctl/top-app/cpu.uclamp.min /dev/stune/top-app/schedtune.boost; do
  [ -f "§f" ] && echo "KNOB|§f|§(cat §f)"
done
""")) ?: return semRoot()
                val sb = StringBuilder()
                val orig = ArrayList<String>()
                for (l in s.lines()) {
                    val p = l.split("|")
                    if (p[0] != "KNOB" || p.size < 3 || p[1] !in KNOBS) continue
                    val alvo = if (p[1].endsWith("uclamp.min")) "25.00" else "10"
                    sb.append("{ echo ").append(alvo).append(" > ").append(p[1]).append("; } 2>/dev/null\n")
                    orig.add(p[1] + "=" + p[2].trim())
                }
                if (sb.isEmpty()) return Res(false, "Este aparelho não tem controle de prioridade para o app em primeiro plano.")
                RootShell.run(sb.toString()) ?: return semRoot()
                guardar(ctx, id, orig.joinToString(";"))
                Res(true, "Prioridade da CPU ligada.")
            }
            "toque" -> {
                val s = RootShell.run(sh("""
echo "ORIG|§(settings get secure long_press_timeout)|§(cat /proc/touchpanel/game_switch_enable 2>/dev/null)"
settings put secure long_press_timeout 200
[ -f /proc/touchpanel/game_switch_enable ] && echo 1 > /proc/touchpanel/game_switch_enable
""")) ?: return semRoot()
                guardar(ctx, id, linhaOrig(s) ?: "|")
                Res(true, "Resposta ao toque ligada.")
            }
            "dnd" -> {
                val s = RootShell.run(sh("""
echo "ORIG|§(settings get global zen_mode)"
settings put global zen_mode 1
""")) ?: return semRoot()
                guardar(ctx, id, linhaOrig(s) ?: "0")
                Res(true, "Não perturbe ligado.")
            }
            "taxa" -> {
                val s = RootShell.run(sh("""
echo "ORIG|§(settings get system min_refresh_rate)|§(settings get system peak_refresh_rate)"
dumpsys display 2>/dev/null | grep -o 'fps=[0-9.]*' | sort -u | sed 's/^/FPS|/'
""")) ?: return semRoot()
                val maximo = s.lines()
                    .filter { it.startsWith("FPS|") }
                    .mapNotNull { it.removePrefix("FPS|fps=").toFloatOrNull() }
                    .filter { it <= 240f }
                    .maxOrNull()
                    ?: return Res(false, "Não consegui descobrir as taxas da tela.")
                val hz = Math.round(maximo)
                RootShell.run("settings put system min_refresh_rate $hz.0; settings put system peak_refresh_rate $hz.0")
                    ?: return semRoot()
                guardar(ctx, id, linhaOrig(s) ?: "|")
                Res(true, "Tela em $hz Hz.")
            }
            "cor" -> {
                Cor.aplicar(Cor.salvo(ctx))
                guardar(ctx, id, "")
                Res(true, "Perfil de cor aplicado.")
            }
            "io" -> {
                val s = RootShell.run(sh("""
for q in /sys/block/sd[a-z]/queue /sys/block/mmcblk[0-9]/queue /sys/block/nvme[0-9]n[0-9]/queue; do
  [ -f "§q/scheduler" ] || continue
  echo "IO|§q|§(cat §q/scheduler)"
done
""")) ?: return semRoot()
                val sb = StringBuilder()
                val orig = ArrayList<String>()
                for (l in s.lines()) {
                    val p = l.split("|")
                    if (p[0] != "IO" || p.size < 3) continue
                    val conteudo = p[2]
                    val atual = Regex("\\[([^\\]]+)\\]").find(conteudo)?.groupValues?.get(1) ?: continue
                    val disp = conteudo.replace("[", "").replace("]", "").trim().split(Regex("\\s+"))
                    val alvo = listOf("none", "noop", "mq-deadline", "deadline").firstOrNull { it in disp } ?: continue
                    if (alvo == atual || !CAMINHO.matches(p[1])) continue
                    sb.append("echo ").append(alvo).append(" > ").append(p[1]).append("/scheduler 2>/dev/null\n")
                    orig.add(p[1] + "=" + atual)
                }
                if (sb.isEmpty()) return Res(false, "Nada para trocar no disco.")
                RootShell.run(sb.toString()) ?: return semRoot()
                guardar(ctx, id, orig.joinToString(";"))
                Res(true, "Disco em modo direto.")
            }
            "wifi" -> {
                val s = RootShell.run("cmd wifi force-low-latency-mode enabled 2>&1") ?: return semRoot()
                val ruim = s.contains("Unknown", true) || s.contains("Error", true) ||
                    s.contains("not found", true) || s.contains("Exception", true)
                if (ruim) return Res(false, "Este Android não suporta o modo de baixa latência do Wi‑Fi.")
                guardar(ctx, id, "")
                Res(true, "Wi‑Fi em baixa latência.")
            }
            "antiqueda" -> {
                guardar(ctx, id, "")
                Res(true, "Anti-queda de FPS ligado.")
            }
            "chamadas" -> {
                Tuner.protegerChamadas(ctx)
                guardar(ctx, id, "")
                Res(true, "Chamadas protegidas.")
            }
            "gpu" -> {
                val s = RootShell.run(sh("""
echo "ORIG|§(cat /sys/class/kgsl/kgsl-3d0/devfreq/adrenoboost 2>/dev/null)|§(cat /sys/class/kgsl/kgsl-3d0/idle_timer 2>/dev/null)"
[ -f /sys/class/kgsl/kgsl-3d0/devfreq/adrenoboost ] && { echo 2 > /sys/class/kgsl/kgsl-3d0/devfreq/adrenoboost; } 2>/dev/null
[ -f /sys/class/kgsl/kgsl-3d0/idle_timer ] && { echo 150 > /sys/class/kgsl/kgsl-3d0/idle_timer; } 2>/dev/null
""")) ?: return semRoot()
                val o = linhaOrig(s) ?: "|"
                val p = o.split("|")
                if (p.getOrElse(0) { "" }.isBlank() && p.getOrElse(1) { "" }.isBlank())
                    return Res(false, "O kernel deste aparelho não expõe Adreno Boost nem idle timer.")
                guardar(ctx, id, o)
                Res(true, "Adreno Boost ligado.")
            }
            "readahead" -> {
                val s = RootShell.run(sh("""
for q in /sys/block/sd[a-z]/queue /sys/block/mmcblk[0-9]/queue /sys/block/nvme[0-9]n[0-9]/queue; do
  [ -f "§q/read_ahead_kb" ] || continue
  echo "RA|§q|§(cat §q/read_ahead_kb)"
done
""")) ?: return semRoot()
                val sb = StringBuilder()
                val orig = ArrayList<String>()
                for (l in s.lines()) {
                    val p = l.split("|")
                    if (p[0] != "RA" || p.size < 3 || !CAMINHO.matches(p[1])) continue
                    val atual = p[2].trim().toIntOrNull() ?: continue
                    if (atual >= 1024) continue
                    sb.append("{ echo 1024 > ").append(p[1]).append("/read_ahead_kb; } 2>/dev/null\n")
                    orig.add(p[1] + "=" + atual)
                }
                if (sb.isEmpty()) return Res(false, "Nada para ajustar no disco.")
                RootShell.run(sb.toString()) ?: return semRoot()
                guardar(ctx, id, orig.joinToString(";"))
                Res(true, "Leitura antecipada ligada.")
            }
            "headsup" -> {
                val s = RootShell.run(sh("""
echo "ORIG|§(settings get global heads_up_notifications_enabled)"
settings put global heads_up_notifications_enabled 0
""")) ?: return semRoot()
                guardar(ctx, id, linhaOrig(s) ?: "1")
                Res(true, "Avisos na tela desligados.")
            }
            "brilho" -> {
                val s = RootShell.run(sh("""
echo "ORIG|§(settings get system screen_brightness_mode)"
settings put system screen_brightness_mode 0
""")) ?: return semRoot()
                guardar(ctx, id, linhaOrig(s) ?: "1")
                Res(true, "Brilho fixo.")
            }
            "ram" -> Res(true, Tuner.limparRam(ctx))
            "profunda" -> Res(true, Tuner.limpezaProfunda(ctx, jogo))
            else -> Res(false, "Módulo desconhecido.")
        }
    }

    fun desligar(ctx: Context, id: String): Res {
        val m = lista.firstOrNull { it.id == id } ?: return Res(false, "Módulo desconhecido.")
        if (!m.reversivel) return Res(true, "")
        if (!Prefs.modAtivo(ctx, id)) return Res(true, "Já está desligado.")
        val o = Prefs.str(ctx, "mo_orig_$id", "").split("|")
        val cmd = when (id) {
            "animacoes" ->
                restaurar("global", "window_animation_scale", o.getOrElse(0) { "" }, "1.0") + "\n" +
                    restaurar("global", "transition_animation_scale", o.getOrElse(1) { "" }, "1.0") + "\n" +
                    restaurar("global", "animator_duration_scale", o.getOrElse(2) { "" }, "1.0")
            "cpuboost" -> {
                val sb = StringBuilder()
                for (par in o[0].split(";")) {
                    val p = par.split("=")
                    if (p.size == 2 && p[0] in KNOBS && VALOR_KNOB.matches(p[1]))
                        sb.append("{ echo ").append(p[1]).append(" > ").append(p[0]).append("; } 2>/dev/null\n")
                }
                sb.toString()
            }
            "toque" -> {
                val tp = o.getOrElse(1) { "" }.trim()
                restaurar("secure", "long_press_timeout", o.getOrElse(0) { "" }, null) + "\n" +
                    (if (tp == "0" || tp == "1") "[ -f /proc/touchpanel/game_switch_enable ] && echo $tp > /proc/touchpanel/game_switch_enable" else "")
            }
            "dnd" -> restaurar("global", "zen_mode", o.getOrElse(0) { "" }, "0")
            "taxa" -> restaurar("system", "min_refresh_rate", o.getOrElse(0) { "" }, null) + "\n" +
                restaurar("system", "peak_refresh_rate", o.getOrElse(1) { "" }, null)
            "cor" -> {
                Cor.aplicar(Cor.ORIGINAL)
                ""
            }
            "io" -> {
                val sb = StringBuilder()
                for (par in o[0].split(";")) {
                    val p = par.split("=")
                    if (p.size == 2 && CAMINHO.matches(p[0]) && SEGURO_IO.matches(p[1]))
                        sb.append("echo ").append(p[1]).append(" > ").append(p[0]).append("/scheduler 2>/dev/null\n")
                }
                sb.toString()
            }
            "wifi" -> "cmd wifi force-low-latency-mode disabled 2>/dev/null"
            "chamadas" -> {
                Tuner.soltarChamadas(ctx)
                ""
            }
            "gpu" -> {
                val sb = StringBuilder()
                val b = o.getOrElse(0) { "" }.trim()
                val i = o.getOrElse(1) { "" }.trim()
                if (b.toIntOrNull() != null)
                    sb.append("{ echo ").append(b).append(" > /sys/class/kgsl/kgsl-3d0/devfreq/adrenoboost; } 2>/dev/null\n")
                if (i.toIntOrNull() != null)
                    sb.append("{ echo ").append(i).append(" > /sys/class/kgsl/kgsl-3d0/idle_timer; } 2>/dev/null\n")
                sb.toString()
            }
            "readahead" -> {
                val sb = StringBuilder()
                for (par in o[0].split(";")) {
                    val p = par.split("=")
                    if (p.size == 2 && CAMINHO.matches(p[0]) && p[1].toIntOrNull() != null)
                        sb.append("{ echo ").append(p[1]).append(" > ").append(p[0]).append("/read_ahead_kb; } 2>/dev/null\n")
                }
                sb.toString()
            }
            "headsup" -> restaurar("global", "heads_up_notifications_enabled", o.getOrElse(0) { "" }, "1")
            "brilho" -> restaurar("system", "screen_brightness_mode", o.getOrElse(0) { "" }, "1")
            else -> ""
        }
        if (cmd.isNotBlank()) RootShell.run(cmd) ?: return semRoot()
        Prefs.setModAtivo(ctx, id, false)
        return Res(true, m.nome + " desligado.")
    }
}
