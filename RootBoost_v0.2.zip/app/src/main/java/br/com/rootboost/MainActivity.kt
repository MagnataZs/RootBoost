package br.com.rootboost

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Typeface
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import java.util.Locale
import kotlin.math.abs

class MainActivity : Activity() {

    private lateinit var paginasRaiz: FrameLayout
    private val paginas = ArrayList<View>()
    private val colunas = ArrayList<LinearLayout>()
    private val abaIcones = ArrayList<Icone>()
    private val abaTextos = ArrayList<TextView>()
    private val abaFundos = ArrayList<LinearLayout>()

    // turbo
    private lateinit var tvRoot: TextView
    private lateinit var tvTurbo: TextView
    private lateinit var tvJogos: TextView
    private lateinit var pulso: Pulso
    private lateinit var cCpu: CartaoMetrica
    private lateinit var cGpu: CartaoMetrica
    private lateinit var cRam: CartaoMetrica
    private lateinit var cTemp: CartaoMetrica
    private lateinit var segPerfil: Segmentado
    private lateinit var tvPerfilDesc: TextView
    private lateinit var nucleos: Nucleos
    private lateinit var tvGpuAgora: TextView

    // jogos
    private lateinit var listaJogos: LinearLayout

    // funções
    private val estadoFuncao = HashMap<String, TextView>()
    private val acaoFuncao = HashMap<String, TextView>()

    // tela
    private lateinit var passosDpi: Passos
    private lateinit var passosTaxa: Passos
    private lateinit var segHwui: Segmentado
    private lateinit var segDriver: Segmentado

    // sistema
    private lateinit var tvGov: TextView
    private var govs: List<String> = emptyList()
    private lateinit var passosCpuMin: Passos
    private lateinit var passosCpuMax: Passos
    private val cpuMinPct = intArrayOf(0, 20, 40, 60, 80)
    private val cpuMaxPct = intArrayOf(30, 50, 70, 85, 100)
    private lateinit var stCpu: TextView
    private lateinit var stRam: TextView
    private lateinit var stTemp: TextView
    private lateinit var stBat: TextView

    @Volatile private var lendo = false
    @Volatile private var geracao = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val raiz = LinearLayout(this)
        raiz.orientation = LinearLayout.VERTICAL
        raiz.setBackgroundColor(0xFF080B16.toInt())
        raiz.addView(cabecalhoApp(), LinearLayout.LayoutParams(CHEIO, AUTO))

        paginasRaiz = FrameLayout(this)
        raiz.addView(paginasRaiz, LinearLayout.LayoutParams(CHEIO, 0, 1f))
        raiz.addView(barraInferior(), LinearLayout.LayoutParams(CHEIO, AUTO))
        aplicarInsets(raiz)
        setContentView(raiz)

        paginas.add(paginaTurbo())
        paginas.add(paginaJogos())
        paginas.add(paginaFuncoes())
        paginas.add(paginaTela())
        paginas.add(paginaSistema())
        for (p in paginas) paginasRaiz.addView(p, FrameLayout.LayoutParams(CHEIO, CHEIO))
        mostrarAba(0)
    }

    // ---- navegação ---------------------------------------------------------

    private fun cabecalhoApp(): View {
        val h = horizontal()
        h.setPadding(dp(16), dp(12), dp(14), dp(10))
        val logo = FrameLayout(this)
        logo.background = degrade(Neon.AZUL, Neon.VIOLETA, 12)
        val ic = Icone(this, "raio")
        ic.cor = Neon.TEXTO
        ic.tamanhoDp = 20
        logo.addView(ic, FrameLayout.LayoutParams(dp(20), dp(20), Gravity.CENTER))
        h.addView(logo, LinearLayout.LayoutParams(dp(38), dp(38)))
        val tx = vertical()
        tx.addView(titulo("RootBoost", 22f))
        tx.addView(texto("por Diparis / MagnataZs", 10.5f, Neon.SUAVE))
        h.addView(tx, LinearLayout.LayoutParams(0, AUTO, 1f).apply { leftMargin = dp(12) })
        tvRoot = texto("Verificando…", 12f, Neon.SUAVE, true)
        tvRoot.setPadding(dp(12), dp(6), dp(12), dp(6))
        tvRoot.background = forma(Neon.CARTAO_A, 20, Neon.BORDA, 1)
        h.addView(tvRoot)
        return h
    }

    /** Navegação embaixo, como antes: cinco abas com ícone e nome. */
    private fun barraInferior(): View {
        val barra = horizontal()
        barra.setBackgroundColor(0xFF0B1020.toInt())
        barra.setPadding(dp(6), dp(6), dp(6), dp(6))
        val nomes = listOf("Turbo", "Jogos", "Funções", "Tela", "Sistema")
        val tipos = listOf("inicio", "jogos", "modulos", "cor", "ajustes")
        for (i in nomes.indices) {
            val item = vertical()
            item.gravity = Gravity.CENTER
            item.setPadding(dp(2), dp(7), dp(2), dp(7))
            val ic = Icone(this, tipos[i])
            ic.tamanhoDp = 22
            item.addView(ic, LinearLayout.LayoutParams(dp(22), dp(22)))
            val tv = texto(nomes[i], 10.5f, Neon.SUAVE, true)
            tv.gravity = Gravity.CENTER
            item.addView(tv, lp(CHEIO, AUTO, 2, 0))
            item.setOnClickListener { mostrarAba(i) }
            barra.addView(item, LinearLayout.LayoutParams(0, AUTO, 1f).apply {
                leftMargin = dp(2)
                rightMargin = dp(2)
            })
            abaIcones.add(ic)
            abaTextos.add(tv)
            abaFundos.add(item)
        }
        val caixa = vertical()
        val linha = View(this)
        linha.setBackgroundColor(Neon.BORDA)
        caixa.addView(linha, LinearLayout.LayoutParams(CHEIO, dp(1)))
        caixa.addView(barra)
        return caixa
    }

    private fun mostrarAba(i: Int) {
        for (k in paginas.indices) paginas[k].visibility = if (k == i) View.VISIBLE else View.GONE
        for (k in abaIcones.indices) {
            val on = k == i
            abaIcones[k].cor = if (on) Neon.CIANO else Neon.SUAVE
            abaTextos[k].setTextColor(if (on) Neon.TEXTO else Neon.SUAVE)
            abaFundos[k].background = if (on) forma(Neon.SELECIONADO, 16, Neon.BORDA_SEL, 1) else null
        }
        if (i == 1) atualizarJogos()
        if (i == 2) atualizarFuncoes()
        if (i == 4) atualizarGovernor()
        paginas[i].alpha = 0f
        paginas[i].animate().alpha(1f).setDuration(180).start()
        entrada(colunas[i])
    }

    // ---- turbo -------------------------------------------------------------

    private fun paginaTurbo(): View {
        val col = coluna()
        col.addView(titulo("Game Turbo", 28f))
        col.addView(texto("Mais performance para os seus jogos.", 13f, Neon.SUAVE), lp(CHEIO, AUTO, 2, 14))

        // modo automático
        val auto = cartaoNeon(16)
        val l1 = horizontal()
        val bloco = vertical()
        bloco.addView(texto("Modo automático", 16f, Neon.TEXTO, true))
        bloco.addView(
            texto("Aplica o perfil e as funções do jogo quando ele abre. Ao sair, tudo volta ao normal.", 12f, Neon.SUAVE),
            lp(CHEIO, AUTO, 4, 0)
        )
        l1.addView(bloco, pesos())
        val chTurbo = Chave(this)
        chTurbo.definir(Prefs.turbo(this))
        chTurbo.aoMudar = { ligado -> alternarTurbo(ligado) }
        l1.addView(chTurbo, LinearLayout.LayoutParams(AUTO, AUTO).apply { leftMargin = dp(12) })
        auto.addView(l1)
        val estado = horizontal()
        pulso = Pulso(this)
        estado.addView(pulso, LinearLayout.LayoutParams(AUTO, AUTO).apply { rightMargin = dp(8) })
        tvTurbo = texto("", 12f, Neon.CIANO, true)
        estado.addView(tvTurbo, pesos())
        auto.addView(estado, lp(CHEIO, AUTO, 10, 12))
        val linhaJogos = horizontal()
        linhaJogos.setPadding(dp(14), dp(12), dp(14), dp(12))
        linhaJogos.background = clicavel(Neon.SELECIONADO, 12)
        tvJogos = texto("", 14f)
        linhaJogos.addView(tvJogos, pesos())
        linhaJogos.addView(texto("›", 20f, Neon.SUAVE))
        linhaJogos.setOnClickListener { mostrarAba(1) }
        linhaJogos.pressionar()
        auto.addView(linhaJogos)
        col.addView(auto)

        // medidores ao vivo
        col.addView(secaoNeon("Ao vivo"), lp(CHEIO, AUTO, 22, 10))
        cCpu = CartaoMetrica(this, "cpu", "CPU", Neon.CIANO, Neon.AZUL)
        cCpu.unidade = "%"
        cGpu = CartaoMetrica(this, "gpu", "GPU", Neon.LILAS, Neon.ROXO)
        cGpu.unidade = "%"
        cRam = CartaoMetrica(this, "memoria", "RAM", Neon.CIANO, Neon.AZUL)
        cRam.unidade = "%"
        cTemp = CartaoMetrica(this, "termometro", "TEMP", Neon.LILAS, Neon.ROXO)
        cTemp.unidade = "°C"
        col.addView(grade(cCpu, cGpu), lp(CHEIO, AUTO, 0, 10))
        col.addView(grade(cRam, cTemp))

        // núcleos da CPU
        val cardNuc = cartaoNeon()
        val topoNuc = horizontal()
        topoNuc.addView(texto("Núcleos da CPU", 15f, Neon.TEXTO, true), pesos())
        tvGpuAgora = texto("GPU —", 12f, Neon.CIANO, true)
        topoNuc.addView(tvGpuAgora)
        cardNuc.addView(topoNuc)
        cardNuc.addView(texto("Cada barra sobe e desce com a frequência. A seta mostra a tendência.", 11.5f, Neon.SUAVE), lp(CHEIO, AUTO, 2, 8))
        nucleos = Nucleos(this)
        cardNuc.addView(nucleos)
        col.addView(cardNuc, lp(CHEIO, AUTO, 14, 0))

        // perfil
        val perfil = cartaoNeon()
        perfil.addView(texto("Perfil de desempenho", 15f, Neon.TEXTO, true))
        segPerfil = Segmentado(this, Tuner.perfis.map { it.nome }, 11.5f, Neon.AZUL, Neon.CARTAO_B)
        segPerfil.aoEscolher = { i -> aplicar(Tuner.perfis[i].id) }
        perfil.addView(segPerfil, lp(CHEIO, AUTO, 10, 0))
        tvPerfilDesc = texto("", 12f, Neon.SUAVE)
        perfil.addView(tvPerfilDesc, lp(CHEIO, AUTO, 10, 0))
        col.addView(perfil, lp(CHEIO, AUTO, 14, 0))

        // dentro do jogo
        col.addView(secaoNeon("Dentro do jogo"), lp(CHEIO, AUTO, 22, 10))
        col.addView(
            linhaChave("Contador de FPS", "Pílula pequena sobre o jogo; toque nela para ver o gráfico e arraste para mover. Em jogos com modo seguro (como o Free Fire) fica sempre desligado.", Prefs.fpsOn(this)) { v ->
                Prefs.setFpsOn(this, v)
                if (v) pedirSobreposicao()
            },
            lp(CHEIO, AUTO, 0, 10)
        )
        col.addView(
            linhaChave("Painel dentro do jogo", "Alça na borda da tela (arraste para qualquer lado) com medidores, funções, filtros e apps rápidos. Em jogos com modo seguro (como o Free Fire) não aparece.", Prefs.painelNoJogo(this)) { v ->
                Prefs.setPainelNoJogo(this, v)
                if (v) pedirSobreposicao()
            },
            lp(CHEIO, AUTO, 0, 10)
        )
        val ov = Chave(this)
        ov.definir(Prefs.overlay(this) && Settings.canDrawOverlays(this))
        ov.aoMudar = { ligado ->
            if (ligado) {
                if (!Settings.canDrawOverlays(this)) {
                    ov.definir(false, true)
                    pedirSobreposicao()
                } else {
                    Prefs.setOverlay(this, true)
                    startService(Intent(this, OverlayService::class.java))
                }
            } else {
                Prefs.setOverlay(this, false)
                stopService(Intent(this, OverlayService::class.java))
            }
        }
        val linhaOv = horizontal()
        linhaOv.setPadding(dp(16), dp(14), dp(16), dp(14))
        linhaOv.background = degrade(Neon.CARTAO_A, Neon.CARTAO_B, 18, Neon.BORDA, 1)
        val txtOv = vertical()
        txtOv.addView(texto("Medidor flutuante", 15f, Neon.TEXTO, true))
        txtOv.addView(texto("Mini painel com CPU, temperatura e RAM, sempre visível.", 12f, Neon.SUAVE), lp(CHEIO, AUTO, 2, 0))
        linhaOv.addView(txtOv, pesos())
        linhaOv.addView(ov, LinearLayout.LayoutParams(AUTO, AUTO).apply { leftMargin = dp(12) })
        col.addView(linhaOv)

        // apps rápidos
        col.addView(secaoNeon("Apps rápidos"), lp(CHEIO, AUTO, 22, 10))
        val linhaApps = horizontal()
        linhaApps.setPadding(dp(14), dp(12), dp(14), dp(12))
        linhaApps.background = clicavel(Neon.CARTAO_A, 18, Neon.BORDA, 1)
        val txtApps = vertical()
        txtApps.addView(texto("Abrir app sem sair do jogo", 15f, Neon.TEXTO, true))
        tvAtalhos = texto("", 12f, Neon.SUAVE)
        txtApps.addView(tvAtalhos, lp(CHEIO, AUTO, 2, 0))
        linhaApps.addView(txtApps, pesos())
        linhaApps.addView(texto("›", 22f, Neon.SUAVE))
        linhaApps.setOnClickListener {
            startActivity(Intent(this, GamesActivity::class.java).putExtra("modo", "atalhos"))
        }
        linhaApps.pressionar()
        col.addView(linhaApps)
        col.addView(
            texto("Aparecem na alça do jogo, na aba Apps rápidos, em janela flutuante. O tamanho da janela se escolhe lá. Se a sua ROM não suportar, o app abre em tela cheia.", 11.5f, Neon.SUAVE),
            lp(CHEIO, AUTO, 6, 0)
        )

        // atalhos
        col.addView(secaoNeon("Atalhos"), lp(CHEIO, AUTO, 22, 10))
        col.addView(
            grade(
                atalho("Limpar RAM", "Libera memória sem fechar chamadas") { emBg { Tuner.limparRam(this, true) } },
                atalho("Smart App Killer", "Encerra apps de fundo") { emBg { Tuner.limpezaProfunda(this, null) } }
            ),
            lp(CHEIO, AUTO, 0, 10)
        )
        col.addView(
            grade(
                atalho("Limpar cache", "Apaga caches dos apps") { emBg { Tuner.limparCache() } },
                atalho("Restaurar padrão", "CPU, GPU, tela e funções") { restaurarPadrao() }
            )
        )
        return rolavel(col)
    }

    private lateinit var tvAtalhos: TextView

    // ---- jogos -------------------------------------------------------------

    private fun paginaJogos(): View {
        val col = coluna()
        col.addView(titulo("Jogos", 28f))
        col.addView(
            texto("Cada jogo tem os seus ajustes: perfil, resolução, FPS, driver, filtro de cor e funções. Toque num jogo para configurar.", 13f, Neon.SUAVE),
            lp(CHEIO, AUTO, 2, 14)
        )
        col.addView(botaoNeon("Adicionar ou remover jogos") {
            startActivity(Intent(this, GamesActivity::class.java).putExtra("modo", "jogos"))
        })
        listaJogos = vertical()
        col.addView(listaJogos, lp(CHEIO, AUTO, 16, 0))
        return rolavel(col)
    }

    private fun atualizarJogos() {
        listaJogos.removeAllViews()
        val pm = packageManager
        val itens = Prefs.jogos(this).map { pkg ->
            val nome = try {
                pm.getApplicationLabel(pm.getApplicationInfo(pkg, 0)).toString()
            } catch (e: Exception) {
                pkg
            }
            Pair(pkg, nome)
        }.sortedBy { it.second.lowercase() }
        if (itens.isEmpty()) {
            listaJogos.addView(texto("Nenhum jogo ainda. Toque em \"Adicionar ou remover jogos\" para escolher.", 13f, Neon.SUAVE))
            return
        }
        for ((pkg, nome) in itens) {
            val linha = horizontal()
            linha.setPadding(dp(14), dp(12), dp(14), dp(12))
            linha.background = clicavel(Neon.CARTAO_A, 18, Neon.BORDA, 1)
            val ic = ImageView(this)
            try {
                ic.setImageDrawable(pm.getApplicationIcon(pkg))
            } catch (e: Exception) {
                // sem ícone
            }
            linha.addView(ic, LinearLayout.LayoutParams(dp(46), dp(46)))
            val tx = vertical()
            tx.addView(texto(nome, 15f, Neon.TEXTO, true))
            tx.addView(texto(resumoJogo(pkg), 11.5f, Neon.CIANO, true), lp(CHEIO, AUTO, 2, 0))
            if (Jogos.conhecido(pkg) != null) {
                tx.addView(texto("Otimização pronta", 10.5f, Neon.OK), lp(CHEIO, AUTO, 1, 0))
            }
            linha.addView(tx, LinearLayout.LayoutParams(0, AUTO, 1f).apply { leftMargin = dp(14) })
            linha.addView(texto("›", 22f, Neon.SUAVE))
            linha.setOnClickListener {
                startActivity(Intent(this, JogoActivity::class.java).putExtra("pkg", pkg))
            }
            linha.pressionar()
            listaJogos.addView(linha, lp(CHEIO, AUTO, 0, 8))
        }
    }

    private fun resumoJogo(pkg: String): String {
        val partes = ArrayList<String>()
        partes.add(Tuner.perfis.firstOrNull { it.id == Prefs.perfilJogo(this, pkg) }?.nome ?: "Gaming")
        val fps = Prefs.fpsJogo(this, pkg)
        if (fps > 0) partes.add("$fps FPS")
        val esc = Prefs.escalaJogo(this, pkg)
        if (esc < 100) partes.add("res. $esc%")
        val filtro = Cor.preset(Prefs.filtroJogo(this, pkg))
        if (filtro != null) partes.add(filtro.nome)
        return partes.joinToString(" • ")
    }

    // ---- funções (um lugar só) ----------------------------------------------

    private fun paginaFuncoes(): View {
        val col = coluna()
        col.addView(titulo("Funções", 28f))
        col.addView(
            texto("Tudo o que o Game Turbo faz, num lugar só. As ligadas entram sozinhas quando um jogo abre. Toque no ⓘ para ver o que cada uma faz.", 13f, Neon.SUAVE),
            lp(CHEIO, AUTO, 2, 14)
        )
        for (m in Modulos.lista) col.addView(linhaFuncao(m), lp(CHEIO, AUTO, 0, 10))
        return rolavel(col)
    }

    private fun linhaFuncao(m: Modulos.Modulo): LinearLayout {
        val c = vertical()
        c.setPadding(dp(14), dp(12), dp(6), dp(10))
        c.background = degrade(Neon.CARTAO_A, Neon.CARTAO_B, 18, Neon.BORDA, 1)
        val topo = horizontal()
        topo.addView(caixaIconeNeon(m.icone), LinearLayout.LayoutParams(dp(44), dp(44)))
        val txt = vertical()
        txt.addView(texto(m.nome, 14.5f, Neon.TEXTO, true))
        txt.addView(texto(m.desc, 11.5f, Neon.SUAVE), lp(CHEIO, AUTO, 2, 0))
        topo.addView(txt, LinearLayout.LayoutParams(0, AUTO, 1f).apply { leftMargin = dp(12); rightMargin = dp(8) })
        val ch = Chave(this)
        ch.definir(Prefs.modAuto(this, m.id))
        ch.aoMudar = { v -> Prefs.setModAuto(this, m.id, v) }
        topo.addView(ch)
        topo.addView(botaoInfo { mostrarInfo(m.nome, m.info) }, LinearLayout.LayoutParams(dp(44), dp(44)))
        c.addView(topo)

        val rod = horizontal()
        rod.setPadding(0, dp(8), dp(8), 0)
        val estado = texto("", 11.5f, Neon.SUAVE, true)
        rod.addView(estado, pesos())
        val acao = texto("", 12.5f, Neon.CIANO, true)
        acao.setPadding(dp(10), dp(4), dp(4), dp(4))
        acao.setOnClickListener { alternarAgora(m) }
        rod.addView(acao)
        c.addView(rod)
        estadoFuncao[m.id] = estado
        acaoFuncao[m.id] = acao
        return c
    }

    private fun alternarAgora(m: Modulos.Modulo) {
        val ativo = Prefs.modAtivo(this, m.id)
        emBg {
            val r = if (m.reversivel && ativo) Modulos.desligar(this, m.id) else Modulos.ligar(this, m.id, null)
            r.msg
        }
    }

    private fun atualizarFuncoes() {
        for (m in Modulos.lista) {
            val tv = estadoFuncao[m.id] ?: continue
            val ativo = Prefs.modAtivo(this, m.id)
            if (!m.reversivel) {
                tv.text = "Roda uma vez ao abrir o jogo"
                tv.setTextColor(Neon.SUAVE)
            } else if (ativo) {
                tv.text = "Ativa agora"
                tv.setTextColor(Neon.OK)
            } else {
                tv.text = "Desligada agora"
                tv.setTextColor(Neon.SUAVE)
            }
            acaoFuncao[m.id]?.text = if (!m.reversivel) "Executar agora" else if (ativo) "Desligar agora" else "Ligar agora"
        }
    }

    // ---- tela --------------------------------------------------------------

    private fun paginaTela(): View {
        val col = coluna()
        col.addView(titulo("Tela", 28f))
        col.addView(
            texto("Filtros de imagem, resolução, taxa de atualização e motor gráfico.", 13f, Neon.SUAVE),
            lp(CHEIO, AUTO, 2, 14)
        )
        col.addView(FiltrosPainel(this, false) { msg -> Toast.makeText(this, msg, Toast.LENGTH_LONG).show() })

        col.addView(secaoNeon("Resolução e taxa"), lp(CHEIO, AUTO, 26, 10))
        val dpis = listOf(0, 300, 320, 360, 380, 400, 440, 480)
        val cardDpi = cartaoNeon()
        cardDpi.addView(
            cabecalho(
                "tela", "Resolução", "Ajuste a densidade da tela e a escala da interface.", "Resolução (DPI)",
                "Muda a densidade da tela (wm density). Valores menores deixam tudo menor e cabe mais coisa; valores maiores deixam tudo maior. Apps abertos podem reiniciar, então feche o jogo antes de trocar. Off devolve o valor original."
            )
        )
        passosDpi = Passos(this, listOf("Off", "300", "320", "360", "380", "400", "440", "480"))
        passosDpi.definir(dpis.indexOf(Prefs.lng(this, "dpi", 0L).toInt()).coerceAtLeast(0))
        passosDpi.aoSoltar = { i ->
            Prefs.putLng(this, "dpi", dpis[i].toLong())
            emBg { Tuner.dpi(dpis[i]) }
        }
        cardDpi.addView(passosDpi, lp(CHEIO, AUTO, 10, 0))
        cardDpi.addView(notaInfo("O DPI altera o tamanho do texto, dos ícones e de toda a interface."))
        col.addView(cardDpi)

        val taxas = listOf(0, 25, 30, 45, 60, 90, 120, 144)
        val cardTaxa = cartaoNeon()
        cardTaxa.addView(
            cabecalho(
                "atualizar", "Taxa de atualização da tela", "Defina a taxa de atualização da tela.", "Taxa de atualização",
                "Fixa a taxa de atualização mínima e máxima da tela. Só vale para taxas que a tela suporta. Libera a taxa da tela, não o FPS do jogo. Off volta ao automático."
            )
        )
        passosTaxa = Passos(this, listOf("Off", "25", "30", "45", "60", "90", "120", "144"))
        passosTaxa.definir(taxas.indexOf(Prefs.lng(this, "taxa_manual", 0L).toInt()).coerceAtLeast(0))
        passosTaxa.aoSoltar = { i ->
            Prefs.putLng(this, "taxa_manual", taxas[i].toLong())
            emBg { Tuner.taxaTela(taxas[i]) }
        }
        cardTaxa.addView(passosTaxa, lp(CHEIO, AUTO, 10, 0))
        cardTaxa.addView(notaInfo("Libera taxas de atualização da tela, não o FPS dentro do jogo."))
        col.addView(cardTaxa, lp(CHEIO, AUTO, 14, 0))

        col.addView(secaoNeon("Motor gráfico"), lp(CHEIO, AUTO, 24, 10))
        val cardHwui = cartaoNeon()
        cardHwui.addView(
            cabecalho(
                "tela", "Renderizador da interface", "Motor que desenha a interface dos apps.", "Renderizador (HWUI)",
                "Troca o motor de desenho da interface dos apps (Skia OpenGL ou Skia Vulkan). Vale para apps abertos depois da troca e não muda o motor interno dos jogos. Padrão devolve o valor do sistema. Enquanto um jogo em modo seguro está aberto, o RootBoost deixa isto no padrão e devolve depois."
            )
        )
        segHwui = Segmentado(this, listOf("Padrão", "Skia GL", "Skia Vulkan"), 12.5f, Neon.AZUL, Neon.CARTAO_B)
        segHwui.definir(Prefs.lng(this, "hwui", 0L).toInt())
        segHwui.aoEscolher = { i ->
            Prefs.putLng(this, "hwui", i.toLong())
            emBg { Tuner.renderizador(i) }
        }
        cardHwui.addView(segHwui, lp(CHEIO, AUTO, 12, 0))
        col.addView(cardHwui)

        val cardDriver = cartaoNeon()
        cardDriver.addView(
            cabecalho(
                "cpu", "Driver gráfico (todos os apps)", "Escolha o driver usado pelos apps.", "Driver gráfico",
                "Game Driver usa o driver atualizável da GPU quando o aparelho tem um. ANGLE traduz o OpenGL ES para Vulkan e pode melhorar ou piorar, dependendo do jogo. Vale ao abrir o jogo de novo. Enquanto um jogo em modo seguro está aberto, o RootBoost deixa isto no padrão e devolve depois. Para escolher só para um jogo, use a aba Jogos."
            )
        )
        segDriver = Segmentado(this, listOf("Padrão", "Game Driver", "ANGLE"), 12.5f, Neon.AZUL, Neon.CARTAO_B)
        segDriver.definir(Prefs.lng(this, "driver", 0L).toInt())
        segDriver.aoEscolher = { i ->
            Prefs.putLng(this, "driver", i.toLong())
            emBg { Tuner.driver(i) }
        }
        cardDriver.addView(segDriver, lp(CHEIO, AUTO, 12, 0))
        col.addView(cardDriver, lp(CHEIO, AUTO, 14, 0))
        return rolavel(col)
    }

    // ---- sistema -----------------------------------------------------------

    private fun paginaSistema(): View {
        val raiz = vertical()
        val col = coluna()
        col.addView(titulo("Sistema", 28f))
        col.addView(texto("CPU, GPU e ferramentas. Tudo aqui pode ser desfeito em Restaurar padrão.", 13f, Neon.SUAVE), lp(CHEIO, AUTO, 2, 14))

        col.addView(secaoNeon("CPU"), lp(CHEIO, AUTO, 4, 10))
        val gov = horizontal()
        gov.setPadding(dp(16), dp(14), dp(16), dp(14))
        gov.background = clicavel(Neon.CARTAO_A, 18, Neon.BORDA, 1)
        val blocoGov = vertical()
        blocoGov.addView(texto("Governor", 15f, Neon.TEXTO, true))
        tvGov = texto("Lendo…", 12f, Neon.CIANO, true)
        blocoGov.addView(tvGov, lp(CHEIO, AUTO, 2, 0))
        gov.addView(blocoGov, pesos())
        gov.addView(texto("›", 20f, Neon.SUAVE))
        gov.setOnClickListener { escolherGovernor() }
        gov.pressionar()
        col.addView(gov, lp(CHEIO, AUTO, 0, 10))

        passosCpuMin = Passos(this, cpuMinPct.map { "$it%" })
        passosCpuMin.definir(maisPerto(cpuMinPct, Prefs.lng(this, "cpu_min", 0L).toInt()))
        passosCpuMin.aoSoltar = { i ->
            Prefs.putLng(this, "cpu_min", cpuMinPct[i].toLong())
            aplicarCpu(null)
        }
        col.addView(blocoPassos("Frequência mínima", passosCpuMin), lp(CHEIO, AUTO, 0, 10))
        passosCpuMax = Passos(this, cpuMaxPct.map { "$it%" })
        passosCpuMax.definir(maisPerto(cpuMaxPct, Prefs.lng(this, "cpu_max", 100L).toInt()))
        passosCpuMax.aoSoltar = { i ->
            Prefs.putLng(this, "cpu_max", cpuMaxPct[i].toLong())
            aplicarCpu(null)
        }
        col.addView(blocoPassos("Frequência máxima", passosCpuMax), lp(CHEIO, AUTO, 0, 10))

        col.addView(secaoNeon("GPU Adreno"), lp(CHEIO, AUTO, 14, 10))
        col.addView(cartaoGpu(), lp(CHEIO, AUTO, 0, 10))

        col.addView(secaoNeon("Ferramentas"), lp(CHEIO, AUTO, 14, 10))
        col.addView(linhaAcao("terminal", "Terminal root", "Execute comandos como root") { mostrarTerminal() }, lp(CHEIO, AUTO, 0, 10))
        col.addView(
            linhaAcao("jogos", "Apps protegidos", "Nunca encerrados pelo Smart App Killer") {
                startActivity(Intent(this, GamesActivity::class.java).putExtra("modo", "protegidos"))
            },
            lp(CHEIO, AUTO, 0, 10)
        )
        col.addView(
            linhaAcao("raio", "Economia de bateria", "Libere o app para o Game Turbo não ser encerrado") {
                startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
            },
            lp(CHEIO, AUTO, 0, 10)
        )
        col.addView(linhaAcao("info", "Diagnóstico", "Mostra o que o app enxerga no aparelho") { mostrarDiagnostico() }, lp(CHEIO, AUTO, 0, 10))

        val sobre = cartaoNeon(16)
        sobre.addView(titulo("RootBoost 0.7.1", 18f, Neon.CIANO))
        sobre.addView(texto("Criado por", 12f, Neon.SUAVE), lp(CHEIO, AUTO, 4, 0))
        sobre.addView(texto("Diparis / MagnataZs", 15f, Neon.TEXTO, true), lp(CHEIO, AUTO, 1, 0))
        col.addView(sobre, lp(CHEIO, AUTO, 14, 0))

        raiz.addView(rolavel(col), LinearLayout.LayoutParams(CHEIO, 0, 1f))
        raiz.addView(rodapeStatus(), LinearLayout.LayoutParams(CHEIO, AUTO))
        return raiz
    }

    private fun maisPerto(lista: IntArray, v: Int): Int {
        var melhor = 0
        for (i in lista.indices) {
            if (abs(lista[i] - v) < abs(lista[melhor] - v)) melhor = i
        }
        return melhor
    }

    private fun blocoPassos(nome: String, p: Passos): LinearLayout {
        val c = cartaoNeon()
        c.addView(texto(nome, 14f, Neon.TEXTO, true))
        c.addView(p, lp(CHEIO, AUTO, 4, 0))
        return c
    }

    private fun linhaAcao(icone: String, nome: String, desc: String, aoClicar: () -> Unit): LinearLayout {
        val c = horizontal()
        c.setPadding(dp(14), dp(12), dp(14), dp(12))
        c.background = clicavel(Neon.CARTAO_A, 18, Neon.BORDA, 1)
        c.addView(caixaIconeNeon(icone), LinearLayout.LayoutParams(dp(44), dp(44)))
        val txt = vertical()
        txt.addView(texto(nome, 14.5f, Neon.TEXTO, true))
        txt.addView(texto(desc, 11.5f, Neon.SUAVE), lp(CHEIO, AUTO, 2, 0))
        c.addView(txt, LinearLayout.LayoutParams(0, AUTO, 1f).apply { leftMargin = dp(12) })
        c.addView(texto("›", 22f, Neon.SUAVE))
        c.setOnClickListener { aoClicar() }
        c.pressionar()
        return c
    }

    private fun rodapeStatus(): LinearLayout {
        val f = vertical()
        f.setBackgroundColor(0xFF0B1020.toInt())
        f.setPadding(dp(16), dp(12), dp(16), dp(12))
        val t = titulo("STATUS DO SISTEMA", 12f, Neon.CIANO)
        t.letterSpacing = 0.1f
        f.addView(t)
        val linha = LinearLayout(this)
        linha.orientation = LinearLayout.HORIZONTAL
        fun coluna(rotulo: String): TextView {
            val c = vertical()
            c.gravity = Gravity.CENTER_HORIZONTAL
            val v = texto("—", 17f, Neon.OK, true)
            c.addView(texto(rotulo, 11f, Neon.SUAVE))
            c.addView(v, lp(AUTO, AUTO, 2, 0))
            linha.addView(c, LinearLayout.LayoutParams(0, AUTO, 1f))
            return v
        }
        stCpu = coluna("Uso de CPU")
        stRam = coluna("Uso de RAM")
        stTemp = coluna("Temperatura")
        stBat = coluna("Bateria")
        f.addView(linha, lp(CHEIO, AUTO, 8, 0))
        return f
    }

    private fun cabecalho(icone: String, nome: String, desc: String, infoTitulo: String, infoTexto: String): LinearLayout {
        val l = horizontal()
        l.addView(caixaIconeNeon(icone), LinearLayout.LayoutParams(dp(44), dp(44)))
        val txt = vertical()
        txt.addView(texto(nome, 15f, Neon.TEXTO, true))
        txt.addView(texto(desc, 12f, Neon.SUAVE), lp(CHEIO, AUTO, 2, 0))
        l.addView(txt, LinearLayout.LayoutParams(0, AUTO, 1f).apply { leftMargin = dp(14); rightMargin = dp(8) })
        l.addView(botaoInfo { mostrarInfo(infoTitulo, infoTexto) }, LinearLayout.LayoutParams(dp(40), dp(40)))
        return l
    }

    // ---- ações -------------------------------------------------------------

    private fun alternarTurbo(ligado: Boolean) {
        Prefs.setTurbo(this, ligado)
        if (ligado) {
            if (Build.VERSION.SDK_INT >= 33 &&
                checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
            ) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
            if (Prefs.jogos(this).isEmpty()) {
                Toast.makeText(this, "Escolha pelo menos um jogo na aba Jogos.", Toast.LENGTH_LONG).show()
            }
            if (Prefs.painelNoJogo(this) || Prefs.fpsOn(this)) pedirSobreposicao()
            startForegroundService(Intent(this, GameService::class.java))
        } else {
            stopService(Intent(this, GameService::class.java))
        }
        mostrarTurbo()
    }

    private fun pedirSobreposicao() {
        if (Settings.canDrawOverlays(this)) return
        Toast.makeText(this, "Libere \"Sobrepor a outros apps\" para o painel e o FPS aparecerem no jogo.", Toast.LENGTH_LONG).show()
        startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
    }

    private fun aplicar(id: String) {
        Prefs.setBase(this, id)
        emBg { Tuner.aplicar(this, id) }
    }

    private fun aplicarCpu(gov: String?) {
        val mn = Prefs.lng(this, "cpu_min", 0L).toInt()
        val mx = Prefs.lng(this, "cpu_max", 100L).toInt()
        emBg { Tuner.cpuManual(this, gov, mn, mx) }
    }

    private fun restaurarPadrao() {
        Prefs.setBase(this, "equilibrado")
        Prefs.putLng(this, "cpu_min", 0L)
        Prefs.putLng(this, "cpu_max", 100L)
        Prefs.putLng(this, "taxa_manual", 0L)
        Prefs.putLng(this, "dpi", 0L)
        Cor.salvar(this, Cor.ORIGINAL)
        Prefs.putStr(this, "cor_preset", "original")
        emBg(true) {
            for (m in Modulos.lista) {
                if (m.reversivel && Prefs.modAtivo(this, m.id)) Modulos.desligar(this, m.id)
            }
            Cor.aplicar(Cor.ORIGINAL)
            Tuner.taxaTela(0)
            Tuner.dpi(0)
            Prefs.putLng(this, "gpu_modo", 0L)
            Tuner.gpuRestaurar(this)
            Tuner.aplicar(this, "equilibrado")
        }
    }

    private fun escolherGovernor() {
        if (govs.isEmpty()) {
            Toast.makeText(this, "Não consegui ler os governors (root?).", Toast.LENGTH_LONG).show()
            return
        }
        AlertDialog.Builder(this)
            .setTitle("Governor da CPU")
            .setItems(govs.toTypedArray()) { _, i -> aplicarCpu(govs[i]) }
            .show()
    }

    /** Roda o trabalho fora da tela e mostra o resultado num aviso; com recriar = true, redesenha a tela no fim. */
    private fun emBg(recriar: Boolean = false, trabalho: () -> String) {
        Thread {
            val msg = try {
                trabalho()
            } catch (e: Exception) {
                "Falhou: ${e.message}"
            }
            runOnUiThread {
                if (msg.isNotEmpty()) Toast.makeText(this, msg, Toast.LENGTH_LONG).show()
                if (recriar) recreate() else atualizarTudo()
            }
        }.start()
    }

    private fun atualizarTudo() {
        val aplicado = Prefs.aplicado(this)
        segPerfil.definir(Tuner.perfis.indexOfFirst { it.id == aplicado })
        tvPerfilDesc.text = Tuner.perfis.firstOrNull { it.id == aplicado }?.desc ?: "Ajuste manual em uso."
        atualizarGovernor()
        atualizarFuncoes()
    }

    private fun atualizarGovernor() {
        Thread {
            val info = Tuner.infoCpu()
            runOnUiThread {
                if (info != null) {
                    govs = info.govs
                    tvGov.text = info.gov + " • " + info.minMhz + "–" + info.maxMhz + " MHz"
                } else {
                    tvGov.text = "Sem leitura (root?)"
                }
            }
        }.start()
    }

    // ---- ciclo de vida e leituras ------------------------------------------

    override fun onResume() {
        super.onResume()
        tvJogos.text = "Jogos escolhidos: ${Prefs.jogos(this).size}"
        val na = Prefs.atalhos(this).size
        tvAtalhos.text = if (na == 0) "Nenhum app escolhido ainda" else "$na app(s) escolhido(s)"
        atualizarTudo()
        if (paginas[1].visibility == View.VISIBLE) atualizarJogos()
        if (Prefs.turbo(this)) startForegroundService(Intent(this, GameService::class.java))
        if (Prefs.overlay(this) && Settings.canDrawOverlays(this)) startService(Intent(this, OverlayService::class.java))
        lendo = true
        val minha = ++geracao
        Thread {
            val root = RootShell.root()
            runOnUiThread { mostrarRoot(root) }
            while (lendo && minha == geracao) {
                val s = if (root) Stats.ler() else null
                runOnUiThread { mostrarStats(s) }
                try {
                    Thread.sleep(1000)
                } catch (e: InterruptedException) {
                    break
                }
            }
        }.start()
    }

    override fun onPause() {
        lendo = false
        geracao++
        super.onPause()
    }

    private fun mostrarRoot(root: Boolean) {
        tvRoot.text = if (root) "Root ativo" else "Sem root"
        tvRoot.setTextColor(if (root) Cores.OK else Cores.ERRO)
    }

    private fun mostrarTurbo() {
        val agora = System.currentTimeMillis()
        val batida = Prefs.lng(this, "beat", 0L)
        val app = Prefs.str(this, "fg", "?")
        val emJogo = Prefs.str(this, "em_jogo", "")
        val vivo = agora - batida <= 9000L
        val (txt, cor) = when {
            !Prefs.turbo(this) -> Pair("Desligado. Ligue o switch para vigiar os jogos.", Neon.SUAVE)
            Prefs.jogos(this).isEmpty() -> Pair("Ligado, mas nenhum jogo foi escolhido.", Cores.AMBAR)
            !vivo -> Pair("Ligado, mas o serviço não está respondendo.", Cores.ERRO)
            emJogo.isNotEmpty() -> Pair("Em jogo • $emJogo", Cores.OK)
            else -> Pair("Vigiando • app atual: $app", Cores.OK)
        }
        tvTurbo.text = txt
        tvTurbo.setTextColor(cor)
        pulso.cor = cor
        pulso.invalidate()
    }

    private fun mostrarStats(s: Stats.Leitura?) {
        mostrarTurbo()
        val bat = Stats.bateria(this)
        stBat.text = if (bat >= 0) "$bat%" else "—"
        if (s == null) return
        if (s.cpuPct >= 0) {
            cCpu.definir(s.cpuPct / 100f, s.cpuPct.toString())
            stCpu.text = "${s.cpuPct}%"
        }
        nucleos.definir(s.cores, s.coresMax)
        tvGpuAgora.text = if (s.gpuMhz > 0) "Adreno • ${s.gpuMhz} MHz" else "GPU —"
        if (s.gpuPct >= 0) cGpu.definir(s.gpuPct / 100f, s.gpuPct.toString()) else cGpu.definir(0f, "—")
        val pct = if (s.ramTotalMb > 0) s.ramUsadaMb * 100 / s.ramTotalMb else 0
        cRam.definir(pct / 100f, pct.toString())
        stRam.text = "$pct%"
        stRam.setTextColor(if (pct >= 85) Cores.ERRO else Neon.OK)
        val t = s.temp
        if (t != null) {
            cTemp.definir(t / 80f, Math.round(t).toString())
            val txt = String.format(Locale.US, "%.0f °C", t)
            stTemp.text = txt
            stTemp.setTextColor(if (t >= 45f) Cores.ERRO else Neon.OK)
        }
    }

    // ---- peças de interface ------------------------------------------------

    private fun coluna(): LinearLayout {
        val c = vertical()
        c.setPadding(dp(20), dp(20), dp(20), dp(28))
        colunas.add(c)
        return c
    }

    private fun rolavel(c: View): ScrollView {
        val s = ScrollView(this)
        s.isVerticalScrollBarEnabled = false
        s.addView(c)
        return s
    }

    private fun pesos() = LinearLayout.LayoutParams(0, AUTO, 1f)

    private fun atalho(titulo: String, sub: String, aoClicar: () -> Unit): LinearLayout {
        val c = vertical()
        c.setPadding(dp(14), dp(14), dp(14), dp(14))
        c.background = clicavel(Neon.CARTAO_A, 16, Neon.BORDA, 1)
        c.addView(texto(titulo, 14f, Neon.TEXTO, true))
        c.addView(texto(sub, 11.5f, Neon.SUAVE), lp(CHEIO, AUTO, 2, 0))
        c.setOnClickListener { aoClicar() }
        c.pressionar()
        return c
    }

    private fun grade(a: View, b: View): LinearLayout {
        val l = LinearLayout(this)
        l.orientation = LinearLayout.HORIZONTAL
        l.addView(a, LinearLayout.LayoutParams(0, AUTO, 1f).apply { rightMargin = dp(5) })
        l.addView(b, LinearLayout.LayoutParams(0, AUTO, 1f).apply { leftMargin = dp(5) })
        return l
    }

    private fun notaInfo(t: String): LinearLayout {
        val l = horizontal()
        l.setPadding(0, dp(6), 0, 0)
        val ic = Icone(this, "info")
        ic.cor = Neon.SUAVE
        l.addView(ic, LinearLayout.LayoutParams(AUTO, AUTO).apply { rightMargin = dp(8) })
        l.addView(texto(t, 12f, Neon.SUAVE), pesos())
        return l
    }

    private fun linhaChave(titulo: String, sub: String, inicial: Boolean, aoMudar: (Boolean) -> Unit): LinearLayout {
        val l = horizontal()
        l.setPadding(dp(16), dp(14), dp(16), dp(14))
        l.background = forma(Neon.CARTAO_A, 18, Neon.BORDA, 1)
        val txt = vertical()
        txt.addView(texto(titulo, 15f, Neon.TEXTO, true))
        txt.addView(texto(sub, 12f, Neon.SUAVE), lp(CHEIO, AUTO, 2, 0))
        l.addView(txt, pesos())
        val ch = Chave(this)
        ch.definir(inicial)
        ch.aoMudar = aoMudar
        l.addView(ch, LinearLayout.LayoutParams(AUTO, AUTO).apply { leftMargin = dp(12) })
        return l
    }

    private fun mostrarTerminal() {
        val c = vertical()
        c.setPadding(dp(20), dp(8), dp(20), dp(8))
        val campo = EditText(this)
        campo.hint = "comando (ex.: cat /proc/version)"
        campo.setHintTextColor(Neon.SUAVE)
        campo.setTextColor(Neon.TEXTO)
        campo.typeface = Typeface.MONOSPACE
        campo.textSize = 13f
        campo.isSingleLine = true
        campo.setPadding(dp(12), dp(10), dp(12), dp(10))
        campo.background = forma(Neon.CARTAO_A, 12)
        c.addView(campo)
        val saida = TextView(this)
        saida.typeface = Typeface.MONOSPACE
        saida.textSize = 11f
        saida.setTextColor(Neon.TEXTO)
        saida.setTextIsSelectable(true)
        val sv = ScrollView(this)
        sv.addView(saida)
        c.addView(sv, LinearLayout.LayoutParams(CHEIO, dp(220)).apply { topMargin = dp(10) })
        val d = AlertDialog.Builder(this)
            .setTitle("Terminal root")
            .setView(c)
            .setPositiveButton("Executar", null)
            .setNegativeButton("Fechar", null)
            .create()
        d.show()
        d.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
            val cmd = campo.text.toString().trim()
            if (cmd.isNotEmpty()) {
                saida.text = "Executando…"
                Thread {
                    val r = Tuner.terminal(cmd)
                    runOnUiThread { saida.text = r }
                }.start()
            }
        }
    }

    private fun mostrarDiagnostico() {
        Toast.makeText(this, "Coletando…", Toast.LENGTH_SHORT).show()
        Thread {
            val txt = Tuner.diagnostico(this)
            runOnUiThread {
                val tv = TextView(this)
                tv.text = txt
                tv.textSize = 11f
                tv.typeface = Typeface.MONOSPACE
                tv.setTextColor(Neon.TEXTO)
                tv.setTextIsSelectable(true)
                tv.setPadding(dp(20), dp(12), dp(20), dp(12))
                val sv = ScrollView(this)
                sv.addView(tv)
                AlertDialog.Builder(this)
                    .setTitle("Diagnóstico")
                    .setView(sv)
                    .setPositiveButton("Copiar") { _, _ ->
                        val cm = getSystemService(ClipboardManager::class.java)
                        cm.setPrimaryClip(ClipData.newPlainText("diagnostico", txt))
                        Toast.makeText(this, "Copiado.", Toast.LENGTH_SHORT).show()
                    }
                    .setNegativeButton("Fechar", null)
                    .show()
            }
        }.start()
    }

    private fun mostrarInfo(titulo: String, texto: String) {
        AlertDialog.Builder(this)
            .setTitle(titulo)
            .setMessage(texto)
            .setPositiveButton("Entendi", null)
            .show()
    }

    /** Controles da GPU Adreno lidos do kernel: governor, frequência mínima/máxima e Adreno Boost. */
    private fun cartaoGpu(): LinearLayout {
        val c = cartaoNeon()
        val topo = horizontal()
        topo.addView(caixaIconeNeon("cpu"), LinearLayout.LayoutParams(dp(46), dp(46)))
        val tx = vertical()
        val tvModelo = texto("Lendo a GPU…", 15f, Neon.TEXTO, true)
        tx.addView(tvModelo)
        val tvDet = texto("", 12f, Neon.SUAVE)
        tx.addView(tvDet, lp(CHEIO, AUTO, 2, 0))
        topo.addView(tx, LinearLayout.LayoutParams(0, AUTO, 1f).apply { leftMargin = dp(14) })
        c.addView(topo)

        val corpo = vertical()
        c.addView(corpo, lp(CHEIO, AUTO, 8, 0))

        Thread {
            val g = Tuner.infoGpu()
            runOnUiThread {
                if (g == null || g.freqsHz.isEmpty()) {
                    tvModelo.text = "GPU não encontrada"
                    tvDet.text = "Precisa de root e de um kernel que exponha a GPU em /sys."
                    return@runOnUiThread
                }
                val mhz = g.freqsHz.map { (it / 1_000_000L).toInt() }
                tvModelo.text = g.modelo.ifBlank { "GPU Adreno" }
                tvDet.text = "${g.gov} • ${mhz.first()}–${mhz.last()} MHz • ${mhz.size} níveis"

                val idxMin0 = g.freqsHz.indexOfFirst { it >= g.minHz }.coerceAtLeast(0)
                val idxMax0 = g.freqsHz.indexOfLast { it <= g.maxHz }.let { if (it < 0) g.freqsHz.size - 1 else it }
                var gov: String? = null

                val linhaGov = horizontal()
                linhaGov.setPadding(dp(14), dp(12), dp(14), dp(12))
                linhaGov.background = clicavel(Neon.CARTAO_A, 14)
                val tvGov = texto(g.gov, 12.5f, Neon.CIANO, true)
                val bl = vertical()
                bl.addView(texto("Governor da GPU", 14f, Neon.TEXTO, true))
                bl.addView(tvGov, lp(CHEIO, AUTO, 2, 0))
                linhaGov.addView(bl, pesos())
                linhaGov.addView(texto("›", 20f, Neon.SUAVE))
                linhaGov.setOnClickListener {
                    AlertDialog.Builder(this)
                        .setTitle("Governor da GPU")
                        .setItems(g.govs.toTypedArray()) { _, i ->
                            gov = g.govs[i]
                            tvGov.text = g.govs[i]
                            val mn = g.freqsHz[Prefs.lng(this, "gpu_idx_min", idxMin0.toLong()).toInt().coerceIn(0, g.freqsHz.size - 1)]
                            val mx = g.freqsHz[Prefs.lng(this, "gpu_idx_max", idxMax0.toLong()).toInt().coerceIn(0, g.freqsHz.size - 1)]
                            emBg { Tuner.gpuManual(this, gov, mn, mx) }
                        }
                        .show()
                }
                linhaGov.pressionar()
                corpo.addView(linhaGov, lp(CHEIO, AUTO, 0, 4))

                val ult = g.freqsHz.size - 1
                val salvoMin = Prefs.lng(this, "gpu_idx_min", idxMin0.toLong()).toInt().coerceIn(0, ult)
                val salvoMax = Prefs.lng(this, "gpu_idx_max", idxMax0.toLong()).toInt().coerceIn(0, ult)
                var barMin: SeekBar? = null
                var barMax: SeekBar? = null
                fun enviar() {
                    val a = (barMin?.progress ?: 0).coerceIn(0, ult)
                    var b = (barMax?.progress ?: ult).coerceIn(0, ult)
                    if (b < a) b = a
                    Prefs.putLng(this, "gpu_idx_min", a.toLong())
                    Prefs.putLng(this, "gpu_idx_max", b.toLong())
                    Prefs.putLng(this, "gpu_modo", 0L)
                    emBg { Tuner.gpuManual(this, gov, g.freqsHz[a], g.freqsHz[b]) }
                }
                val sMin = slider("Frequência mínima", 0, ult, salvoMin, true, { p -> "${mhz[p.coerceIn(0, ult)]} MHz" }) { enviar() }
                val sMax = slider("Frequência máxima", 0, ult, salvoMax, true, { p -> "${mhz[p.coerceIn(0, ult)]} MHz" }) { enviar() }
                barMin = sMin.second
                barMax = sMax.second
                corpo.addView(sMin.first)
                corpo.addView(sMax.first)

                if (g.boost >= 0) {
                    corpo.addView(texto("Adreno Boost", 14f, Neon.TEXTO, true), lp(CHEIO, AUTO, 14, 6))
                    val segBoost = Segmentado(this, listOf("Off", "1", "2", "3"), 12.5f, Neon.ROXO, Neon.CARTAO_B)
                    segBoost.definir(g.boost.coerceIn(0, 3))
                    segBoost.aoEscolher = { i -> emBg { Tuner.adrenoBoost(i) } }
                    corpo.addView(segBoost)
                } else {
                    corpo.addView(notaInfo("O kernel deste aparelho não expõe o Adreno Boost."), lp(CHEIO, AUTO, 10, 0))
                }
                val restaurar = texto("Restaurar GPU", 14f, Neon.CIANO, true)
                restaurar.setPadding(0, dp(14), 0, dp(2))
                restaurar.setOnClickListener {
                    Prefs.putLng(this, "gpu_idx_min", 0L)
                    Prefs.putLng(this, "gpu_idx_max", ult.toLong())
                    barMin?.progress = 0
                    barMax?.progress = ult
                    emBg { Tuner.gpuRestaurar(this) }
                }
                corpo.addView(restaurar)
            }
        }.start()
        return c
    }

    private fun slider(
        titulo: String, min: Int, max: Int, inicial: Int, embutido: Boolean,
        formato: (Int) -> String, aoSoltar: (Int) -> Unit
    ): Pair<LinearLayout, SeekBar> {
        val c = vertical()
        if (embutido) {
            c.setPadding(0, dp(12), 0, dp(2))
        } else {
            c.setPadding(dp(16), dp(14), dp(16), dp(10))
            c.background = forma(Neon.CARTAO_A, 18, Neon.BORDA, 1)
        }
        val topo = horizontal()
        topo.addView(texto(titulo, 14f, Neon.TEXTO, true), pesos())
        val valor = texto(formato(inicial), 13f, Neon.CIANO, true)
        topo.addView(valor)
        c.addView(topo)
        val barra = SeekBar(this)
        barra.max = max - min
        barra.progress = (inicial - min).coerceIn(0, max - min)
        barra.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, doUsuario: Boolean) { valor.text = formato(p + min) }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) { aoSoltar((s?.progress ?: 0) + min) }
        })
        c.addView(barra, lp(CHEIO, AUTO, 6, 0))
        return Pair(c, barra)
    }
}
