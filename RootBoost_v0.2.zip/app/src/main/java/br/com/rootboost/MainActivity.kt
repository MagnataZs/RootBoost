package br.com.rootboost

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Typeface
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import java.util.Locale

class MainActivity : Activity() {

    private lateinit var paginasRaiz: FrameLayout
    private val paginas = ArrayList<View>()
    private val colunas = ArrayList<LinearLayout>()
    private val abaIcones = ArrayList<Icone>()
    private val abaTextos = ArrayList<TextView>()

    // início
    private lateinit var tvRoot: TextView
    private lateinit var tvTurbo: TextView
    private lateinit var tvJogos: TextView
    private lateinit var pulso: Pulso
    private lateinit var gCpu: Grafico
    private lateinit var gGpu: Grafico
    private lateinit var gRam: Grafico
    private lateinit var gTemp: Grafico
    private lateinit var segPerfil: Segmentado
    private lateinit var tvPerfilDesc: TextView
    private lateinit var nucleos: Nucleos
    private lateinit var tvGpuAgora: TextView
    private lateinit var tvAtalhos: TextView
    private val caixasInicio = HashMap<String, Caixinha>()
    private val idsCaixas = listOf("chamadas", "gpu", "cpuboost", "antiqueda", "readahead", "animacoes", "taxa", "toque")

    // jogos
    private lateinit var listaJogos: LinearLayout

    // desempenho
    private lateinit var tvGov: TextView
    private var govs: List<String> = emptyList()
    private lateinit var passosDpi: Passos
    private lateinit var passosTaxa: Passos
    private lateinit var barraCpuMin: SeekBar
    private lateinit var barraCpuMax: SeekBar

    // gráficos
    private val chipsPreset = HashMap<String, LinearLayout>()
    private val barrasCor = ArrayList<SeekBar>()
    private val minCor = intArrayOf(50, 70, -20, 70, 70, 70)
    private lateinit var segHwui: Segmentado
    private lateinit var segDriver: Segmentado

    // avançado
    private val statusAvancado = HashMap<String, TextView>()
    private lateinit var stCpu: TextView
    private lateinit var stRam: TextView
    private lateinit var stTemp: TextView
    private lateinit var stBat: TextView

    @Volatile private var lendo = false
    @Volatile private var geracao = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val raiz = LinearLayout(this)
        raiz.orientation = LinearLayout.VERTICAL
        raiz.setBackgroundColor(Cores.FUNDO)
        paginasRaiz = FrameLayout(this)
        raiz.addView(paginasRaiz, LinearLayout.LayoutParams(CHEIO, 0, 1f))
        raiz.addView(barraInferior(), LinearLayout.LayoutParams(CHEIO, AUTO))
        aplicarInsets(raiz)
        setContentView(raiz)

        paginas.add(paginaInicio())
        paginas.add(paginaJogos())
        paginas.add(paginaDesempenho())
        paginas.add(paginaGraficos())
        paginas.add(paginaAvancado())
        for (p in paginas) paginasRaiz.addView(p, FrameLayout.LayoutParams(CHEIO, CHEIO))
        mostrarAba(0)
    }

    // ---- navegação ---------------------------------------------------------

    private fun barraInferior(): View {
        val barra = LinearLayout(this)
        barra.orientation = LinearLayout.HORIZONTAL
        barra.setBackgroundColor(Cores.SUPERFICIE)
        val nomes = listOf("Início", "Jogos", "Desempenho", "Gráficos", "Avançado")
        val tipos = listOf("inicio", "jogos", "cpu", "cor", "ajustes")
        for (i in nomes.indices) {
            val item = LinearLayout(this)
            item.orientation = LinearLayout.VERTICAL
            item.gravity = Gravity.CENTER_HORIZONTAL
            item.setPadding(0, dp(10), 0, dp(10))
            val ic = Icone(this, tipos[i])
            val tv = texto(nomes[i], 10.5f, Cores.SUAVE, true)
            item.addView(ic, LinearLayout.LayoutParams(AUTO, AUTO))
            item.addView(tv, lp(AUTO, AUTO, 2, 0))
            item.setOnClickListener { mostrarAba(i) }
            abaIcones.add(ic)
            abaTextos.add(tv)
            barra.addView(item, LinearLayout.LayoutParams(0, AUTO, 1f))
        }
        return barra
    }

    private fun mostrarAba(i: Int) {
        for (k in paginas.indices) paginas[k].visibility = if (k == i) View.VISIBLE else View.GONE
        for (k in abaIcones.indices) {
            val cor = if (k == i) Cores.ACENTO else Cores.SUAVE
            abaIcones[k].cor = cor
            abaTextos[k].setTextColor(cor)
        }
        if (i == 1) atualizarJogos()
        if (i == 4) atualizarAvancado()
        paginas[i].alpha = 0f
        paginas[i].animate().alpha(1f).setDuration(180).start()
        entrada(colunas[i])
    }

    // ---- início ------------------------------------------------------------

    private fun paginaInicio(): View {
        val col = coluna()

        val topo = horizontal()
        topo.addView(texto("Game Turbo", 28f, Cores.TEXTO, true), pesos())
        tvRoot = texto("Verificando…", 12f, Cores.SUAVE, true)
        tvRoot.setPadding(dp(12), dp(6), dp(12), dp(6))
        tvRoot.background = forma(Cores.SUPERFICIE, 20, Cores.LINHA, 1)
        topo.addView(tvRoot)
        col.addView(topo, lp(CHEIO, AUTO, 0, 16))

        // modo automático
        val auto = cartao()
        val l1 = horizontal()
        val bloco = vertical()
        bloco.addView(texto("Modo automático", 17f, Cores.TEXTO, true))
        bloco.addView(
            texto("Aplica o perfil do jogo e os módulos ligados quando um jogo da lista abre. Ao sair, tudo volta ao normal.", 12f, Cores.SUAVE),
            lp(CHEIO, AUTO, 4, 0)
        )
        l1.addView(bloco, pesos())
        val chTurbo = Chave(this)
        chTurbo.definir(Prefs.turbo(this))
        chTurbo.aoMudar = { ligado -> alternarTurbo(ligado) }
        l1.addView(chTurbo, LinearLayout.LayoutParams(AUTO, AUTO).apply { leftMargin = dp(12) })
        auto.addView(l1)
        val estado = horizontal()
        pulso = Pulso(this)
        estado.addView(pulso, LinearLayout.LayoutParams(AUTO, AUTO).apply { rightMargin = dp(8) })
        tvTurbo = texto("", 12f, Cores.ACENTO, true)
        estado.addView(tvTurbo, pesos())
        auto.addView(estado, lp(CHEIO, AUTO, 10, 12))
        val linhaJogos = horizontal()
        linhaJogos.setPadding(dp(14), dp(12), dp(14), dp(12))
        linhaJogos.background = clicavel(Cores.SUPERFICIE2, 12)
        tvJogos = texto("", 14f)
        linhaJogos.addView(tvJogos, pesos())
        linhaJogos.addView(texto("›", 20f, Cores.SUAVE))
        linhaJogos.setOnClickListener { mostrarAba(1) }
        linhaJogos.pressionar()
        auto.addView(linhaJogos)
        col.addView(auto)

        // monitor ao vivo
        val mon = cartao()
        mon.addView(texto("Monitor ao vivo", 15f, Cores.TEXTO, true))
        gCpu = grafico("CPU", Cores.ACENTO, 100f)
        gGpu = grafico("GPU", Cores.AMBAR, 100f)
        gRam = grafico("RAM", Cores.AZUL, 100f)
        gTemp = grafico("Temperatura", Cores.OK, 80f)
        mon.addView(grade(gCpu, gGpu), lp(CHEIO, AUTO, 10, 10))
        mon.addView(grade(gRam, gTemp))
        col.addView(mon, lp(CHEIO, AUTO, 14, 0))

        // núcleos da CPU em tempo real
        val cardNuc = cartao()
        val topoNuc = horizontal()
        topoNuc.addView(texto("Núcleos da CPU", 15f, Cores.TEXTO, true), pesos())
        tvGpuAgora = texto("GPU —", 12f, Cores.ACENTO, true)
        topoNuc.addView(tvGpuAgora)
        cardNuc.addView(topoNuc)
        cardNuc.addView(texto("Cada barra sobe e desce com a frequência. A seta mostra a tendência.", 11.5f, Cores.SUAVE), lp(CHEIO, AUTO, 2, 8))
        nucleos = Nucleos(this)
        cardNuc.addView(nucleos)
        col.addView(cardNuc, lp(CHEIO, AUTO, 14, 0))

        // funções do Game Turbo em caixinhas
        col.addView(secaoLinha("Funções do Game Turbo"), lp(CHEIO, AUTO, 22, 10))
        col.addView(texto("Toque para ligar ou desligar. As ligadas entram sozinhas quando um jogo abre.", 12f, Cores.SUAVE), lp(CHEIO, AUTO, 0, 10))
        var linhaCx: LinearLayout? = null
        for (i in idsCaixas.indices) {
            val m = modulo(idsCaixas[i])
            if (i % 2 == 0) {
                val l = LinearLayout(this)
                l.orientation = LinearLayout.HORIZONTAL
                linhaCx = l
                col.addView(l, lp(CHEIO, AUTO, 0, 10))
            }
            val cx = Caixinha(this, m.icone, m.nome)
            cx.definir(Prefs.modAuto(this, m.id), if (Prefs.modAuto(this, m.id)) "Entra ao abrir jogo" else "Desligado", false)
            cx.aoToque = {
                val novo = !Prefs.modAuto(this, m.id)
                Prefs.setModAuto(this, m.id, novo)
                cx.definir(novo, if (novo) "Entra ao abrir jogo" else "Desligado")
            }
            caixasInicio[m.id] = cx
            linhaCx?.addView(cx, LinearLayout.LayoutParams(0, AUTO, 1f).apply { if (i % 2 == 0) rightMargin = dp(10) })
        }

        // perfil
        val perfil = cartao()
        perfil.addView(texto("Perfil", 15f, Cores.TEXTO, true))
        segPerfil = Segmentado(this, Tuner.perfis.map { it.nome }, 11.5f)
        segPerfil.aoEscolher = { i -> aplicar(Tuner.perfis[i].id) }
        perfil.addView(segPerfil, lp(CHEIO, AUTO, 10, 0))
        tvPerfilDesc = texto("", 12f, Cores.SUAVE)
        perfil.addView(tvPerfilDesc, lp(CHEIO, AUTO, 10, 0))
        col.addView(perfil, lp(CHEIO, AUTO, 14, 0))

        // dentro do jogo
        col.addView(secaoLinha("Dentro do jogo"), lp(CHEIO, AUTO, 22, 10))
        col.addView(
            linhaChave("Contador de FPS", "Pílula pequena sobre o jogo; toque nela para ver o gráfico. Desligado por padrão no Free Fire.", Prefs.fpsOn(this)) { v ->
                Prefs.setFpsOn(this, v)
                if (v) pedirSobreposicao()
            },
            lp(CHEIO, AUTO, 0, 10)
        )
        col.addView(
            linhaChave("Painel dentro do jogo", "Alça na borda da tela com medidores, núcleos, perfis, módulos e apps rápidos. Desligada por padrão no Free Fire.", Prefs.painelNoJogo(this)) { v ->
                Prefs.setPainelNoJogo(this, v)
                if (v) pedirSobreposicao()
            },
            lp(CHEIO, AUTO, 0, 10)
        )
        val ov = Chave(this)
        ov.definir(Prefs.overlay(this) && Settings.canDrawOverlays(this))
        ov.aoMudar = { ligado ->
            if (ligado) {
                if (!Settings.canDrawOverlays(this)) {
                    ov.definir(false, true)
                    pedirSobreposicao()
                } else {
                    Prefs.setOverlay(this, true)
                    startService(Intent(this, OverlayService::class.java))
                }
            } else {
                Prefs.setOverlay(this, false)
                stopService(Intent(this, OverlayService::class.java))
            }
        }
        val linhaOv = horizontal()
        linhaOv.setPadding(dp(16), dp(14), dp(16), dp(14))
        linhaOv.background = forma(Cores.SUPERFICIE, 18, Cores.LINHA, 1)
        val txtOv = vertical()
        txtOv.addView(texto("Medidor flutuante", 15f, Cores.TEXTO, true))
        txtOv.addView(texto("Mini painel com CPU, temperatura e RAM, sempre visível.", 12f, Cores.SUAVE), lp(CHEIO, AUTO, 2, 0))
        linhaOv.addView(txtOv, pesos())
        linhaOv.addView(ov, LinearLayout.LayoutParams(AUTO, AUTO).apply { leftMargin = dp(12) })
        col.addView(linhaOv)

        // apps rápidos (janela flutuante)
        col.addView(secaoLinha("Apps rápidos"), lp(CHEIO, AUTO, 22, 10))
        val linhaApps = horizontal()
        linhaApps.setPadding(dp(14), dp(12), dp(14), dp(12))
        linhaApps.background = clicavel(Cores.SUPERFICIE, 18, Cores.LINHA, 1)
        val txtApps = vertical()
        txtApps.addView(texto("Abrir app sem sair do jogo", 15f, Cores.TEXTO, true))
        tvAtalhos = texto("", 12f, Cores.SUAVE)
        txtApps.addView(tvAtalhos, lp(CHEIO, AUTO, 2, 0))
        linhaApps.addView(txtApps, pesos())
        linhaApps.addView(texto("›", 22f, Cores.SUAVE))
        linhaApps.setOnClickListener {
            startActivity(Intent(this, GamesActivity::class.java).putExtra("modo", "atalhos"))
        }
        linhaApps.pressionar()
        col.addView(linhaApps)
        col.addView(
            texto("Aparecem na alça do jogo, na aba de janelas. Usa janela flutuante do Android; se a sua ROM não suportar, o app abre em tela cheia.", 11.5f, Cores.SUAVE),
            lp(CHEIO, AUTO, 6, 0)
        )

        // atalhos
        col.addView(secaoLinha("Atalhos"), lp(CHEIO, AUTO, 22, 10))
        col.addView(
            grade(
                atalho("Limpar RAM", "Libera memória sem fechar chamadas") { emBg { Tuner.limparRam(this, true) } },
                atalho("Smart App Killer", "Encerra apps de fundo") { emBg { Tuner.limpezaProfunda(this, null) } }
            ),
            lp(CHEIO, AUTO, 0, 10)
        )
        col.addView(
            grade(
                atalho("Limpar cache", "Apaga caches dos apps") { emBg { Tuner.limparCache() } },
                atalho("Restaurar padrão", "CPU, GPU, tela e módulos") { restaurarPadrao() }
            )
        )
        return rolavel(col)
    }

    private fun paginaJogos(): View {
        val col = coluna()
        col.addView(texto("Jogos", 28f, Cores.TEXTO, true))
        col.addView(texto("Cada jogo pode ter o seu perfil. Toque num jogo para trocar.", 13f, Cores.SUAVE), lp(CHEIO, AUTO, 4, 16))
        col.addView(botao("Adicionar ou remover jogos") {
            startActivity(Intent(this, GamesActivity::class.java).putExtra("modo", "jogos"))
        })
        listaJogos = vertical()
        col.addView(listaJogos, lp(CHEIO, AUTO, 16, 0))
        return rolavel(col)
    }

    private fun atualizarJogos() {
        listaJogos.removeAllViews()
        val pm = packageManager
        val itens = Prefs.jogos(this).map { pkg ->
            val nome = try {
                pm.getApplicationLabel(pm.getApplicationInfo(pkg, 0)).toString()
            } catch (e: Exception) {
                pkg
            }
            Pair(pkg, nome)
        }.sortedBy { it.second.lowercase() }
        if (itens.isEmpty()) {
            listaJogos.addView(texto("Nenhum jogo ainda. Toque em \"Adicionar ou remover jogos\" para escolher.", 13f, Cores.SUAVE))
            return
        }
        for ((pkg, nome) in itens) {
            val linha = horizontal()
            linha.setPadding(dp(14), dp(12), dp(14), dp(12))
            linha.background = clicavel(Cores.SUPERFICIE, 16, Cores.LINHA, 1)
            val ic = ImageView(this)
            try {
                ic.setImageDrawable(pm.getApplicationIcon(pkg))
            } catch (e: Exception) {
                // sem ícone
            }
            linha.addView(ic, LinearLayout.LayoutParams(dp(44), dp(44)))
            val tx = vertical()
            tx.addView(texto(nome, 15f, Cores.TEXTO, true))
            val nomePerfil = Tuner.perfis.firstOrNull { it.id == Prefs.perfilJogo(this, pkg) }?.nome ?: "Gaming"
            tx.addView(texto("Perfil: $nomePerfil", 12f, Cores.ACENTO, true), lp(CHEIO, AUTO, 2, 0))
            linha.addView(tx, LinearLayout.LayoutParams(0, AUTO, 1f).apply { leftMargin = dp(14) })
            linha.addView(texto("›", 20f, Cores.SUAVE))
            linha.setOnClickListener { escolherPerfilJogo(pkg, nome) }
            linha.pressionar()
            listaJogos.addView(linha, lp(CHEIO, AUTO, 0, 8))
        }
    }

    private fun escolherPerfilJogo(pkg: String, nome: String) {
        val nomes = Tuner.perfis.map { it.nome }.toTypedArray()
        val atual = Tuner.perfis.indexOfFirst { it.id == Prefs.perfilJogo(this, pkg) }.coerceAtLeast(0)
        AlertDialog.Builder(this)
            .setTitle(nome)
            .setSingleChoiceItems(nomes, atual) { d, i ->
                Prefs.setPerfilJogo(this, pkg, Tuner.perfis[i].id)
                d.dismiss()
                atualizarJogos()
            }
            .setNeutralButton(
                if (Prefs.semOverlay(this, pkg)) "Overlay: desligado" else "Overlay: ligado"
            ) { _, _ ->
                Prefs.setSemOverlay(this, pkg, !Prefs.semOverlay(this, pkg))
                Toast.makeText(
                    this,
                    if (Prefs.semOverlay(this, pkg)) "Nada será desenhado por cima de $nome." else "FPS e painel voltam a aparecer em $nome.",
                    Toast.LENGTH_LONG
                ).show()
            }
            .setNegativeButton("Remover da lista") { _, _ ->
                val s = HashSet<String>(Prefs.jogos(this))
                s.remove(pkg)
                Prefs.setJogos(this, s)
                atualizarJogos()
                tvJogos.text = "Jogos escolhidos: ${s.size}"
            }
            .show()
    }

    // ---- desempenho --------------------------------------------------------

    private fun paginaDesempenho(): View {
        val col = coluna()
        col.addView(texto("Desempenho", 28f, Cores.TEXTO, true))
        col.addView(
            texto("Ajustes de tela e sistema. Os módulos ligados entram sozinhos ao abrir um jogo.", 13f, Cores.SUAVE),
            lp(CHEIO, AUTO, 4, 14)
        )

        val dpis = listOf(0, 300, 320, 360, 380, 400, 440, 480)
        val cardDpi = cartao()
        cardDpi.addView(
            cabecalho(
                "tela", "Resolução", "Ajuste a densidade da tela e a escala da interface.", "Resolução (DPI)",
                "Muda a densidade da tela (wm density). Valores menores deixam tudo menor e cabe mais coisa; valores maiores deixam tudo maior. Apps abertos podem reiniciar, então feche o jogo antes de trocar. Off devolve o valor original."
            )
        )
        passosDpi = Passos(this, listOf("Off", "300", "320", "360", "380", "400", "440", "480"))
        passosDpi.definir(dpis.indexOf(Prefs.lng(this, "dpi", 0L).toInt()))
        passosDpi.aoSoltar = { i ->
            Prefs.putLng(this, "dpi", dpis[i].toLong())
            emBg { Tuner.dpi(dpis[i]) }
        }
        cardDpi.addView(passosDpi, lp(CHEIO, AUTO, 10, 0))
        cardDpi.addView(notaInfo("O DPI altera o tamanho do texto, dos ícones e de toda a interface."))
        col.addView(cardDpi)

        val taxas = listOf(0, 25, 30, 45, 60, 90, 120, 144)
        val cardTaxa = cartao()
        cardTaxa.addView(
            cabecalho(
                "atualizar", "Taxa de atualização da tela", "Defina a taxa de atualização da tela.", "Taxa de atualização",
                "Fixa a taxa de atualização mínima e máxima da tela. Só vale para taxas que a tela suporta. Libera a taxa da tela, não o FPS do jogo. Off volta ao automático."
            )
        )
        passosTaxa = Passos(this, listOf("Off", "25", "30", "45", "60", "90", "120", "144"))
        passosTaxa.definir(taxas.indexOf(Prefs.lng(this, "taxa_manual", 0L).toInt()))
        passosTaxa.aoSoltar = { i ->
            Prefs.putLng(this, "taxa_manual", taxas[i].toLong())
            emBg { Tuner.taxaTela(taxas[i]) }
        }
        cardTaxa.addView(passosTaxa, lp(CHEIO, AUTO, 10, 0))
        cardTaxa.addView(notaInfo("Libera taxas de atualização da tela, não o FPS dentro do jogo."))
        col.addView(cardTaxa, lp(CHEIO, AUTO, 14, 0))

        col.addView(secaoLinha("Melhoria de desempenho"), lp(CHEIO, AUTO, 22, 10))
        for (id in listOf("animacoes", "ram", "cpuboost", "taxa", "io", "antiqueda", "readahead", "headsup", "brilho", "chamadas")) {
            val m = Modulos.lista.firstOrNull { it.id == id } ?: continue
            col.addView(linhaRecurso(m), lp(CHEIO, AUTO, 0, 10))
        }

        col.addView(secaoLinha("GPU Adreno"), lp(CHEIO, AUTO, 14, 10))
        col.addView(linhaRecurso(modulo("gpu")), lp(CHEIO, AUTO, 0, 10))
        col.addView(cartaoGpu(), lp(CHEIO, AUTO, 0, 10))

        col.addView(secaoLinha("CPU"), lp(CHEIO, AUTO, 14, 10))
        val gov = horizontal()
        gov.setPadding(dp(16), dp(14), dp(16), dp(14))
        gov.background = clicavel(Cores.SUPERFICIE, 18, Cores.LINHA, 1)
        val blocoGov = vertical()
        blocoGov.addView(texto("Governor", 15f, Cores.TEXTO, true))
        tvGov = texto("Lendo…", 12f, Cores.ACENTO, true)
        blocoGov.addView(tvGov, lp(CHEIO, AUTO, 2, 0))
        gov.addView(blocoGov, pesos())
        gov.addView(texto("›", 20f, Cores.SUAVE))
        gov.setOnClickListener { escolherGovernor() }
        gov.pressionar()
        col.addView(gov, lp(CHEIO, AUTO, 0, 10))
        val sMin = slider("Frequência mínima", 0, 100, Prefs.lng(this, "cpu_min", 0L).toInt(), false, { p -> "$p%" }) { p ->
            Prefs.putLng(this, "cpu_min", p.toLong())
            aplicarCpu(null)
        }
        barraCpuMin = sMin.second
        col.addView(sMin.first, lp(CHEIO, AUTO, 0, 10))
        val sMax = slider("Frequência máxima", 30, 100, Prefs.lng(this, "cpu_max", 100L).toInt(), false, { p -> "$p%" }) { p ->
            Prefs.putLng(this, "cpu_max", p.toLong())
            aplicarCpu(null)
        }
        barraCpuMax = sMax.second
        col.addView(sMax.first, lp(CHEIO, AUTO, 0, 10))

        val rt = horizontal()
        rt.setPadding(dp(14), dp(14), dp(14), dp(14))
        rt.background = forma(Cores.SUPERFICIE, 18, Cores.LINHA, 1)
        rt.addView(caixaIcone("raio"), LinearLayout.LayoutParams(dp(46), dp(46)))
        val rtTxt = vertical()
        rtTxt.addView(texto("Controle em tempo real", 15f, Cores.TEXTO, true))
        rtTxt.addView(
            texto("As configurações entram enquanto o jogo roda e saem quando você fecha o jogo.", 12f, Cores.SUAVE),
            lp(CHEIO, AUTO, 2, 0)
        )
        rt.addView(rtTxt, LinearLayout.LayoutParams(0, AUTO, 1f).apply { leftMargin = dp(14) })
        col.addView(rt, lp(CHEIO, AUTO, 8, 0))
        return rolavel(col)
    }

    // ---- gráficos ----------------------------------------------------------

    private fun paginaGraficos(): View {
        val col = coluna()
        col.addView(texto("Gráficos", 28f, Cores.TEXTO, true))
        col.addView(
            texto("Cores, shaders e motor de desenho. Algumas opções dependem do aparelho.", 13f, Cores.SUAVE),
            lp(CHEIO, AUTO, 4, 14)
        )

        col.addView(secaoLinha("Cores e shaders"), lp(CHEIO, AUTO, 4, 10))
        val cartaoCor = cartao()
        cartaoCor.addView(
            cabecalho(
                "cor", "Cores e shaders", "Escolha um shader pronto ou ajuste do seu jeito.", "Cores e shaders",
                "Os shaders são combinações prontas de saturação, contraste, brilho e cores. As barras abaixo ajustam cada parte. As mudanças aparecem na hora; com \"Aplicar só durante o jogo\" ligado, o perfil entra ao abrir o jogo e sai ao fechar."
            )
        )
        val chips = horizontal()
        for (p in Cor.presets) {
            chips.addView(chip(p), LinearLayout.LayoutParams(AUTO, AUTO).apply { rightMargin = dp(8) })
        }
        val rolH = HorizontalScrollView(this)
        rolH.isHorizontalScrollBarEnabled = false
        rolH.addView(chips)
        cartaoCor.addView(rolH, lp(CHEIO, AUTO, 12, 6))

        val nomes = listOf("Saturação", "Contraste", "Brilho", "Vermelho", "Verde", "Azul")
        val maxs = intArrayOf(200, 150, 20, 130, 130, 130)
        val salvo = Cor.salvo(this)
        val iniciais = intArrayOf(
            Math.round(salvo.sat * 100f), Math.round(salvo.con * 100f), Math.round(salvo.bri * 100f),
            Math.round(salvo.r * 100f), Math.round(salvo.g * 100f), Math.round(salvo.b * 100f)
        )
        for (i in nomes.indices) {
            val sl = slider(nomes[i], minCor[i], maxs[i], iniciais[i], true, { p -> formatoCor(i, p) }) { _ -> soltouCor() }
            barrasCor.add(sl.second)
            cartaoCor.addView(sl.first)
        }
        pintarChips(Prefs.str(this, "cor_preset", "original"))

        val linhaAuto = horizontal()
        linhaAuto.addView(texto("Aplicar só durante o jogo", 14f, Cores.TEXTO, true), pesos())
        val chAuto = Chave(this)
        chAuto.definir(Prefs.modAuto(this, "cor"))
        chAuto.aoMudar = { v -> Prefs.setModAuto(this, "cor", v) }
        linhaAuto.addView(chAuto)
        cartaoCor.addView(linhaAuto, lp(CHEIO, AUTO, 14, 4))
        val restaurar = texto("Restaurar cores", 14f, Cores.ACENTO, true)
        restaurar.setPadding(0, dp(10), 0, dp(4))
        restaurar.setOnClickListener { restaurarCores() }
        cartaoCor.addView(restaurar)
        col.addView(cartaoCor)

        col.addView(secaoLinha("Renderização"), lp(CHEIO, AUTO, 22, 10))
        val cardHwui = cartao()
        cardHwui.addView(
            cabecalho(
                "tela", "Renderizador da interface", "Motor que desenha a interface dos apps.", "Renderizador (HWUI)",
                "Troca o motor de desenho da interface dos apps (Skia OpenGL ou Skia Vulkan). Vale para apps abertos depois da troca e não muda o motor interno dos jogos. Padrão devolve o valor do sistema."
            )
        )
        segHwui = Segmentado(this, listOf("Padrão", "Skia GL", "Skia Vulkan"), 12.5f)
        segHwui.definir(Prefs.lng(this, "hwui", 0L).toInt())
        segHwui.aoEscolher = { i ->
            Prefs.putLng(this, "hwui", i.toLong())
            emBg { Tuner.renderizador(i) }
        }
        cardHwui.addView(segHwui, lp(CHEIO, AUTO, 12, 0))
        col.addView(cardHwui)

        val cardDriver = cartao()
        cardDriver.addView(
            cabecalho(
                "cpu", "Driver gráfico", "Escolha o driver usado pelos apps.", "Driver gráfico",
                "Game Driver usa o driver atualizável da GPU quando o aparelho tem um. ANGLE traduz o OpenGL ES para Vulkan e pode melhorar ou piorar, dependendo do jogo. Vale ao abrir o jogo de novo. Se algo ficar estranho, volte para Padrão."
            )
        )
        segDriver = Segmentado(this, listOf("Padrão", "Game Driver", "ANGLE"), 12.5f)
        segDriver.definir(Prefs.lng(this, "driver", 0L).toInt())
        segDriver.aoEscolher = { i ->
            Prefs.putLng(this, "driver", i.toLong())
            emBg { Tuner.driver(i) }
        }
        cardDriver.addView(segDriver, lp(CHEIO, AUTO, 12, 0))
        col.addView(cardDriver, lp(CHEIO, AUTO, 14, 0))
        return rolavel(col)
    }

    private fun formatoCor(i: Int, p: Int): String =
        if (i == 2) String.format(Locale.US, "%+.2f", p / 100f) else String.format(Locale.US, "%.2f", p / 100f)

    private fun chip(p: Cor.Preset): LinearLayout {
        val c = horizontal()
        c.setPadding(dp(12), dp(9), dp(14), dp(9))
        val ponto = View(this)
        ponto.background = forma(p.amostra, 8)
        c.addView(ponto, LinearLayout.LayoutParams(dp(14), dp(14)).apply { rightMargin = dp(8) })
        c.addView(texto(p.nome, 13f, Cores.TEXTO, true))
        c.setOnClickListener { escolherPreset(p) }
        c.pressionar()
        chipsPreset[p.id] = c
        return c
    }

    private fun pintarChips(id: String?) {
        for ((k, v) in chipsPreset) {
            val sel = k == id
            v.background = forma(
                if (sel) Cores.SELECIONADO else Cores.SUPERFICIE2, 12,
                if (sel) Cores.ACENTO else Cores.LINHA, 1
            )
        }
    }

    private fun marcarPreset(id: String?) {
        Prefs.putStr(this, "cor_preset", id ?: "custom")
        pintarChips(id)
    }

    private fun escolherPreset(p: Cor.Preset) {
        Cor.salvar(this, p.ajuste)
        definirBarras(p.ajuste)
        marcarPreset(p.id)
        emBg { Cor.aplicar(p.ajuste) }
    }

    private fun definirBarras(a: Cor.Ajuste) {
        val v = intArrayOf(
            Math.round(a.sat * 100f), Math.round(a.con * 100f), Math.round(a.bri * 100f),
            Math.round(a.r * 100f), Math.round(a.g * 100f), Math.round(a.b * 100f)
        )
        for (i in barrasCor.indices) {
            barrasCor[i].progress = (v[i] - minCor[i]).coerceIn(0, barrasCor[i].max)
        }
    }

    private fun valorBarra(i: Int): Float = (barrasCor[i].progress + minCor[i]) / 100f

    private fun soltouCor() {
        val a = Cor.Ajuste(valorBarra(0), valorBarra(1), valorBarra(2), valorBarra(3), valorBarra(4), valorBarra(5))
        Cor.salvar(this, a)
        marcarPreset(null)
        emBg { Cor.aplicar(a) }
    }

    private fun restaurarCores() {
        Cor.salvar(this, Cor.ORIGINAL)
        definirBarras(Cor.ORIGINAL)
        marcarPreset("original")
        emBg { Cor.aplicar(Cor.ORIGINAL) }
    }

    // ---- avançado ----------------------------------------------------------

    private fun modulo(id: String): Modulos.Modulo = Modulos.lista.first { it.id == id }

    private fun paginaAvancado(): View {
        val raiz = vertical()
        val col = coluna()

        val cab = horizontal()
        cab.setPadding(dp(14), dp(14), dp(14), dp(14))
        cab.background = forma(Cores.SUPERFICIE, 18, Cores.LINHA, 1)
        cab.addView(caixaIcone("ajustes"), LinearLayout.LayoutParams(dp(54), dp(54)))
        val cabTxt = vertical()
        cabTxt.addView(texto("Configuração avançada", 18f, Cores.TEXTO, true))
        cabTxt.addView(texto("Ferramentas de terminal para otimizar o sistema.", 12f, Cores.SUAVE), lp(CHEIO, AUTO, 2, 0))
        cab.addView(cabTxt, LinearLayout.LayoutParams(0, AUTO, 1f).apply { leftMargin = dp(14) })
        col.addView(cab, lp(CHEIO, AUTO, 0, 14))

        col.addView(
            cartaoAvancado("FERRAMENTAS", "Terminal root", "Execute comandos como root", "terminal", null) { mostrarTerminal() },
            lp(CHEIO, AUTO, 0, 10)
        )
        col.addView(
            cartaoAvancado("CACHE", "Smart Cache Cleaner", "Limpe o cache e os arquivos temporários", "limpar", null) {
                emBg { Tuner.limparCache() }
            },
            lp(CHEIO, AUTO, 0, 10)
        )
        col.addView(
            cartaoAvancado("APLICATIVO", "Smart App Killer", "Interrompe apps em segundo plano que não estão em uso", "memoria", "profunda") {
                dialogoModulo(modulo("profunda"))
            },
            lp(CHEIO, AUTO, 0, 10)
        )
        col.addView(
            cartaoAvancado("TOQUE", "Lightning Touch", "Melhore a resposta da tela ao toque", "toque", "toque") {
                dialogoModulo(modulo("toque"))
            },
            lp(CHEIO, AUTO, 0, 10)
        )
        col.addView(
            cartaoAvancado("REDE", "Baixa latência do Wi‑Fi", "Otimize a latência da conexão", "wifi", "wifi") {
                dialogoModulo(modulo("wifi"))
            },
            lp(CHEIO, AUTO, 0, 10)
        )
        col.addView(
            cartaoAvancado("NOTIFICAÇÕES", "Não perturbe", "Silencie o aparelho enquanto joga", "sino", "dnd") {
                dialogoModulo(modulo("dnd"))
            },
            lp(CHEIO, AUTO, 0, 10)
        )
        col.addView(
            cartaoAvancado("SISTEMA", "Economia de bateria", "Libere o app para o Game Turbo não ser encerrado", "raio", null) {
                startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
            },
            lp(CHEIO, AUTO, 0, 10)
        )
        col.addView(
            cartaoAvancado("APLICATIVO", "Apps protegidos", "Nunca encerrados pelo Smart App Killer", "jogos", null) {
                startActivity(Intent(this, GamesActivity::class.java).putExtra("modo", "protegidos"))
            },
            lp(CHEIO, AUTO, 0, 10)
        )
        col.addView(
            cartaoAvancado("DIAGNÓSTICO", "Diagnóstico", "Mostra o que o app enxerga no aparelho", "info", null) { mostrarDiagnostico() },
            lp(CHEIO, AUTO, 0, 10)
        )
        col.addView(
            cartaoAvancado("SISTEMA", "Restaurar padrão", "Devolve CPU, GPU, tela e módulos ao normal", "atualizar", null) { restaurarPadrao() },
            lp(CHEIO, AUTO, 0, 4)
        )
        col.addView(texto("RootBoost 0.5.0", 12f, Cores.SUAVE), lp(CHEIO, AUTO, 14, 0))

        raiz.addView(rolavel(col), LinearLayout.LayoutParams(CHEIO, 0, 1f))
        raiz.addView(rodapeStatus(), LinearLayout.LayoutParams(CHEIO, AUTO))
        return raiz
    }

    private fun cartaoAvancado(
        tag: String, titulo: String, desc: String, icone: String, idStatus: String?, aoClicar: () -> Unit
    ): LinearLayout {
        val c = horizontal()
        c.setPadding(dp(14), dp(14), dp(14), dp(14))
        c.background = clicavel(Cores.SUPERFICIE, 18, Cores.LINHA, 1)
        c.addView(caixaIcone(icone), LinearLayout.LayoutParams(dp(54), dp(54)))
        val txt = vertical()
        val chip = texto(tag, 10f, Cores.ACENTO, true)
        chip.letterSpacing = 0.06f
        chip.setPadding(dp(8), dp(3), dp(8), dp(3))
        chip.background = forma(Cores.SUPERFICIE2, 8, Cores.LINHA, 1)
        txt.addView(chip, LinearLayout.LayoutParams(AUTO, AUTO))
        txt.addView(texto(titulo, 15f, Cores.TEXTO, true), lp(CHEIO, AUTO, 6, 0))
        txt.addView(texto(desc, 12f, Cores.SUAVE), lp(CHEIO, AUTO, 2, 0))
        c.addView(txt, LinearLayout.LayoutParams(0, AUTO, 1f).apply { leftMargin = dp(14) })
        val st = texto("Pronto", 12f, Cores.OK, true)
        st.setPadding(dp(8), 0, dp(6), 0)
        c.addView(st)
        c.addView(texto("›", 22f, Cores.SUAVE))
        if (idStatus != null) statusAvancado[idStatus] = st
        c.setOnClickListener { aoClicar() }
        c.pressionar()
        return c
    }

    private fun atualizarAvancado() {
        for ((id, tv) in statusAvancado) {
            val m = Modulos.lista.firstOrNull { it.id == id } ?: continue
            val txt = if (!m.reversivel) "Pronto" else if (Prefs.modAtivo(this, id)) "Ativo" else "Inativo"
            tv.text = txt
            tv.setTextColor(if (txt == "Inativo") Cores.AMBAR else Cores.OK)
        }
    }

    private fun rodapeStatus(): LinearLayout {
        val f = vertical()
        f.setBackgroundColor(Cores.SUPERFICIE)
        f.setPadding(dp(16), dp(12), dp(16), dp(12))
        val t = texto("STATUS DO SISTEMA", 11f, Cores.ACENTO, true)
        t.letterSpacing = 0.08f
        f.addView(t)
        val linha = LinearLayout(this)
        linha.orientation = LinearLayout.HORIZONTAL
        fun coluna(rotulo: String): TextView {
            val c = vertical()
            c.gravity = Gravity.CENTER_HORIZONTAL
            val v = texto("—", 17f, Cores.OK, true)
            c.addView(texto(rotulo, 11f, Cores.SUAVE))
            c.addView(v, lp(AUTO, AUTO, 2, 0))
            linha.addView(c, LinearLayout.LayoutParams(0, AUTO, 1f))
            return v
        }
        stCpu = coluna("Uso de CPU")
        stRam = coluna("Uso de RAM")
        stTemp = coluna("Temperatura")
        stBat = coluna("Bateria")
        f.addView(linha, lp(CHEIO, AUTO, 8, 0))
        return f
    }

    private fun dialogoModulo(m: Modulos.Modulo) {
        val ativo = Prefs.modAtivo(this, m.id)
        val c = vertical()
        c.setPadding(dp(22), dp(10), dp(22), dp(4))
        c.addView(texto(m.info, 13f, Cores.SUAVE))
        val l = horizontal()
        l.addView(texto("Aplicar ao abrir jogos", 14f, Cores.TEXTO, true), pesos())
        val ch = Chave(this)
        ch.definir(Prefs.modAuto(this, m.id))
        ch.aoMudar = { v -> Prefs.setModAuto(this, m.id, v) }
        l.addView(ch)
        c.addView(l, lp(CHEIO, AUTO, 16, 8))
        val acao = if (!m.reversivel) "Executar agora" else if (ativo) "Desligar agora" else "Ligar agora"
        AlertDialog.Builder(this)
            .setTitle(m.nome)
            .setView(c)
            .setPositiveButton(acao) { _, _ ->
                emBg {
                    val r = if (m.reversivel && ativo) Modulos.desligar(this, m.id) else Modulos.ligar(this, m.id, null)
                    r.msg
                }
            }
            .setNegativeButton("Fechar", null)
            .show()
    }

    private fun mostrarTerminal() {
        val c = vertical()
        c.setPadding(dp(20), dp(8), dp(20), dp(8))
        val campo = EditText(this)
        campo.hint = "comando (ex.: cat /proc/version)"
        campo.setHintTextColor(Cores.SUAVE)
        campo.setTextColor(Cores.TEXTO)
        campo.typeface = Typeface.MONOSPACE
        campo.textSize = 13f
        campo.isSingleLine = true
        campo.setPadding(dp(12), dp(10), dp(12), dp(10))
        campo.background = forma(Cores.SUPERFICIE2, 12)
        c.addView(campo)
        val saida = TextView(this)
        saida.typeface = Typeface.MONOSPACE
        saida.textSize = 11f
        saida.setTextColor(Cores.TEXTO)
        saida.setTextIsSelectable(true)
        val sv = ScrollView(this)
        sv.addView(saida)
        c.addView(sv, LinearLayout.LayoutParams(CHEIO, dp(220)).apply { topMargin = dp(10) })
        val d = AlertDialog.Builder(this)
            .setTitle("Terminal root")
            .setView(c)
            .setPositiveButton("Executar", null)
            .setNegativeButton("Fechar", null)
            .create()
        d.show()
        d.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
            val cmd = campo.text.toString().trim()
            if (cmd.isNotEmpty()) {
                saida.text = "Executando…"
                Thread {
                    val r = Tuner.terminal(cmd)
                    runOnUiThread { saida.text = r }
                }.start()
            }
        }
    }

    private fun mostrarDiagnostico() {
        Toast.makeText(this, "Coletando…", Toast.LENGTH_SHORT).show()
        Thread {
            val txt = Tuner.diagnostico(this)
            runOnUiThread {
                val tv = TextView(this)
                tv.text = txt
                tv.textSize = 11f
                tv.typeface = Typeface.MONOSPACE
                tv.setTextColor(Cores.TEXTO)
                tv.setTextIsSelectable(true)
                tv.setPadding(dp(20), dp(12), dp(20), dp(12))
                val sv = ScrollView(this)
                sv.addView(tv)
                AlertDialog.Builder(this)
                    .setTitle("Diagnóstico")
                    .setView(sv)
                    .setPositiveButton("Copiar") { _, _ ->
                        val cm = getSystemService(ClipboardManager::class.java)
                        cm.setPrimaryClip(ClipData.newPlainText("diagnostico", txt))
                        Toast.makeText(this, "Copiado.", Toast.LENGTH_SHORT).show()
                    }
                    .setNegativeButton("Fechar", null)
                    .show()
            }
        }.start()
    }

    private fun mostrarInfo(titulo: String, texto: String) {
        AlertDialog.Builder(this)
            .setTitle(titulo)
            .setMessage(texto)
            .setPositiveButton("Entendi", null)
            .show()
    }

    // ---- ações -------------------------------------------------------------

    private fun alternarTurbo(ligado: Boolean) {
        Prefs.setTurbo(this, ligado)
        if (ligado) {
            if (Build.VERSION.SDK_INT >= 33 &&
                checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
            ) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
            if (Prefs.jogos(this).isEmpty()) {
                Toast.makeText(this, "Escolha pelo menos um jogo na aba Jogos.", Toast.LENGTH_LONG).show()
            }
            if (Prefs.painelNoJogo(this) || Prefs.fpsOn(this)) pedirSobreposicao()
            startForegroundService(Intent(this, GameService::class.java))
        } else {
            stopService(Intent(this, GameService::class.java))
        }
        mostrarTurbo()
    }

    private fun pedirSobreposicao() {
        if (Settings.canDrawOverlays(this)) return
        Toast.makeText(this, "Libere \"Sobrepor a outros apps\" para o painel e o FPS aparecerem no jogo.", Toast.LENGTH_LONG).show()
        startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
    }

    private fun aplicar(id: String) {
        Prefs.setBase(this, id)
        emBg { Tuner.aplicar(this, id) }
    }

    private fun aplicarCpu(gov: String?) {
        val mn = Prefs.lng(this, "cpu_min", 0L).toInt()
        val mx = Prefs.lng(this, "cpu_max", 100L).toInt()
        emBg { Tuner.cpuManual(this, gov, mn, mx) }
    }

    private fun restaurarPadrao() {
        Prefs.setBase(this, "equilibrado")
        Prefs.putLng(this, "cpu_min", 0L)
        Prefs.putLng(this, "cpu_max", 100L)
        Prefs.putLng(this, "taxa_manual", 0L)
        Prefs.putLng(this, "dpi", 0L)
        Cor.salvar(this, Cor.ORIGINAL)
        passosDpi.definir(0, true)
        passosTaxa.definir(0, true)
        barraCpuMin.progress = 0
        barraCpuMax.progress = barraCpuMax.max
        definirBarras(Cor.ORIGINAL)
        marcarPreset("original")
        emBg {
            for (m in Modulos.lista) {
                if (m.reversivel && Prefs.modAtivo(this, m.id)) Modulos.desligar(this, m.id)
            }
            Cor.aplicar(Cor.ORIGINAL)
            Tuner.taxaTela(0)
            Tuner.dpi(0)
            Prefs.putLng(this, "gpu_modo", 0L)
            Tuner.gpuRestaurar(this)
            Tuner.aplicar(this, "equilibrado")
        }
    }

    private fun escolherGovernor() {
        if (govs.isEmpty()) {
            Toast.makeText(this, "Não consegui ler os governors (root?).", Toast.LENGTH_LONG).show()
            return
        }
        AlertDialog.Builder(this)
            .setTitle("Governor da CPU")
            .setItems(govs.toTypedArray()) { _, i -> aplicarCpu(govs[i]) }
            .show()
    }

    /** Roda o trabalho fora da tela e mostra o resultado num aviso. */
    private fun emBg(trabalho: () -> String) {
        Thread {
            val msg = try {
                trabalho()
            } catch (e: Exception) {
                "Falhou: ${e.message}"
            }
            runOnUiThread {
                if (msg.isNotEmpty()) Toast.makeText(this, msg, Toast.LENGTH_LONG).show()
                atualizarTudo()
            }
        }.start()
    }

    private fun atualizarTudo() {
        val aplicado = Prefs.aplicado(this)
        segPerfil.definir(Tuner.perfis.indexOfFirst { it.id == aplicado })
        tvPerfilDesc.text = Tuner.perfis.firstOrNull { it.id == aplicado }?.desc ?: "Ajuste manual em uso."
        atualizarGovernor()
        atualizarAvancado()
    }

    private fun atualizarGovernor() {
        Thread {
            val info = Tuner.infoCpu()
            runOnUiThread {
                if (info != null) {
                    govs = info.govs
                    tvGov.text = info.gov + " • " + info.minMhz + "–" + info.maxMhz + " MHz"
                } else {
                    tvGov.text = "Sem leitura (root?)"
                }
            }
        }.start()
    }

    // ---- ciclo de vida e leituras ------------------------------------------

    override fun onResume() {
        super.onResume()
        tvJogos.text = "Jogos escolhidos: ${Prefs.jogos(this).size}"
        val na = Prefs.atalhos(this).size
        tvAtalhos.text = if (na == 0) "Nenhum app escolhido ainda" else "$na app(s) escolhido(s)"
        atualizarTudo()
        if (Prefs.turbo(this)) startForegroundService(Intent(this, GameService::class.java))
        if (Prefs.overlay(this) && Settings.canDrawOverlays(this)) startService(Intent(this, OverlayService::class.java))
        lendo = true
        val minha = ++geracao
        Thread {
            val root = RootShell.root()
            runOnUiThread { mostrarRoot(root) }
            while (lendo && minha == geracao) {
                val s = if (root) Stats.ler() else null
                runOnUiThread { mostrarStats(s) }
                try {
                    Thread.sleep(1000)
                } catch (e: InterruptedException) {
                    break
                }
            }
        }.start()
    }

    override fun onPause() {
        lendo = false
        geracao++
        super.onPause()
    }

    private fun mostrarRoot(root: Boolean) {
        tvRoot.text = if (root) "Root ativo" else "Sem root"
        tvRoot.setTextColor(if (root) Cores.OK else Cores.ERRO)
    }

    private fun mostrarTurbo() {
        val agora = System.currentTimeMillis()
        val batida = Prefs.lng(this, "beat", 0L)
        val app = Prefs.str(this, "fg", "?")
        val emJogo = Prefs.str(this, "em_jogo", "")
        val vivo = agora - batida <= 9000L
        val (txt, cor) = when {
            !Prefs.turbo(this) -> Pair("Desligado. Ligue o switch para vigiar os jogos.", Cores.SUAVE)
            Prefs.jogos(this).isEmpty() -> Pair("Ligado, mas nenhum jogo foi escolhido.", Cores.AMBAR)
            !vivo -> Pair("Ligado, mas o serviço não está respondendo.", Cores.ERRO)
            emJogo.isNotEmpty() -> Pair("Em jogo • $emJogo", Cores.OK)
            else -> Pair("Vigiando • app atual: $app", Cores.OK)
        }
        tvTurbo.text = txt
        tvTurbo.setTextColor(cor)
        pulso.cor = cor
        pulso.invalidate()
    }

    private fun mostrarStats(s: Stats.Leitura?) {
        mostrarTurbo()
        val bat = Stats.bateria(this)
        stBat.text = if (bat >= 0) "$bat%" else "—"
        if (s == null) return
        if (s.cpuPct >= 0) {
            gCpu.adicionar(s.cpuPct.toFloat(), "${s.cpuPct}%")
            stCpu.text = "${s.cpuPct}%"
        }
        nucleos.definir(s.cores, s.coresMax)
        tvGpuAgora.text = if (s.gpuMhz > 0) "Adreno • ${s.gpuMhz} MHz" else "GPU —"
        if (s.gpuPct >= 0) gGpu.adicionar(s.gpuPct.toFloat(), "${s.gpuPct}%") else gGpu.adicionar(0f, "—")
        val pct = if (s.ramTotalMb > 0) s.ramUsadaMb * 100 / s.ramTotalMb else 0
        gRam.adicionar(pct.toFloat(), "$pct%")
        stRam.text = "$pct%"
        stRam.setTextColor(if (pct >= 85) Cores.ERRO else Cores.OK)
        val t = s.temp
        if (t != null) {
            val txt = String.format(Locale.US, "%.0f °C", t)
            gTemp.adicionar(t, txt)
            stTemp.text = txt
            stTemp.setTextColor(if (t >= 45f) Cores.ERRO else Cores.OK)
        }
    }

    // ---- peças de interface ------------------------------------------------

    private fun coluna(): LinearLayout {
        val c = vertical()
        c.setPadding(dp(20), dp(20), dp(20), dp(28))
        colunas.add(c)
        return c
    }

    private fun rolavel(c: View): ScrollView {
        val s = ScrollView(this)
        s.isVerticalScrollBarEnabled = false
        s.addView(c)
        return s
    }

    private fun pesos() = LinearLayout.LayoutParams(0, AUTO, 1f)

    private fun grafico(rotulo: String, cor: Int, maximo: Float): Grafico {
        val g = Grafico(this)
        g.rotulo = rotulo
        g.maximo = maximo
        g.definirCor(cor)
        g.background = forma(Cores.SUPERFICIE2, 14)
        return g
    }

    private fun atalho(titulo: String, sub: String, aoClicar: () -> Unit): LinearLayout {
        val c = vertical()
        c.setPadding(dp(14), dp(14), dp(14), dp(14))
        c.background = clicavel(Cores.SUPERFICIE, 16, Cores.LINHA, 1)
        c.addView(texto(titulo, 14f, Cores.TEXTO, true))
        c.addView(texto(sub, 11.5f, Cores.SUAVE), lp(CHEIO, AUTO, 2, 0))
        c.setOnClickListener { aoClicar() }
        c.pressionar()
        return c
    }

    private fun grade(a: View, b: View): LinearLayout {
        val l = LinearLayout(this)
        l.orientation = LinearLayout.HORIZONTAL
        l.addView(a, LinearLayout.LayoutParams(0, AUTO, 1f).apply { rightMargin = dp(5) })
        l.addView(b, LinearLayout.LayoutParams(0, AUTO, 1f).apply { leftMargin = dp(5) })
        return l
    }

    private fun cabecalho(icone: String, titulo: String, desc: String, infoTitulo: String, infoTexto: String): LinearLayout {
        val l = horizontal()
        l.addView(caixaIcone(icone), LinearLayout.LayoutParams(dp(46), dp(46)))
        val txt = vertical()
        txt.addView(texto(titulo, 15f, Cores.TEXTO, true))
        txt.addView(texto(desc, 12f, Cores.SUAVE), lp(CHEIO, AUTO, 2, 0))
        l.addView(txt, LinearLayout.LayoutParams(0, AUTO, 1f).apply { leftMargin = dp(14); rightMargin = dp(8) })
        l.addView(botaoInfo { mostrarInfo(infoTitulo, infoTexto) }, LinearLayout.LayoutParams(dp(40), dp(40)))
        return l
    }

    private fun notaInfo(t: String): LinearLayout {
        val l = horizontal()
        l.setPadding(0, dp(6), 0, 0)
        val ic = Icone(this, "info")
        ic.cor = Cores.SUAVE
        l.addView(ic, LinearLayout.LayoutParams(AUTO, AUTO).apply { rightMargin = dp(8) })
        l.addView(texto(t, 12f, Cores.SUAVE), pesos())
        return l
    }

    private fun linhaChave(titulo: String, sub: String, inicial: Boolean, aoMudar: (Boolean) -> Unit): LinearLayout {
        val l = horizontal()
        l.setPadding(dp(16), dp(14), dp(16), dp(14))
        l.background = forma(Cores.SUPERFICIE, 18, Cores.LINHA, 1)
        val txt = vertical()
        txt.addView(texto(titulo, 15f, Cores.TEXTO, true))
        txt.addView(texto(sub, 12f, Cores.SUAVE), lp(CHEIO, AUTO, 2, 0))
        l.addView(txt, pesos())
        val ch = Chave(this)
        ch.definir(inicial)
        ch.aoMudar = aoMudar
        l.addView(ch, LinearLayout.LayoutParams(AUTO, AUTO).apply { leftMargin = dp(12) })
        return l
    }

    /** Linha de recurso no estilo "ícone, título, descrição, chave e botão de informação". */
    private fun linhaRecurso(m: Modulos.Modulo): LinearLayout {
        val l = horizontal()
        l.setPadding(dp(14), dp(14), dp(8), dp(14))
        l.background = forma(Cores.SUPERFICIE, 18, Cores.LINHA, 1)
        l.addView(caixaIcone(m.icone), LinearLayout.LayoutParams(dp(46), dp(46)))
        val txt = vertical()
        txt.addView(texto(m.nome, 15f, Cores.TEXTO, true))
        txt.addView(texto(m.desc, 12f, Cores.SUAVE), lp(CHEIO, AUTO, 2, 0))
        l.addView(txt, LinearLayout.LayoutParams(0, AUTO, 1f).apply { leftMargin = dp(14); rightMargin = dp(10) })
        val ch = Chave(this)
        ch.definir(Prefs.modAuto(this, m.id))
        ch.aoMudar = { v -> Prefs.setModAuto(this, m.id, v) }
        l.addView(ch)
        val sep = View(this)
        sep.setBackgroundColor(Cores.LINHA)
        l.addView(sep, LinearLayout.LayoutParams(dp(1), dp(30)).apply { leftMargin = dp(10); rightMargin = dp(2) })
        l.addView(botaoInfo { mostrarInfo(m.nome, m.info) }, LinearLayout.LayoutParams(dp(44), dp(44)))
        return l
    }

    /** Controles da GPU Adreno lidos do kernel: governor, frequência mínima/máxima e Adreno Boost. */
    private fun cartaoGpu(): LinearLayout {
        val c = cartao()
        val topo = horizontal()
        topo.addView(caixaIcone("cpu"), LinearLayout.LayoutParams(dp(46), dp(46)))
        val tx = vertical()
        val tvModelo = texto("Lendo a GPU…", 15f, Cores.TEXTO, true)
        tx.addView(tvModelo)
        val tvDet = texto("", 12f, Cores.SUAVE)
        tx.addView(tvDet, lp(CHEIO, AUTO, 2, 0))
        topo.addView(tx, LinearLayout.LayoutParams(0, AUTO, 1f).apply { leftMargin = dp(14) })
        c.addView(topo)

        val corpo = vertical()
        c.addView(corpo, lp(CHEIO, AUTO, 8, 0))

        Thread {
            val g = Tuner.infoGpu()
            runOnUiThread {
                if (g == null || g.freqsHz.isEmpty()) {
                    tvModelo.text = "GPU não encontrada"
                    tvDet.text = "Precisa de root e de um kernel que exponha a GPU em /sys."
                    return@runOnUiThread
                }
                val mhz = g.freqsHz.map { (it / 1_000_000L).toInt() }
                tvModelo.text = g.modelo.ifBlank { "GPU Adreno" }
                tvDet.text = "${g.gov} • ${mhz.first()}–${mhz.last()} MHz • ${mhz.size} níveis"

                val idxMin0 = g.freqsHz.indexOfFirst { it >= g.minHz }.coerceAtLeast(0)
                val idxMax0 = g.freqsHz.indexOfLast { it <= g.maxHz }.let { if (it < 0) g.freqsHz.size - 1 else it }
                var gov: String? = null

                val linhaGov = horizontal()
                linhaGov.setPadding(dp(14), dp(12), dp(14), dp(12))
                linhaGov.background = clicavel(Cores.SUPERFICIE2, 14)
                val tvGov = texto(g.gov, 12.5f, Cores.ACENTO, true)
                val bl = vertical()
                bl.addView(texto("Governor da GPU", 14f, Cores.TEXTO, true))
                bl.addView(tvGov, lp(CHEIO, AUTO, 2, 0))
                linhaGov.addView(bl, pesos())
                linhaGov.addView(texto("›", 20f, Cores.SUAVE))
                linhaGov.setOnClickListener {
                    AlertDialog.Builder(this)
                        .setTitle("Governor da GPU")
                        .setItems(g.govs.toTypedArray()) { _, i ->
                            gov = g.govs[i]
                            tvGov.text = g.govs[i]
                            val mn = g.freqsHz[Prefs.lng(this, "gpu_idx_min", idxMin0.toLong()).toInt().coerceIn(0, g.freqsHz.size - 1)]
                            val mx = g.freqsHz[Prefs.lng(this, "gpu_idx_max", idxMax0.toLong()).toInt().coerceIn(0, g.freqsHz.size - 1)]
                            emBg { Tuner.gpuManual(this, gov, mn, mx) }
                        }
                        .show()
                }
                linhaGov.pressionar()
                corpo.addView(linhaGov, lp(CHEIO, AUTO, 0, 4))

                val ult = g.freqsHz.size - 1
                val salvoMin = Prefs.lng(this, "gpu_idx_min", idxMin0.toLong()).toInt().coerceIn(0, ult)
                val salvoMax = Prefs.lng(this, "gpu_idx_max", idxMax0.toLong()).toInt().coerceIn(0, ult)
                var barMin: SeekBar? = null
                var barMax: SeekBar? = null
                fun enviar() {
                    val a = (barMin?.progress ?: 0).coerceIn(0, ult)
                    var b = (barMax?.progress ?: ult).coerceIn(0, ult)
                    if (b < a) b = a
                    Prefs.putLng(this, "gpu_idx_min", a.toLong())
                    Prefs.putLng(this, "gpu_idx_max", b.toLong())
                    Prefs.putLng(this, "gpu_modo", 0L)
                    emBg { Tuner.gpuManual(this, gov, g.freqsHz[a], g.freqsHz[b]) }
                }
                val sMin = slider("Frequência mínima", 0, ult, salvoMin, true, { p -> "${mhz[p.coerceIn(0, ult)]} MHz" }) { enviar() }
                val sMax = slider("Frequência máxima", 0, ult, salvoMax, true, { p -> "${mhz[p.coerceIn(0, ult)]} MHz" }) { enviar() }
                barMin = sMin.second
                barMax = sMax.second
                corpo.addView(sMin.first)
                corpo.addView(sMax.first)

                if (g.boost >= 0) {
                    corpo.addView(texto("Adreno Boost", 14f, Cores.TEXTO, true), lp(CHEIO, AUTO, 14, 6))
                    val segBoost = Segmentado(this, listOf("Off", "1", "2", "3"), 12.5f)
                    segBoost.definir(g.boost.coerceIn(0, 3))
                    segBoost.aoEscolher = { i -> emBg { Tuner.adrenoBoost(i) } }
                    corpo.addView(segBoost)
                } else {
                    corpo.addView(notaInfo("O kernel deste aparelho não expõe o Adreno Boost."), lp(CHEIO, AUTO, 10, 0))
                }
                val restaurar = texto("Restaurar GPU", 14f, Cores.ACENTO, true)
                restaurar.setPadding(0, dp(14), 0, dp(2))
                restaurar.setOnClickListener {
                    Prefs.putLng(this, "gpu_idx_min", 0L)
                    Prefs.putLng(this, "gpu_idx_max", ult.toLong())
                    barMin?.progress = 0
                    barMax?.progress = ult
                    emBg { Tuner.gpuRestaurar(this) }
                }
                corpo.addView(restaurar)
            }
        }.start()
        return c
    }

    private fun slider(
        titulo: String, min: Int, max: Int, inicial: Int, embutido: Boolean,
        formato: (Int) -> String, aoSoltar: (Int) -> Unit
    ): Pair<LinearLayout, SeekBar> {
        val c = vertical()
        if (embutido) {
            c.setPadding(0, dp(12), 0, dp(2))
        } else {
            c.setPadding(dp(16), dp(14), dp(16), dp(10))
            c.background = forma(Cores.SUPERFICIE, 18, Cores.LINHA, 1)
        }
        val topo = horizontal()
        topo.addView(texto(titulo, 14f, Cores.TEXTO, true), pesos())
        val valor = texto(formato(inicial), 13f, Cores.ACENTO, true)
        topo.addView(valor)
        c.addView(topo)
        val barra = SeekBar(this)
        barra.max = max - min
        barra.progress = (inicial - min).coerceIn(0, max - min)
        barra.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, doUsuario: Boolean) { valor.text = formato(p + min) }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) { aoSoltar((s?.progress ?: 0) + min) }
        })
        c.addView(barra, lp(CHEIO, AUTO, 6, 0))
        return Pair(c, barra)
    }
}
