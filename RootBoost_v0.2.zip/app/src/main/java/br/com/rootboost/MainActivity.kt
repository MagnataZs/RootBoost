package br.com.rootboost

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import java.util.Locale

class MainActivity : Activity() {

    private lateinit var tvRoot: TextView
    private lateinit var tvJogos: TextView
    private lateinit var tvTurbo: TextView
    private lateinit var tvCpu: TextView
    private lateinit var tvTemp: TextView
    private lateinit var tvRam: TextView
    private lateinit var tvPerfil: TextView
    private val cartoes = LinkedHashMap<String, LinearLayout>()

    @Volatile private var lendo = false
    @Volatile private var geracao = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val a = this

        val col = caixa()
        col.setPadding(dp(20), dp(24), dp(20), dp(32))

        // Cabeçalho
        col.addView(texto("RootBoost", 30f, Cores.TEXTO, true))
        tvRoot = texto("Verificando root…", 13f, Cores.SUAVE)
        tvRoot.setPadding(dp(12), dp(6), dp(12), dp(6))
        tvRoot.background = forma(Cores.SUPERFICIE, 20)
        col.addView(tvRoot, lp(AUTO, AUTO, 8, 16))

        // Game Turbo
        val hero = caixa()
        hero.setPadding(dp(18), dp(18), dp(18), dp(14))
        hero.background = forma(Cores.SUPERFICIE, 24, Cores.TURBO, 1)

        val topoHero = linha()
        val textoHero = caixa()
        textoHero.addView(texto("Game Turbo", 20f, Cores.TURBO, true))
        textoHero.addView(
            texto("Muda para o perfil Gaming quando um jogo da lista abre e volta ao seu perfil quando você sai.", 13f, Cores.SUAVE),
            lp(CHEIO, AUTO, 4, 0)
        )
        tvTurbo = texto("", 12f, Cores.ACENTO)
        textoHero.addView(tvTurbo, lp(CHEIO, AUTO, 6, 0))
        topoHero.addView(textoHero, pesos())
        val swTurbo = Switch(a)
        swTurbo.isChecked = Prefs.turbo(a)
        swTurbo.setOnCheckedChangeListener { _, ligado ->
            Prefs.setTurbo(a, ligado)
            if (ligado) {
                if (Build.VERSION.SDK_INT >= 33 &&
                    checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
                ) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
                if (Prefs.jogos(a).isEmpty()) Toast.makeText(a, "Escolha pelo menos um jogo.", Toast.LENGTH_LONG).show()
                startForegroundService(Intent(a, GameService::class.java))
            } else {
                stopService(Intent(a, GameService::class.java))
            }
        }
        topoHero.addView(swTurbo)
        hero.addView(topoHero)

        val linhaJogos = linha()
        linhaJogos.setPadding(dp(14), dp(12), dp(14), dp(12))
        linhaJogos.background = forma(Cores.SUPERFICIE2, 14)
        tvJogos = texto("", 14f)
        linhaJogos.addView(tvJogos, pesos())
        linhaJogos.addView(texto("›", 20f, Cores.SUAVE))
        linhaJogos.setOnClickListener { startActivity(Intent(a, GamesActivity::class.java)) }
        hero.addView(linhaJogos, lp(CHEIO, AUTO, 14, 0))

        val linhaLimpar = linha()
        linhaLimpar.setPadding(dp(4), dp(10), dp(4), dp(0))
        linhaLimpar.addView(texto("Limpar RAM ao abrir o jogo", 14f), pesos())
        val swLimpar = Switch(a)
        swLimpar.isChecked = Prefs.limparAoJogar(a)
        swLimpar.setOnCheckedChangeListener { _, v -> Prefs.setLimparAoJogar(a, v) }
        linhaLimpar.addView(swLimpar)
        hero.addView(linhaLimpar)
        col.addView(hero)

        // Perfis
        col.addView(secao("Perfis"), lp(CHEIO, AUTO, 24, 8))
        for (p in Tuner.perfis) {
            val c = caixa()
            c.setPadding(dp(16), dp(14), dp(16), dp(14))
            c.addView(texto(p.nome, 16f, Cores.TEXTO, true))
            c.addView(texto(p.desc, 13f, Cores.SUAVE), lp(CHEIO, AUTO, 2, 0))
            c.setOnClickListener { aplicar(p.id) }
            cartoes[p.id] = c
            col.addView(c, lp(CHEIO, AUTO, 0, 8))
        }

        // Agora
        col.addView(secao("Agora"), lp(CHEIO, AUTO, 16, 8))
        val painel = caixa()
        painel.setPadding(dp(16), dp(16), dp(16), dp(8))
        painel.background = forma(Cores.SUPERFICIE, 20)
        val (bCpu, vCpu) = tile("CPU")
        val (bTemp, vTemp) = tile("Temperatura")
        val (bRam, vRam) = tile("RAM em uso")
        val (bPerfil, vPerfil) = tile("Perfil ativo")
        tvCpu = vCpu; tvTemp = vTemp; tvRam = vRam; tvPerfil = vPerfil
        val l1 = linha(); l1.addView(bCpu, pesos()); l1.addView(bTemp, pesos())
        val l2 = linha(); l2.addView(bRam, pesos()); l2.addView(bPerfil, pesos())
        painel.addView(l1); painel.addView(l2)
        col.addView(painel)

        // Ferramentas
        col.addView(secao("Ferramentas"), lp(CHEIO, AUTO, 24, 8))
        col.addView(
            acao("Limpar RAM", "Encerra apps em segundo plano e libera cache.") { emBg { Tuner.limparRam() } },
            lp(CHEIO, AUTO, 0, 8)
        )
        col.addView(
            acao("Otimizar armazenamento", "Roda o fstrim em /data e /cache.") { emBg { Tuner.otimizarArmazenamento() } },
            lp(CHEIO, AUTO, 0, 8)
        )

        val linhaOverlay = linha()
        linhaOverlay.setPadding(dp(16), dp(13), dp(16), dp(13))
        linhaOverlay.background = forma(Cores.SUPERFICIE, 16)
        val textoOverlay = caixa()
        textoOverlay.addView(texto("Painel flutuante", 15f, Cores.TEXTO, true))
        textoOverlay.addView(texto("CPU, temperatura e RAM sobre o jogo. Arraste para mover.", 12f, Cores.SUAVE), lp(CHEIO, AUTO, 2, 0))
        linhaOverlay.addView(textoOverlay, pesos())
        val swOverlay = Switch(a)
        swOverlay.isChecked = Prefs.overlay(a) && Settings.canDrawOverlays(a)
        swOverlay.setOnCheckedChangeListener { botao, ligado ->
            if (ligado) {
                if (!Settings.canDrawOverlays(a)) {
                    botao.isChecked = false
                    Toast.makeText(a, "Libere \"Sobrepor a outros apps\" e ligue de novo.", Toast.LENGTH_LONG).show()
                    startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
                } else {
                    Prefs.setOverlay(a, true)
                    startService(Intent(a, OverlayService::class.java))
                }
            } else {
                Prefs.setOverlay(a, false)
                stopService(Intent(a, OverlayService::class.java))
            }
        }
        linhaOverlay.addView(swOverlay)
        col.addView(linhaOverlay, lp(CHEIO, AUTO, 0, 8))

        col.addView(
            acao("Restaurar valores originais", "Devolve CPU e GPU ao que o aparelho usava ao ligar.") {
                Prefs.setBase(a, "equilibrado")
                emBg { Tuner.saturacao(1f); Tuner.aplicar(a, "equilibrado") }
            },
            lp(CHEIO, AUTO, 0, 8)
        )

        // Tela
        col.addView(secao("Tela"), lp(CHEIO, AUTO, 16, 8))
        val caixaTela = caixa()
        caixaTela.setPadding(dp(16), dp(14), dp(16), dp(10))
        caixaTela.background = forma(Cores.SUPERFICIE, 16)
        val tvSat = texto("Saturação: 1.00", 14f)
        val barra = SeekBar(a)
        barra.max = 150
        barra.progress = 50
        barra.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, doUsuario: Boolean) {
                tvSat.text = String.format(Locale.US, "Saturação: %.2f", 0.5f + p / 100f)
            }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {
                val v = 0.5f + (s?.progress ?: 50) / 100f
                Thread { Tuner.saturacao(v) }.start()
            }
        })
        caixaTela.addView(tvSat)
        caixaTela.addView(barra, lp(CHEIO, AUTO, 6, 0))
        val padrao = texto("Voltar ao padrão", 13f, Cores.ACENTO, true)
        padrao.setPadding(0, dp(8), 0, dp(6))
        padrao.setOnClickListener {
            barra.progress = 50
            Thread { Tuner.saturacao(1f) }.start()
        }
        caixaTela.addView(padrao)
        col.addView(caixaTela)

        col.addView(
            texto(
                "Os valores originais ficam guardados e podem ser restaurados. O RootBoost não desativa a proteção térmica do sistema.",
                12f, Cores.SUAVE
            ),
            lp(CHEIO, AUTO, 20, 0)
        )

        val rolagem = ScrollView(a)
        rolagem.setBackgroundColor(Cores.FUNDO)
        rolagem.addView(col)
        aplicarInsets(rolagem)
        setContentView(rolagem)
    }

    override fun onResume() {
        super.onResume()
        atualizarPerfis()
        tvJogos.text = "Jogos escolhidos: ${Prefs.jogos(this).size}"
        // Depois de reiniciar o aparelho os serviços não voltam sozinhos; religa ao abrir o app.
        if (Prefs.turbo(this)) startForegroundService(Intent(this, GameService::class.java))
        if (Prefs.overlay(this) && Settings.canDrawOverlays(this)) startService(Intent(this, OverlayService::class.java))
        lendo = true
        val minha = ++geracao
        Thread {
            val root = RootShell.root()
            runOnUiThread { mostrarRoot(root) }
            while (lendo && minha == geracao) {
                val s = if (root) Stats.ler() else null
                runOnUiThread { mostrarStats(s) }
                try {
                    Thread.sleep(2000)
                } catch (e: InterruptedException) {
                    break
                }
            }
        }.start()
    }

    override fun onPause() {
        lendo = false
        geracao++
        super.onPause()
    }

    // ---- ações -------------------------------------------------------------

    private fun aplicar(id: String) {
        Prefs.setBase(this, id)
        emBg { Tuner.aplicar(this, id) }
    }

    /** Roda o trabalho fora da tela principal e mostra o resultado num aviso. */
    private fun emBg(trabalho: () -> String) {
        Thread {
            val msg = try {
                trabalho()
            } catch (e: Exception) {
                "Falhou: ${e.message}"
            }
            runOnUiThread {
                Toast.makeText(this, msg, Toast.LENGTH_LONG).show()
                atualizarPerfis()
            }
        }.start()
    }

    private fun atualizarPerfis() {
        val atual = Prefs.aplicado(this)
        for ((id, c) in cartoes) {
            val sel = id == atual
            val borda = if (!sel) Cores.LINHA else if (id == "gaming") Cores.TURBO else Cores.ACENTO
            c.background = forma(if (sel) Cores.SELECIONADO else Cores.SUPERFICIE, 18, borda, if (sel) 2 else 1)
        }
    }

    private fun mostrarRoot(root: Boolean) {
        tvRoot.text = if (root) "Root ativo" else "Sem root — conceda acesso no Magisk/KernelSU"
        tvRoot.setTextColor(if (root) Cores.OK else Cores.ERRO)
    }

    private fun mostrarTurbo() {
        val agora = System.currentTimeMillis()
        val batida = Prefs.lng(this, "beat", 0L)
        val app = Prefs.str(this, "fg", "?")
        tvTurbo.text = when {
            !Prefs.turbo(this) -> "Desligado. Ligue o switch para vigiar os jogos."
            Prefs.jogos(this).isEmpty() -> "Ligado, mas nenhum jogo foi escolhido."
            agora - batida > 9000L -> "Ligado, mas o serviço não está respondendo."
            else -> "Vigiando • app atual: $app"
        }
    }

    private fun mostrarStats(s: Stats.Leitura?) {
        mostrarTurbo()
        if (s == null) {
            tvCpu.text = "—"; tvTemp.text = "—"; tvRam.text = "—"
        } else {
            tvCpu.text = "${s.cpuMhz} MHz"
            tvTemp.text = s.temp?.let { String.format(Locale.US, "%.0f °C", it) } ?: "—"
            tvRam.text = String.format(Locale.US, "%.1f / %.1f GB", s.ramUsadaMb / 1024f, s.ramTotalMb / 1024f)
        }
        tvPerfil.text = Tuner.perfis.firstOrNull { it.id == Prefs.aplicado(this) }?.nome ?: "—"
    }

    // ---- peças de interface ------------------------------------------------

    private fun caixa(): LinearLayout = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }

    private fun linha(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        gravity = Gravity.CENTER_VERTICAL
    }

    private fun pesos() = LinearLayout.LayoutParams(0, AUTO, 1f)

    private fun secao(t: String) = texto(t, 18f, Cores.TEXTO, true)

    private fun acao(titulo: String, sub: String, aoClicar: () -> Unit): LinearLayout {
        val c = caixa()
        c.setPadding(dp(16), dp(13), dp(16), dp(13))
        c.background = forma(Cores.SUPERFICIE, 16)
        c.addView(texto(titulo, 15f, Cores.TEXTO, true))
        c.addView(texto(sub, 12f, Cores.SUAVE), lp(CHEIO, AUTO, 2, 0))
        c.setOnClickListener { aoClicar() }
        return c
    }

    private fun tile(rotulo: String): Pair<LinearLayout, TextView> {
        val b = caixa()
        b.setPadding(0, 0, dp(8), dp(12))
        val valor = texto("—", 20f, Cores.TEXTO, true)
        b.addView(valor)
        b.addView(texto(rotulo, 12f, Cores.SUAVE))
        return Pair(b, valor)
    }
}
