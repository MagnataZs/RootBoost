package br.com.rootboost

import android.content.Context
import android.content.Intent
import android.provider.Settings

/** O que acontece quando um jogo da lista abre e quando fecha. */
object Sessao {

    fun entrar(ctx: Context, pkg: String) {
        Prefs.putStr(ctx, "em_jogo", pkg)
        Prefs.putLng(ctx, "jogo_inicio", System.currentTimeMillis())
        Prefs.putStr(ctx, "jogo_bat0", Stats.bateria(ctx).toString())
        Tuner.aplicar(ctx, Prefs.perfilJogo(ctx, pkg))
        // cada jogo pode ter funções próprias; sem escolha própria vale a lista global
        for (m in Modulos.lista) {
            if (Prefs.modAutoJogo(ctx, pkg, m.id)) Modulos.ligar(ctx, m.id, pkg)
        }
        // emulador (Winlator, GameHub, ARMSX2, NetherSX2...): sobe um pacote de ajustes pensado para CPU pesada
        if (Jogos.ehEmulador(ctx, pkg)) modoEmulador(ctx, pkg)
        // filtro de cor só deste jogo
        val filtro = Prefs.filtroJogo(ctx, pkg)
        if (filtro.isNotEmpty() && Cor.aplicarPreset(ctx, filtro)) Prefs.putBool(ctx, "cj_ativo", true)
        // Modo seguro (jogos com anti-cheat, como o Free Fire): motor gráfico no padrão e nenhuma medição
        // enquanto o jogo está aberto. O RootBoost só ajusta CPU/GPU do aparelho e as funções do sistema.
        if (Prefs.modoSeguro(ctx, pkg)) {
            val hw = Prefs.lng(ctx, "hwui", 0L).toInt()
            val dr = Prefs.lng(ctx, "driver", 0L).toInt()
            if (hw != 0) Tuner.renderizador(0)
            if (dr != 0) Tuner.driver(0)
            Prefs.putBool(ctx, "seg_ativo", hw != 0 || dr != 0)
        } else {
            Monitor.iniciar(ctx, pkg)
        }
        // Jogos em modo seguro ou marcados como "sem overlay" não recebem nada desenhado por cima.
        if (Prefs.semOverlay(ctx, pkg)) {
            ctx.stopService(Intent(ctx, OverlayService::class.java))
        } else if (Settings.canDrawOverlays(ctx)) {
            if (Prefs.painelNoJogo(ctx)) ctx.startService(Intent(ctx, PainelJogoService::class.java))
            if (Prefs.fpsOn(ctx)) ctx.startService(Intent(ctx, FpsService::class.java))
        }
    }

    fun sair(ctx: Context) {
        Monitor.parar()
        ctx.stopService(Intent(ctx, PainelJogoService::class.java))
        ctx.stopService(Intent(ctx, FpsService::class.java))
        for (m in Modulos.lista) {
            if (m.reversivel && Prefs.modAtivo(ctx, m.id)) Modulos.desligar(ctx, m.id)
        }
        if (Prefs.bool(ctx, "cj_ativo", false)) {
            // sai do filtro do jogo: volta ao filtro global (ou ao original se ele só vale durante o jogo)
            Cor.aplicar(if (Prefs.modAuto(ctx, "cor")) Cor.ORIGINAL else Cor.salvo(ctx))
            Prefs.putBool(ctx, "cj_ativo", false)
        }
        if (Prefs.bool(ctx, "seg_ativo", false)) {
            // devolve o motor gráfico que o usuário tinha escolhido antes do jogo seguro abrir
            Tuner.renderizador(Prefs.lng(ctx, "hwui", 0L).toInt())
            Tuner.driver(Prefs.lng(ctx, "driver", 0L).toInt())
            Prefs.putBool(ctx, "seg_ativo", false)
        }
        Tuner.aplicar(ctx, Prefs.base(ctx))
        Prefs.putStr(ctx, "em_jogo", "")
        // O medidor flutuante global volta se estava ligado.
        if (Prefs.overlay(ctx) && Settings.canDrawOverlays(ctx)) ctx.startService(Intent(ctx, OverlayService::class.java))
    }

    /** Funções que ajudam emuladores: mais clock, RAM livre, disco rápido e o sistema fora do caminho. */
    private val PACOTE_EMULADOR = listOf(
        "cpuboost", "gpu", "mali", "sustentado", "readahead", "io", "ram", "profunda", "scan", "poupanca"
    )

    private fun modoEmulador(ctx: Context, pkg: String) {
        val tipoGpu = Prefs.str(ctx, "gpu_tipo", "")
        for (id in PACOTE_EMULADOR) {
            val m = Modulos.lista.firstOrNull { it.id == id } ?: continue
            if (Modulos.indisponivel(ctx, id) != null) continue
            if (m.gpu.isNotEmpty() && tipoGpu.isNotEmpty() && m.gpu != tipoGpu) continue
            if (m.reversivel && Prefs.modAtivo(ctx, id)) continue
            Modulos.ligar(ctx, id, pkg)
        }
    }
}
