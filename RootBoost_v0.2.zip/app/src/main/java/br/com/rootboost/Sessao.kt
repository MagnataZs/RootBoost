package br.com.rootboost

import android.content.Context
import android.content.Intent
import android.provider.Settings

/** O que acontece quando um jogo da lista abre e quando fecha. */
object Sessao {

    fun entrar(ctx: Context, pkg: String) {
        Prefs.putStr(ctx, "em_jogo", pkg)
        Prefs.putLng(ctx, "jogo_inicio", System.currentTimeMillis())
        Prefs.putStr(ctx, "jogo_bat0", Stats.bateria(ctx).toString())
        Tuner.aplicar(ctx, Prefs.perfilJogo(ctx, pkg))
        for (m in Modulos.lista) {
            if (Prefs.modAuto(ctx, m.id)) Modulos.ligar(ctx, m.id, pkg)
        }
        Monitor.iniciar(ctx, pkg)
        // Jogos marcados como "sem overlay" (o Free Fire vem assim) não recebem nada desenhado por cima.
        if (Prefs.semOverlay(ctx, pkg)) {
            ctx.stopService(Intent(ctx, OverlayService::class.java))
        } else if (Settings.canDrawOverlays(ctx)) {
            if (Prefs.painelNoJogo(ctx)) ctx.startService(Intent(ctx, PainelJogoService::class.java))
            if (Prefs.fpsOn(ctx)) ctx.startService(Intent(ctx, FpsService::class.java))
        }
    }

    fun sair(ctx: Context) {
        Monitor.parar()
        ctx.stopService(Intent(ctx, PainelJogoService::class.java))
        ctx.stopService(Intent(ctx, FpsService::class.java))
        for (m in Modulos.lista) {
            if (m.reversivel && Prefs.modAtivo(ctx, m.id)) Modulos.desligar(ctx, m.id)
        }
        Tuner.aplicar(ctx, Prefs.base(ctx))
        Prefs.putStr(ctx, "em_jogo", "")
        // O medidor flutuante global volta se estava ligado.
        if (Prefs.overlay(ctx) && Settings.canDrawOverlays(ctx)) ctx.startService(Intent(ctx, OverlayService::class.java))
    }
}
